'use client';

import { lazy, Suspense, useCallback, useEffect, useRef, useState } from 'react';
import { usePathname, useRouter } from 'next/navigation';
import { createPortal } from 'react-dom';
import { useAuthState } from '../contexts/AuthContext';
import { initializeAuthStore } from '../auth/authStore';

let globalMenuPromise = null;

const loadGlobalMenu = () => {
  if (!globalMenuPromise) {
    globalMenuPromise = import('../layout/GlobalMenu');
  }
  return globalMenuPromise;
};

const GlobalMenu = lazy(loadGlobalMenu);

const THEME_STORAGE_KEY = 'darkMode';
const CLOSE_NAVIGATION_OVERLAYS_EVENT = 'sv:close-navigation-overlays';
const MENU_OPEN_LOCK_MS = 260;
const MENU_CLOSE_LOCK_MS = 220;
const DESKTOP_MENU_CLOSE_MS = 520;
const MENU_IDLE_PRELOAD_DELAY_MS = 180;
const MENU_IDLE_PRELOAD_TIMEOUT_MS = 900;
const DESKTOP_MENU_QUERY = '(min-width: 1024px)';
const DESKTOP_MENU_OPEN_CLASS = 'global-menu-desktop-open';
const HOLD_MENU_UNTIL_ROUTE_PATHS = new Set(['/admin', '/mes-commandes', '/devis']);
const isDesktopMenuViewport = () => (
  typeof window !== 'undefined'
  && window.matchMedia(DESKTOP_MENU_QUERY).matches
);

function MenuIcon({ open }) {
  return (
    <span className="relative block h-4 w-5">
      <span className={`absolute left-0 top-1/2 h-[1.25px] origin-center rounded-full bg-current transition-all duration-[420ms] ${open ? 'w-[19px] rotate-45' : 'w-5 -translate-y-[6px]'}`} />
      <span className={`absolute left-0 top-1/2 h-[1.25px] origin-center rounded-full bg-current transition-all duration-300 ${open ? 'w-[19px] scale-x-0 opacity-0' : 'w-[15px]'}`} />
      <span className={`absolute left-0 top-1/2 h-[1.25px] origin-center rounded-full bg-current transition-all duration-[420ms] ${open ? 'w-[19px] -rotate-45' : 'w-[10px] translate-y-[6px]'}`} />
    </span>
  );
}

export default function GlobalMenuTriggerIsland({ darkMode = false } = {}) {
  const router = useRouter();
  const pathname = usePathname();
  const authState = useAuthState();
  const [effectiveDarkMode, setEffectiveDarkMode] = useState(darkMode);
  const [panelOpen, setPanelOpen] = useState(false);
  const [panelClosing, setPanelClosing] = useState(false);
  const [hasClientMounted, setHasClientMounted] = useState(false);
  const [hasPanelMounted, setHasPanelMounted] = useState(false);
  const [desktopMenuViewport, setDesktopMenuViewport] = useState(false);
  const [menuPreloaded, setMenuPreloaded] = useState(false);
  const [heldNavigationPath, setHeldNavigationPath] = useState(null);
  const closeTimerRef = useRef(null);
  const openFrameRef = useRef(null);
  const transitionLockTimerRef = useRef(null);
  const transitionLockedRef = useRef(false);
  const pointerOpenedRef = useRef(false);
  const pointerOpenedTimerRef = useRef(null);
  const [transitionLocked, setTransitionLocked] = useState(false);

  const syncCriticalAuthSnapshot = useCallback(() => {
    void initializeAuthStore({ forceInitialize: true }).catch(() => {});
  }, []);

  const preloadMenu = useCallback((mountDesktopPanel = false) => {
    const menuPromise = loadGlobalMenu();
    menuPromise.then(() => {
      setMenuPreloaded(true);
      if (mountDesktopPanel && isDesktopMenuViewport()) {
        setHasPanelMounted(true);
      }
    }).catch(() => {});
    return menuPromise;
  }, []);

  useEffect(() => {
    if (typeof window === 'undefined') return undefined;

    const mediaQuery = window.matchMedia(DESKTOP_MENU_QUERY);
    const syncViewport = () => {
      setHasClientMounted(true);
      setDesktopMenuViewport(mediaQuery.matches);
    };

    syncViewport();
    mediaQuery.addEventListener?.('change', syncViewport);
    return () => mediaQuery.removeEventListener?.('change', syncViewport);
  }, []);

  useEffect(() => {
    if (typeof window === 'undefined') return undefined;

    let cancelled = false;
    let preloadTimer = 0;
    let idleCallbackId = 0;

    const clearScheduledPreload = () => {
      if (preloadTimer) {
        window.clearTimeout(preloadTimer);
        preloadTimer = 0;
      }
      if (idleCallbackId && 'cancelIdleCallback' in window) {
        window.cancelIdleCallback(idleCallbackId);
        idleCallbackId = 0;
      }
    };

    const stopListeningForScrollIntent = () => {
      window.removeEventListener('wheel', cancelPreload);
      window.removeEventListener('touchstart', cancelPreload);
      window.removeEventListener('scroll', cancelPreload);
    };

    const runPreload = () => {
      idleCallbackId = 0;
      if (cancelled || window.scrollY > 4 || !isDesktopMenuViewport()) return;
      stopListeningForScrollIntent();
      void preloadMenu(true);
    };

    const schedulePreload = () => {
      if (cancelled || window.scrollY > 4) return;
      preloadTimer = window.setTimeout(() => {
        preloadTimer = 0;
        if (cancelled || window.scrollY > 4) return;
        if ('requestIdleCallback' in window) {
          idleCallbackId = window.requestIdleCallback(runPreload, {
            timeout: MENU_IDLE_PRELOAD_TIMEOUT_MS,
          });
          return;
        }
        runPreload();
      }, MENU_IDLE_PRELOAD_DELAY_MS);
    };

    function cancelPreload() {
      cancelled = true;
      clearScheduledPreload();
      stopListeningForScrollIntent();
    }

    window.addEventListener('wheel', cancelPreload, { passive: true });
    window.addEventListener('touchstart', cancelPreload, { passive: true });
    window.addEventListener('scroll', cancelPreload, { passive: true });

    if (document.readyState === 'complete') {
      schedulePreload();
    } else {
      window.addEventListener('load', schedulePreload, { once: true });
    }

    return () => {
      cancelled = true;
      clearScheduledPreload();
      stopListeningForScrollIntent();
      window.removeEventListener('load', schedulePreload);
    };
  }, [preloadMenu]);

  useEffect(() => {
    if (typeof window === 'undefined') return undefined;

    const readClientTheme = () => {
      let nextDark = document.documentElement.classList.contains('dark');
      try { nextDark ||= window.localStorage.getItem(THEME_STORAGE_KEY) === 'true'; } catch { /* Theme storage is optional. */ }
      setEffectiveDarkMode(nextDark);
    };

    readClientTheme();
    window.addEventListener('sv:theme-change', readClientTheme);
    return () => window.removeEventListener('sv:theme-change', readClientTheme);
  }, []);

  const clearCloseTimer = useCallback(() => {
    if (!closeTimerRef.current) return;
    window.clearTimeout(closeTimerRef.current);
    closeTimerRef.current = null;
  }, []);

  const clearOpenFrame = useCallback(() => {
    if (!openFrameRef.current) return;
    window.cancelAnimationFrame(openFrameRef.current);
    openFrameRef.current = null;
  }, []);

  const unlockTransition = useCallback(() => {
    if (transitionLockTimerRef.current) {
      window.clearTimeout(transitionLockTimerRef.current);
      transitionLockTimerRef.current = null;
    }
    transitionLockedRef.current = false;
    setTransitionLocked(false);
  }, []);

  const lockTransition = useCallback((duration) => {
    transitionLockedRef.current = true;
    setTransitionLocked(true);
    if (transitionLockTimerRef.current) {
      window.clearTimeout(transitionLockTimerRef.current);
    }
    transitionLockTimerRef.current = window.setTimeout(() => {
      transitionLockedRef.current = false;
      setTransitionLocked(false);
      transitionLockTimerRef.current = null;
    }, duration);
  }, []);

  useEffect(() => () => {
    clearCloseTimer();
    clearOpenFrame();
    if (transitionLockTimerRef.current) {
      window.clearTimeout(transitionLockTimerRef.current);
      transitionLockTimerRef.current = null;
    }
    if (pointerOpenedTimerRef.current) {
      window.clearTimeout(pointerOpenedTimerRef.current);
      pointerOpenedTimerRef.current = null;
    }
  }, [clearCloseTimer, clearOpenFrame]);

  const presentPanel = useCallback(() => {
    clearCloseTimer();
    clearOpenFrame();
    syncCriticalAuthSnapshot();
    if (authState.user?.uid && !authState.user?.isAnonymous) {
      router.prefetch('/mes-commandes');
    }
    setHasPanelMounted(true);
    const isDesktopOpen = isDesktopMenuViewport();

    if (isDesktopOpen) {
      unlockTransition();
      setPanelClosing(false);
      setPanelOpen(true);
      return;
    }

    lockTransition(MENU_OPEN_LOCK_MS);
    setPanelClosing(false);
    setPanelOpen(false);
    openFrameRef.current = window.requestAnimationFrame(() => {
      setPanelOpen(true);
      openFrameRef.current = null;
    });
  }, [authState.user, clearCloseTimer, clearOpenFrame, lockTransition, router, syncCriticalAuthSnapshot, unlockTransition]);

  const openPanel = useCallback(() => {
    clearCloseTimer();
    clearOpenFrame();
    presentPanel();
  }, [clearCloseTimer, clearOpenFrame, presentPanel]);

  const closePanel = useCallback(() => {
    clearCloseTimer();
    clearOpenFrame();
    const isDesktopOpen = isDesktopMenuViewport();

    if (isDesktopOpen) {
      unlockTransition();
      setPanelOpen(false);
      setPanelClosing(true);
      closeTimerRef.current = window.setTimeout(() => {
        setPanelClosing(false);
        document.documentElement.classList.remove(DESKTOP_MENU_OPEN_CLASS);
        closeTimerRef.current = null;
      }, DESKTOP_MENU_CLOSE_MS);
      return;
    }

    lockTransition(MENU_CLOSE_LOCK_MS);
    setPanelOpen(false);
    setPanelClosing(true);
    closeTimerRef.current = window.setTimeout(() => {
      setPanelClosing(false);
      closeTimerRef.current = null;
    }, 540);
  }, [clearCloseTimer, clearOpenFrame, lockTransition, unlockTransition]);

  const closePanelInstantly = useCallback(() => {
    clearCloseTimer();
    clearOpenFrame();
    unlockTransition();
    setPanelOpen(false);
    setPanelClosing(false);
    setHeldNavigationPath(null);
    document.documentElement.classList.remove(DESKTOP_MENU_OPEN_CLASS);
  }, [clearCloseTimer, clearOpenFrame, unlockTransition]);

  useEffect(() => {
    if (!heldNavigationPath) return;
    if (pathname === heldNavigationPath || pathname?.startsWith(`${heldNavigationPath}/`)) {
      closePanelInstantly();
      setHeldNavigationPath(null);
    }
  }, [closePanelInstantly, heldNavigationPath, pathname]);

  useEffect(() => {
    if (!heldNavigationPath) return undefined;
    const timeoutId = window.setTimeout(closePanelInstantly, 10000);
    return () => window.clearTimeout(timeoutId);
  }, [closePanelInstantly, heldNavigationPath]);

  const setPanelOpenWithMotion = useCallback((nextValue) => {
    const resolvedValue = typeof nextValue === 'function' ? nextValue(panelOpen) : nextValue;
    if (resolvedValue) {
      if (transitionLockedRef.current && !isDesktopMenuViewport()) return;
      openPanel();
      return;
    }
    closePanel();
  }, [closePanel, openPanel, panelOpen]);

  const togglePanel = () => {
    if (pointerOpenedRef.current) {
      pointerOpenedRef.current = false;
      return;
    }
    if (panelClosing) {
      openPanel();
      return;
    }
    if (panelOpen) {
      closePanel();
      return;
    }
    if (transitionLockedRef.current && !isDesktopMenuViewport()) return;
    openPanel();
  };

  const handlePointerDown = (event) => {
    void preloadMenu();
    const isDesktopOpen = isDesktopMenuViewport();
    if (event.button !== undefined && event.button !== 0) return;
    if (isDesktopOpen) {
      if (panelOpen) return;
      pointerOpenedRef.current = true;
      if (pointerOpenedTimerRef.current) window.clearTimeout(pointerOpenedTimerRef.current);
      pointerOpenedTimerRef.current = window.setTimeout(() => {
        pointerOpenedRef.current = false;
        pointerOpenedTimerRef.current = null;
      }, 350);
      openPanel();
      return;
    }
    if (panelOpen || panelClosing || transitionLockedRef.current) return;

    pointerOpenedRef.current = true;
    openPanel();
  };

  const navigateCriticalDesktop = useCallback((path) => {
    if (!path) return;
    const targetPath = path.split(/[?#]/)[0] || '/';
    const isAlreadyOnTarget = pathname === targetPath || pathname?.startsWith(`${targetPath}/`);
    if (HOLD_MENU_UNTIL_ROUTE_PATHS.has(targetPath) && !isAlreadyOnTarget) {
      setHeldNavigationPath(targetPath);
      router.push(path);
      return;
    }
    closePanelInstantly();
    window.requestAnimationFrame(() => {
      router.push(path);
    });
  }, [closePanelInstantly, pathname, router]);

  const openCriticalDesktopLogin = useCallback(() => {
    closePanelInstantly();
    window.requestAnimationFrame(() => {
      window.dispatchEvent(new CustomEvent('sv:open-login'));
    });
  }, [closePanelInstantly]);

  const openCriticalDesktopCart = useCallback(() => {
    closePanelInstantly();
    window.requestAnimationFrame(() => {
      window.dispatchEvent(new CustomEvent('sv:open-cart'));
    });
  }, [closePanelInstantly]);

  useEffect(() => {
    window.addEventListener(CLOSE_NAVIGATION_OVERLAYS_EVENT, closePanelInstantly);
    return () => window.removeEventListener(CLOSE_NAVIGATION_OVERLAYS_EVENT, closePanelInstantly);
  }, [closePanelInstantly]);

  return (
    <>
      <button
        data-global-menu-trigger
        data-menu-preloaded={menuPreloaded ? 'true' : 'false'}
        type="button"
        onClick={togglePanel}
        onPointerDown={handlePointerDown}
        onPointerEnter={() => { void preloadMenu(true); }}
        onFocus={() => { void preloadMenu(true); }}
        aria-disabled={transitionLocked && !desktopMenuViewport}
        className={`relative mr-1 flex h-10 min-w-10 touch-manipulation items-center justify-center gap-2 rounded-full px-2.5 transition-all duration-150 ease-[cubic-bezier(0.32,0.72,0,1)] active:scale-[0.96] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#8B5C42]/25 dark:focus-visible:ring-[#D9B58D]/45 md:mr-0 md:px-3.5 ${effectiveDarkMode ? 'bg-white/[0.08] text-stone-100 ring-1 ring-white/[0.08] shadow-[inset_0_1px_0_rgba(255,255,255,0.08)] hover:bg-white/[0.14] hover:text-[#D9B58D]' : 'bg-white text-stone-900 shadow-sm shadow-stone-900/5 hover:text-[#8B5C42] dark:bg-white/[0.08] dark:text-stone-100 dark:ring-1 dark:ring-white/[0.08] dark:shadow-[inset_0_1px_0_rgba(255,255,255,0.08)] dark:hover:bg-white/[0.14] dark:hover:text-[#D9B58D]'}`}
        aria-label={panelOpen ? 'Fermer le menu' : 'Ouvrir le menu'}
        aria-expanded={panelOpen}
        aria-controls="global-menu-dialog"
      >
        <MenuIcon open={panelOpen} />
        <span className="hidden text-[10px] font-black uppercase tracking-[0.16em] md:inline">Menu</span>
      </button>
      {hasClientMounted && hasPanelMounted && typeof document !== 'undefined' ? createPortal(
        <Suspense fallback={null}>
          <GlobalMenu
            darkMode={effectiveDarkMode}
            isMenuOpen={panelOpen}
            isMenuClosing={panelClosing}
            keepMounted
            setIsMenuOpen={setPanelOpenWithMotion}
            currentView="gallery"
            user={authState.user}
            isAdmin={authState.claims.admin}
            onNavigate={navigateCriticalDesktop}
            onShowLogin={openCriticalDesktopLogin}
            onOpenWishlist={() => navigateCriticalDesktop('/wishlist')}
            onOpenCart={openCriticalDesktopCart}
            onLogout={() => {}}
          />
        </Suspense>,
        document.body
      ) : null}
    </>
  );
}
