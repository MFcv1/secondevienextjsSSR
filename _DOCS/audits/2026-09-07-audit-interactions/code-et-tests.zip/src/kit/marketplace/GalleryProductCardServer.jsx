import Link from 'next/link';
import { getProductUrl } from '../../utils/slug';
import { getProductCardImage, getProductDisplayImageSrc, getProductImageItems } from '../../utils/imageUtils';
import { getProductPriceAmount, getProductStockAmount, getPurchaseUnavailableLabel, isPurchasable, isSoldOut, shouldRequestQuote } from '../commerce/purchasability';
import { Heart, Plus } from 'lucide-react';
import ProductCardMediaServer, { ProductCardHoverOverlay, ProductSoldBadge } from './ProductCardMediaServer';

const formatPrice = (item) => {
  if (isSoldOut(item)) return 'VENDU';
  if (getProductStockAmount(item) <= 0) return getPurchaseUnavailableLabel(item);
  if (shouldRequestQuote(item)) return 'Sur demande';
  const price = getProductPriceAmount(item);
  return price ? `${Number(price).toLocaleString('fr-FR')} EUR` : '';
};

const getCartItemPayload = (item, cardImage, title) => ({
  originalId: item?.id || '',
  id: item?.id || '',
  collectionName: item?.collectionName || 'furniture',
  name: title,
  title,
  price: Number(item?.currentPrice || item?.startingPrice || item?.price || 0),
  stock: getProductStockAmount(item),
  sold: Boolean(item?.sold),
  priceOnRequest: Boolean(item?.priceOnRequest),
  image: cardImage?.src || item?.imageUrl || item?.thumbnailUrl || '',
  imageUrl: cardImage?.src || item?.imageUrl || item?.thumbnailUrl || '',
  material: item?.material || 'Bois',
  quantity: 1,
});

export default function GalleryProductCardServer({
  item,
  layoutMode = 'grid',
  isBig = false,
  compact = false,
  priority = false,
  darkMode = false,
} = {}) {
  const cardImage = getProductCardImage(item);
  const [primaryDetailImage] = getProductImageItems(item);
  const title = item?.name || item?.title || 'Piece restauree';
  const purchasable = isPurchasable(item);
  const soldOut = isSoldOut(item);
  const cartItem = getCartItemPayload(item, cardImage, title);
  const warmupImage = primaryDetailImage ? {
    detailFast: primaryDetailImage.detailFast || '',
    medium: primaryDetailImage.medium || '',
    card: primaryDetailImage.card || '',
    thumb: primaryDetailImage.thumb || '',
    src: primaryDetailImage.src || '',
  } : null;

  const productUrl = getProductUrl(item);
  const warmupSrc = getProductDisplayImageSrc(primaryDetailImage, { viewport: 'desktop' }) || warmupImage?.medium || warmupImage?.src || warmupImage?.card || warmupImage?.thumb || '';
  const cartPayload = JSON.stringify(cartItem);
  const wishlistPayload = JSON.stringify(cartItem);
  const productId = item?.id || '';

  return (
    <div
      className={`product-card-shell group relative flex touch-manipulation flex-col w-full text-inherit ${layoutMode === 'list' ? 'flex-row items-center gap-12 border-b border-stone-200 pb-12' : ''}`}
      data-gallery-product-card
      data-card-theme={darkMode ? 'dark' : undefined}
      data-card-sold={soldOut ? 'true' : undefined}
      data-product-id={productId || undefined}
      data-product-url={productUrl}
    >
      <div
        className={`product-card-media relative overflow-hidden ${layoutMode === 'list' ? 'w-1/3 aspect-[4/3]' : 'w-full aspect-[3/4]'} ${isBig ? 'md:aspect-[16/10]' : ''}`}
      >
        <Link href={productUrl} prefetch={false} draggable={false} data-gallery-product-link className="block h-full w-full cursor-pointer text-inherit no-underline" aria-label={`Découvrir ${title}`}>
          <ProductCardMediaServer
            cardImage={cardImage}
            alt={title}
            priority={priority}
            warmupSrc={warmupSrc}
            imageClassName="product-card-image h-full w-full object-cover"
          />

          <ProductCardHoverOverlay />
        </Link>

        {soldOut ? <ProductSoldBadge /> : null}

        {productId ? (
          <div className="product-card-actions absolute right-2 top-2 z-20 flex flex-col gap-1.5 opacity-100 transition-opacity duration-300 md:right-2.5 md:top-2.5 md:gap-2 lg:opacity-0 lg:group-hover:opacity-100">
            {purchasable ? (
              <button
                type="button"
                data-gallery-cart-button
                data-cart-item={cartPayload}
                className="flex h-8 w-8 items-center justify-center rounded-full bg-[#8B5C42] text-white shadow-md transition-colors hover:bg-[#6f4630] md:h-9 md:w-9"
                title="Ajouter au panier"
                aria-label="Ajouter au panier"
              >
                <Plus className="h-3.5 w-3.5 md:h-4 md:w-4" strokeWidth={2.5} />
              </button>
            ) : null}
            <button
              type="button"
              data-gallery-wishlist-button
              data-product-id={productId}
              data-wishlist-item={wishlistPayload}
              data-liked="false"
              aria-pressed="false"
              className="flex h-8 w-8 items-center justify-center rounded-full bg-white/90 text-stone-700 shadow-md transition-colors hover:bg-rose-500 hover:text-white data-[liked=true]:bg-rose-500 data-[liked=true]:text-white md:h-9 md:w-9"
              title="Ajouter a la liste de souhaits"
              aria-label="Ajouter a la liste de souhaits"
            >
              <Heart data-gallery-wishlist-heart className="h-[13px] w-[13px] md:h-[15px] md:w-[15px]" strokeWidth={2} fill="none" />
            </button>
          </div>
        ) : null}
      </div>

      <Link href={productUrl} prefetch={false} draggable={false} data-gallery-product-link className={`product-card-info flex cursor-pointer text-inherit no-underline ${compact ? 'flex-col gap-1 md:flex-row md:items-start md:justify-between md:gap-4' : 'items-start justify-between gap-2 md:gap-4'} ${layoutMode === 'list' ? 'flex-1 pt-6' : ''}`}>
        <div className="flex min-w-0 flex-1 flex-col gap-0.5 md:gap-1">
          <div className={`truncate font-black uppercase tracking-widest opacity-50 ${compact ? 'text-[8px] md:text-[9px]' : 'text-[9px]'}`}>
            {item?.material || 'Matiere inconnue'}
          </div>
          <h3 className={`font-serif leading-tight ${compact ? 'text-[13px] md:text-lg lg:text-xl' : 'text-[15px] md:text-lg lg:text-xl'} ${layoutMode === 'list' ? 'text-4xl' : ''}`}>
            {title}
          </h3>
        </div>

        <div className={`flex shrink-0 ${compact ? 'flex-row items-center justify-between md:flex-col md:items-end' : 'flex-col items-end'} gap-0.5 text-right md:gap-1`}>
          <div className={`whitespace-nowrap font-black uppercase tracking-widest opacity-50 ${compact ? 'text-[8px] md:text-[9px]' : 'text-[9px]'}`}>
            {soldOut ? 'Stock: 0' : `Stock: ${getProductStockAmount(item)}`}
          </div>
          <p className={`product-card-price whitespace-nowrap font-bold tabular-nums ${compact ? 'text-[10px] md:text-xs lg:text-sm' : 'text-[11px] md:text-xs lg:text-sm'}`}>
            {formatPrice(item)}
          </p>
        </div>
      </Link>
    </div>
  );
}
