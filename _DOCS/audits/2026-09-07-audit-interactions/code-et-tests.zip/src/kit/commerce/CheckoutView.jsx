import { lazy, Suspense, useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { ArrowLeft, CreditCard, Truck, AlertCircle, Landmark, Wallet, Loader2, TicketPercent, Check, X } from 'lucide-react';
import { motion } from 'framer-motion';
import { functions, db } from '../config/firebase';
import { getFunctionTarget } from '../config/functionTargets';
import KIT_CONFIG from '../config/constants';
import { httpsCallable } from 'firebase/functions';
import { doc, getDoc } from 'firebase/firestore';
import { useToast } from '../ui/Toast';
import { getPurchaseUnavailableLabel, isPurchasable } from './purchasability';
import { logClientPerf, startClientPerf } from '../shared/clientPerf';
import {
    COMMERCE_V2_CONSUMERS_ENABLED,
    createCheckoutV2,
    ensureCheckoutAnonymousIdentity,
    previewPromotionCodeV2,
    resumeCheckoutV2,
} from './commerceV2Client';
import { buildCheckoutV2Input } from './checkoutContract';
import { deliveryUnavailableReason } from './deliveryEligibility';
import { getCheckoutRequestIdentity, clearCheckoutRequestIdentity } from './checkoutRequestIdentity';
import { createCommerceCommandId, requestOrderCancellation } from './commerceCommandClient';
import { useCancellationConfirmation } from './CancellationConfirmation';
import {
    createCheckoutControllerState,
    reduceCheckoutController,
} from './checkoutController';
import {
    clearCheckoutRecoveryDescriptor,
    COMMERCE_V2_RECOVERY_ENABLED,
    createCheckoutRecoveryDescriptor,
    getCheckoutRecoveryOrderItems,
    getCheckoutRecoveryTerminalCartLines,
    getCheckoutRecoveryTerminalMessage,
    getCheckoutRecoveryTerminalReason,
    readCheckoutRecoveryDescriptor,
    writeCheckoutRecoveryDescriptor,
} from './checkoutRecovery';

const DELIVERY_SETTINGS_CACHE_KEY = 'secondevie:delivery-settings:v1';
const PAYMENT_SETTINGS_CACHE_KEY = 'paymentSettings';
const CheckoutStripeModal = lazy(() => import('./CheckoutStripeModal'));
const isLegalDocumentUrl = (value) => /^(?:https?:\/\/|\/)/i.test(String(value || '').trim());
const TERMS_URL = KIT_CONFIG.legalLinks.terms;
const PRIVACY_URL = KIT_CONFIG.legalLinks.privacy;
const LEGAL_DOCUMENTS_READY = isLegalDocumentUrl(TERMS_URL) && isLegalDocumentUrl(PRIVACY_URL);
const normalizeCheckoutEmail = (email) => String(email || '').trim().toLowerCase();
const getCheckoutItemsTotal = (items = []) => (
    items.reduce((sum, item) => sum + (Number(item.price) || 0) * (Number(item.quantity) || 1), 0)
);
const formatCheckoutEuros = (value) => new Intl.NumberFormat('fr-FR', {
    minimumFractionDigits: Number.isInteger(value) ? 0 : 2,
    maximumFractionDigits: 2
}).format(value);

const getCheckoutOtpError = (error, fallback) => {
    const code = String(error?.code || '').toLowerCase();
    if (code.includes('resource-exhausted') || code.includes('too-many-requests')) {
        return 'Trop de tentatives rapprochées. Patientez quelques minutes avant de réessayer.';
    }
    if (code.includes('network')) {
        return 'La connexion a été interrompue. Vérifiez votre réseau puis réessayez.';
    }
    return fallback;
};

const hasReliableEmailProvider = (user, checkoutEmail) => {
    if (!user || user.isAnonymous) return false;

    const normalizedCheckoutEmail = normalizeCheckoutEmail(checkoutEmail);
    const normalizedUserEmail = normalizeCheckoutEmail(user.email);

    if (!normalizedCheckoutEmail || normalizedCheckoutEmail !== normalizedUserEmail) {
        return false;
    }

    return user.emailVerified === true;
};

const PremiumActionBtn = ({ children, isLoading, disabled, onClick, darkMode }) => {
    const bgColor = darkMode ? 'bg-stone-900' : 'bg-white';
    const disabledBg = darkMode ? 'bg-stone-900/50' : 'bg-stone-100';

    return (
        <motion.button
            layout
            onClick={onClick}
            disabled={disabled || isLoading}
            whileTap={!disabled && !isLoading ? { scale: 0.985 } : {}}
            transition={{ layout: { type: 'spring', stiffness: 450, damping: 35 } }}
            className={`relative mx-auto flex h-[64px] w-full items-center justify-center gap-3 overflow-hidden rounded-[1.25rem] px-4 py-0 text-sm font-black uppercase tracking-widest outline-none transition-colors duration-300
                ${isLoading ? 'cursor-wait' : 'cursor-pointer'}
                ${disabled
                    ? `${disabledBg} ${darkMode ? 'text-stone-600 border border-stone-800/50' : 'text-stone-400 border border-stone-200'} opacity-60`
                    : `${bgColor} ${darkMode ? 'text-white' : 'text-stone-900'} shadow-[0_8px_30px_rgba(0,0,0,0.15)]`
                }
            `}
        >
            {isLoading ? <Loader2 size={18} className="relative animate-spin opacity-70" /> : null}
            <span className="relative z-10 flex items-center justify-center gap-3 whitespace-nowrap">
                {isLoading ? 'Préparation…' : children}
            </span>
            {isLoading ? (
                <span className={`absolute inset-x-0 bottom-0 h-1 ${darkMode ? 'bg-stone-700' : 'bg-stone-300'}`}>
                    <span className="sv-auth-loading-bar block h-full w-1/2 bg-emerald-400" />
                </span>
            ) : null}
        </motion.button>
    );
};

/**
 * CheckoutView — Flow Single Page Premium (Mars 2026)
 * Tout sur la même page : formulaire au-dessus, choix du paiement, et Stripe injecté en dessous.
 */
const CheckoutView = ({
    cartItems,
    user,
    darkMode = false,
    onBack,
    onPlaceOrder,
    fixtureContext = null,
    recoveryExpected = false,
    onRecoveryTerminal = null,
    onCheckoutReserved = null
}) => {
    const toast = useToast();
    const { confirmCancellation, confirmation } = useCancellationConfirmation();
    // --- STATE ---
    const [formData, setFormData] = useState(() => {
        const defaults = {
        fullName: user?.displayName || '',
        email: user?.email || '',
        phone: user?.phoneNumber || '',
        address: '',
        city: '',
        zip: '',
        country: 'France',
        deliveryMode: 'retrait'
        };
        try {
            const saved = JSON.parse(window.sessionStorage.getItem(`secondevie:checkout-form:${user?.uid || 'guest'}`) || 'null');
            return saved ? { ...defaults, ...saved } : defaults;
        } catch { return defaults; }
    });
    useEffect(() => {
        try { window.sessionStorage.setItem(`secondevie:checkout-form:${user?.uid || 'guest'}`, JSON.stringify(formData)); } catch { /* Optional local draft. */ }
    }, [formData, user?.uid]);
    
    const [rgpdAccepted, setRgpdAccepted] = useState(false);
    
    // Default delivery modes
    const [deliverySettings, setDeliverySettings] = useState({
        retrait: { id: 'retrait', active: true, label: "Retrait à l'atelier (Marseille)", sub: "Sur rendez-vous", price: 0 },
        idf: { id: 'idf', active: true, label: "Livraison Marseille & Alentours", sub: "Par nos soins", price: 49 },
        transporteur: { id: 'transporteur', active: true, label: "Transporteur Spécialisé (Cocolis)", sub: "Protections sur-mesure", price: 90 }
    });

    useEffect(() => {
        let mounted = true;
        try {
            const cached = localStorage.getItem(DELIVERY_SETTINGS_CACHE_KEY);
            if (cached) setDeliverySettings(prev => ({ ...prev, ...JSON.parse(cached) }));
        } catch {
            // Cache optional.
        }

        getDoc(doc(db, 'sys_metadata', 'delivery')).then((snap) => {
            if (!mounted || !snap.exists()) return;
            const data = snap.data();
            setDeliverySettings(prev => ({ ...prev, ...data }));
            try {
                localStorage.setItem(DELIVERY_SETTINGS_CACHE_KEY, JSON.stringify(data));
            } catch {
                // Cache optional.
            }
        }).catch((error) => {
            console.error('Delivery settings load error:', error);
        });

        return () => { mounted = false; };
    }, []);

    const [stripeEnabled, setStripeEnabled] = useState(() => {
        if (COMMERCE_V2_CONSUMERS_ENABLED) return true;
        try { const c = localStorage.getItem('paymentSettings'); if (c) return JSON.parse(c).stripeEnabled !== false; } catch { /* ignore error */ }
        return true;
    });
    const [paymentMethod, setPaymentMethod] = useState('stripe_elements'); // 'stripe_elements' | 'deferred'

    // Lecture simple du flag admin pour carte/wallets; un refresh suffit si le reglage change.
    useEffect(() => {
        let mounted = true;
        getDoc(doc(db, 'sys_metadata', 'payment_settings')).then((snap) => {
            if (!mounted || !snap.exists()) return;
            const enabled = COMMERCE_V2_CONSUMERS_ENABLED || snap.data().stripeEnabled !== false;
            try {
                localStorage.setItem(PAYMENT_SETTINGS_CACHE_KEY, JSON.stringify({ stripeEnabled: enabled }));
            } catch {
                // Cache optional.
            }
            setStripeEnabled(enabled);
            if (!enabled && !COMMERCE_V2_CONSUMERS_ENABLED) {
                setPaymentMethod('deferred');
            }
        }).catch((error) => {
            console.error('Payment settings load error:', error);
        });
        return () => { mounted = false; };
    }, []);

    // Status global : 'editing' -> 'fetching_stripe' -> 'ready_to_pay' -> 'processing_deferred' -> 'order_success'
    const [checkoutState, setCheckoutState] = useState(
        recoveryExpected ? 'fetching_stripe' : 'editing'
    );
    const checkoutControllerRef = useRef(createCheckoutControllerState());
    
    const [clientSecret, setClientSecret] = useState(null);
    const [reservationExpiresAt, setReservationExpiresAt] = useState(null);
    const [providerStatus, setProviderStatus] = useState(null);
    const actionInFlightRef = useRef(false);
    const cancellationIdRef = useRef(null);
    const mountedRef = useRef(true);
    useEffect(() => {
        mountedRef.current = true;
        return () => { mountedRef.current = false; };
    }, []);
    const [createdOrderId, setCreatedOrderId] = useState(null);
    const [createdOrderNumber, setCreatedOrderNumber] = useState(null);
    const [createdOrderOtpToken, setCreatedOrderOtpToken] = useState('');
    const [createdStripeConnectedAccountId, setCreatedStripeConnectedAccountId] = useState('');
    const [lockedOrderDraft, setLockedOrderDraft] = useState(null);
    const [recoveredOrderTotal, setRecoveredOrderTotal] = useState(null);
    const [authoritativeShippingCost, setAuthoritativeShippingCost] = useState(null);
    const [authoritativeDiscount, setAuthoritativeDiscount] = useState(null);
    const [promotionCode, setPromotionCode] = useState('');
    const [promotionPreview, setPromotionPreview] = useState(null);
    const [promotionStatus, setPromotionStatus] = useState('idle');
    const [promotionError, setPromotionError] = useState('');
    const [paymentResumeNotice, setPaymentResumeNotice] = useState('');
    const [priceOverrides, setPriceOverrides] = useState({});
    const [unavailableItems, setUnavailableItems] = useState([]);
    const [isCleaningUp] = useState(false);
    const checkoutClientOrderIdRef = useRef(null);
    const [guestOtp, setGuestOtp] = useState({
        status: 'idle',
        email: '',
        code: '',
        token: '',
        error: ''
    });
    const guestOtpVerifyInFlightRef = useRef(false);
    const checkoutRecoveryAttemptedRef = useRef(false);

    const normalizedCheckoutEmail = normalizeCheckoutEmail(formData.email);
    const requiresGuestCheckoutOtp = !hasReliableEmailProvider(user, formData.email);
    const hasVerifiedGuestCheckoutOtp = !requiresGuestCheckoutOtp || (
        guestOtp.status === 'verified'
        && guestOtp.email === normalizedCheckoutEmail
        && Boolean(guestOtp.token)
    );
    const hasVerifiedCheckoutEmail = hasVerifiedGuestCheckoutOtp;
    const isCheckoutLocked = Boolean(createdOrderId) || ['fetching_stripe', 'ready_to_pay', 'payment_paused', 'processing_deferred', 'order_success'].includes(checkoutState);
    const currentCartItems = useMemo(() => cartItems.map((item) => {
        const id = String(item.originalId || item.id || '');
        return Object.prototype.hasOwnProperty.call(priceOverrides, id)
            ? { ...item, price: priceOverrides[id] }
            : item;
    }), [cartItems, priceOverrides]);
    const currentSubtotal = useMemo(() => getCheckoutItemsTotal(currentCartItems), [currentCartItems]);
    const promotionCartSignature = useMemo(() => JSON.stringify(currentCartItems.map((item) => ({
        id: item.originalId || item.productId || item.id,
        quantity: Number(item.quantity || 1),
        revision: Number(item.cartRevision || 0)
    }))), [currentCartItems]);
    const promotionCartSignatureRef = useRef(null);
    const checkoutItems = isCheckoutLocked && lockedOrderDraft?.items?.length ? lockedOrderDraft.items : currentCartItems;
    const checkoutSubtotal = isCheckoutLocked && lockedOrderDraft ? lockedOrderDraft.subtotal : currentSubtotal;
    const selectedDelivery = formData.deliveryMode && !deliveryUnavailableReason(formData.deliveryMode, formData.zip) ? deliverySettings[formData.deliveryMode] : null;
    useEffect(() => {
        if (!createdOrderId && !isCheckoutLocked && deliveryUnavailableReason(formData.deliveryMode, formData.zip)) {
            setFormData(previous => ({ ...previous, deliveryMode: '' }));
        }
    }, [createdOrderId, isCheckoutLocked, formData.deliveryMode, formData.zip]);
    const shippingCost = selectedDelivery ? selectedDelivery.price : 0;
    const displayedShippingCost = authoritativeShippingCost ?? shippingCost;
    const displayedDiscount = authoritativeDiscount ?? ((promotionPreview?.discountCents || 0) / 100);
    const finalTotal = recoveredOrderTotal ?? Math.max(0, checkoutSubtotal + shippingCost - displayedDiscount);
    const getCheckoutClientOrderId = () => {
        if (!checkoutClientOrderIdRef.current) {
            const randomPart = window.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(36).slice(2)}`;
            checkoutClientOrderIdRef.current = `checkout_${randomPart}`;
        }
        return checkoutClientOrderIdRef.current;
    };
    const resetCheckoutClientOrderId = useCallback(() => {
        clearCheckoutRequestIdentity(user?.uid, checkoutClientOrderIdRef.current);
        checkoutClientOrderIdRef.current = null;
    }, [user?.uid]);
    const advanceCheckoutController = (event) => {
        checkoutControllerRef.current = reduceCheckoutController(
            checkoutControllerRef.current,
            event,
            { enabled: COMMERCE_V2_CONSUMERS_ENABLED }
        );
        return checkoutControllerRef.current;
    };
    const resetTerminalCheckoutRecovery = useCallback((reason, descriptor = null) => {
        clearCheckoutRequestIdentity(descriptor?.ownerUid, descriptor?.clientOrderId);
        clearCheckoutRecoveryDescriptor({ enabled: COMMERCE_V2_RECOVERY_ENABLED, ownerUid: descriptor?.ownerUid, orderId: descriptor?.orderId });
        checkoutControllerRef.current = createCheckoutControllerState();
        checkoutClientOrderIdRef.current = null;
        setClientSecret(null);
        setCreatedOrderId(null);
        setCreatedOrderNumber(null);
        setCreatedOrderOtpToken('');
        setCreatedStripeConnectedAccountId('');
        setLockedOrderDraft(null);
        setRecoveredOrderTotal(null);
        setAuthoritativeShippingCost(null);
        setAuthoritativeDiscount(null);
        setPaymentResumeNotice(getCheckoutRecoveryTerminalMessage(reason));
        setCheckoutState('editing');
        onRecoveryTerminal?.(
            reason,
            getCheckoutRecoveryTerminalCartLines(reason, descriptor),
            descriptor?.orderId
        );
    }, [onRecoveryTerminal]);

    const hasPendingV2Payment = Boolean(
        COMMERCE_V2_CONSUMERS_ENABLED
        && !['succeeded', 'canceled'].includes(checkoutControllerRef.current.status)
        && createdOrderId
    );

    const openExistingPayment = async () => {
        if (!hasPendingV2Payment) return false;
        setCheckoutState('fetching_stripe');
        setPaymentResumeNotice('');
        try {
            const resumed = await resumeCheckoutV2(createdOrderId);
            if (!mountedRef.current) return true;
            if (resumed) {
                setReservationExpiresAt(resumed.expiresAt);
                setProviderStatus(resumed.providerStatus);
                setClientSecret(resumed.clientSecret);
                setRecoveredOrderTotal(Number.isSafeInteger(resumed.totalCents)
                    ? resumed.totalCents / 100
                    : null);
                setAuthoritativeShippingCost(Number.isSafeInteger(resumed.shippingCents)
                    ? resumed.shippingCents / 100
                    : null);
                setAuthoritativeDiscount(Number.isSafeInteger(resumed.discountCents)
                    ? resumed.discountCents / 100
                    : null);
                if (resumed.promotion) {
                    setPromotionCode(resumed.promotion.code || '');
                    setPromotionPreview({
                        ...resumed.promotion,
                        discountCents: resumed.discountCents
                    });
                }
                setCreatedStripeConnectedAccountId(resumed.connectedAccountId || '');
                setCreatedOrderNumber(Number.isSafeInteger(resumed.orderNumber) ? resumed.orderNumber : null);
            }
            setCheckoutState('ready_to_pay');
        } catch (error) {
            if (!mountedRef.current) return true;
            const terminalReason = getCheckoutRecoveryTerminalReason(error);
            if (terminalReason) {
                resetTerminalCheckoutRecovery(terminalReason, {
                    cartLines: lockedOrderDraft?.purchasedCartLines || []
                });
                return true;
            }
            console.error('Checkout payment resume failed:', error);
            setCheckoutState('payment_paused');
            setPaymentResumeNotice(
                error?.details?.reason === 'COMMERCE_CHECKOUT_DEADLINE_REACHED'
                    ? 'Le délai de réservation est terminé. Consultez le dossier : un paiement engagé peut encore être en cours de vérification.'
                    : 'L’état du paiement doit être vérifié avant de reprendre. Réessayez ou consultez le dossier.'
            );
        }
        return true;
    };

    const applyPromotionCode = async () => {
        if (isCheckoutLocked || promotionStatus === 'loading') return;
        const normalized = promotionCode.trim().toUpperCase();
        if (!normalized) return;
        setPromotionStatus('loading');
        setPromotionError('');
        try {
            const preview = await previewPromotionCodeV2(normalized, currentCartItems);
            setPromotionCode(preview.code);
            setPromotionPreview(preview);
            promotionCartSignatureRef.current = promotionCartSignature;
            setPromotionStatus('applied');
        } catch (error) {
            setPromotionPreview(null);
            setPromotionStatus('error');
            setPromotionError(error?.message || 'Ce code ne peut pas être appliqué à ce panier.');
        }
    };

    useEffect(() => {
        if (!promotionPreview || !promotionCartSignatureRef.current) return;
        if (promotionCartSignatureRef.current !== promotionCartSignature && !isCheckoutLocked) {
            setPromotionPreview(null);
            setPromotionStatus('idle');
            setPromotionError('Le panier a changé. Appliquez de nouveau le code.');
            setAuthoritativeDiscount(null);
            resetCheckoutClientOrderId();
        }
    }, [isCheckoutLocked, promotionCartSignature, promotionPreview, resetCheckoutClientOrderId]);

    const clearPromotionCode = () => {
        if (isCheckoutLocked) return;
        setPromotionCode('');
        setPromotionPreview(null);
        setPromotionStatus('idle');
        setPromotionError('');
        setAuthoritativeDiscount(null);
        resetCheckoutClientOrderId();
    };

    useEffect(() => {
        if (!COMMERCE_V2_CONSUMERS_ENABLED || typeof window === 'undefined') return undefined;
        if (checkoutRecoveryAttemptedRef.current) return undefined;
        const params = new URLSearchParams(window.location.search);
        if (params.get('order_success') === 'true') return undefined;
        checkoutRecoveryAttemptedRef.current = true;

        let cancelled = false;
        const restorePayment = async () => {
            let descriptor = null;
            try {
                const identity = await ensureCheckoutAnonymousIdentity();
                if (cancelled) return;
                descriptor = readCheckoutRecoveryDescriptor(identity.uid, {
                    enabled: COMMERCE_V2_RECOVERY_ENABLED
                });
                if (!descriptor) return;

                checkoutControllerRef.current = reduceCheckoutController(
                    createCheckoutControllerState(),
                    {
                        type: 'RESTORE',
                        orderId: descriptor.orderId,
                        clientOrderId: descriptor.clientOrderId
                    },
                    { enabled: COMMERCE_V2_CONSUMERS_ENABLED }
                );
                checkoutClientOrderIdRef.current = descriptor.clientOrderId;
                setCreatedOrderId(descriptor.orderId);
                setCheckoutState('fetching_stripe');

                const resumed = await resumeCheckoutV2(descriptor.orderId);
                if (cancelled) return;
                setReservationExpiresAt(resumed.expiresAt);
                setProviderStatus(resumed.providerStatus);
                if (resumed.shippingAddress) setFormData({
                    ...resumed.shippingAddress,
                    address: resumed.shippingAddress.line1 || '',
                    zip: resumed.shippingAddress.postalCode || '',
                    email: resumed.customerEmail || '',
                    deliveryMode: ({ 'delivery-pickup': 'retrait', 'delivery-local': 'idf', 'delivery-carrier': 'transporteur' })[resumed.deliveryModeId] || resumed.deliveryModeId,
                });
                const recoveredItems = getCheckoutRecoveryOrderItems(resumed);
                const recoveredSubtotal = recoveredItems.reduce(
                    (sum, item) => sum + (item.price * item.quantity),
                    0
                );
                setLockedOrderDraft({
                    items: recoveredItems,
                    subtotal: recoveredSubtotal,
                    purchasedCartLines: descriptor.cartLines
                });
                setClientSecret(resumed.clientSecret);
                setRecoveredOrderTotal(Number.isSafeInteger(resumed.totalCents)
                    ? resumed.totalCents / 100
                    : null);
                setAuthoritativeShippingCost(Number.isSafeInteger(resumed.shippingCents)
                    ? resumed.shippingCents / 100
                    : null);
                setAuthoritativeDiscount(Number.isSafeInteger(resumed.discountCents)
                    ? resumed.discountCents / 100
                    : null);
                if (resumed.promotion) {
                    setPromotionCode(resumed.promotion.code || '');
                    setPromotionPreview({ ...resumed.promotion, discountCents: resumed.discountCents });
                }
                setCreatedStripeConnectedAccountId(resumed.connectedAccountId || '');
                setPaymentResumeNotice('Votre commande vous attend. Vous pouvez reprendre le paiement là où vous l’aviez laissé.');
                setCheckoutState('ready_to_pay');
            } catch (error) {
                if (cancelled) return;
                const terminalReason = getCheckoutRecoveryTerminalReason(error);
                if (terminalReason) {
                    resetTerminalCheckoutRecovery(terminalReason, descriptor);
                    return;
                }
                console.error('Checkout recovery failed:', error);
                if (checkoutControllerRef.current.status === 'awaiting_method') {
                    setCheckoutState('payment_paused');
                    setPaymentResumeNotice(
                        error?.details?.reason === 'COMMERCE_CHECKOUT_DEADLINE_REACHED'
                            ? 'Le délai de réservation est terminé. Consultez le dossier pour vérifier le paiement.'
                            : 'L’état du paiement doit être vérifié. Utilisez « Reprendre le paiement » ou consultez le dossier.'
                    );
                }
            }
        };

        void restorePayment();
        return () => {
            cancelled = true;
            checkoutRecoveryAttemptedRef.current = false;
        };
    }, [resetTerminalCheckoutRecovery]);

    // Quitter l'ecran Stripe ne compense jamais une operation ambigue et ne
    // detruit plus les informations permettant de reprendre le meme PaymentIntent.
    const handleClosePaymentModal = () => {
        setPaymentResumeNotice(
            'Retrouvez les informations de votre commande. La reprise vérifiera l’état du paiement et le délai restant.'
        );
        setCheckoutState('payment_paused');
    };
    const leaveCheckout = async () => {
        if (actionInFlightRef.current) return;
        if (!createdOrderId) { onBack(); return; }
        actionInFlightRef.current = true;
        if (!await confirmCancellation()) { actionInFlightRef.current = false; return; }
        if (!mountedRef.current) return;
        cancellationIdRef.current ||= createCommerceCommandId('cancel');
        try {
            const result = await requestOrderCancellation(createdOrderId, 'Annulation explicite depuis le checkout', cancellationIdRef.current);
            if (!mountedRef.current) return;
            if (result.outcome === 'canceled') {
                clearCheckoutRecoveryDescriptor({ ownerUid: user?.uid, orderId: createdOrderId });
                resetCheckoutClientOrderId();
                onBack();
            } else if (result.outcome === 'paid') {
                await onPlaceOrder({ id: createdOrderId, orderNumber: createdOrderNumber, paymentMethod: 'stripe_elements', purchasedCartLines: lockedOrderDraft?.purchasedCartLines || [] });
            } else setPaymentResumeNotice('Le paiement est en cours de vérification. Consultez le dossier.');
        } catch {
            if (mountedRef.current) setPaymentResumeNotice('L’annulation reste à vérifier. Consultez le dossier avant de réessayer.');
        } finally { actionInFlightRef.current = false; }
    };
    
    // --- ADDRESS AUTOCOMPLETE ---
    const [suggestions, setSuggestions] = useState([]);
    const [showSuggestions, setShowSuggestions] = useState(false);
    const suggestionRef = useRef(null);   // container div des inputs adresse
    const addressInputRef = useRef(null); // input adresse uniquement (pour position dropdown)
    const dropdownRef = useRef(null);     // portal dropdown (pour handleClickOutside)
    const searchTimeout = useRef(null);
    const addressRequestRef = useRef(null);
    const [dropdownPos, setDropdownPos] = useState({ mobile: false, top: 0, left: 0, width: 0 });

    const updateDropdownPosition = () => {
        if (window.innerWidth < 768) {
            // Mobile : bottom sheet ancré au bas du visual viewport, au-dessus du clavier
            setDropdownPos({ mobile: true });
            return;
        }
        // Desktop : dropdown positionné sous l'input
        const el = addressInputRef.current;
        if (!el) return;
        const rect = el.getBoundingClientRect();
        const vvTop = window.visualViewport ? window.visualViewport.offsetTop : 0;
        const vvLeft = window.visualViewport ? window.visualViewport.offsetLeft : 0;
        setDropdownPos({
            mobile: false,
            top: rect.bottom + 4 - vvTop,
            left: rect.left - vvLeft,
            width: rect.width,
        });
    };

    useEffect(() => {
        const handleClickOutside = (event) => {
            const insideInput = suggestionRef.current && suggestionRef.current.contains(event.target);
            const insideDropdown = dropdownRef.current && dropdownRef.current.contains(event.target);
            if (!insideInput && !insideDropdown) {
                setShowSuggestions(false);
            }
        };
        document.addEventListener('pointerdown', handleClickOutside);
        return () => {
            document.removeEventListener('pointerdown', handleClickOutside);
            window.clearTimeout(searchTimeout.current);
            addressRequestRef.current?.abort();
        };
    }, []);

    useEffect(() => {
        if (!showSuggestions) return;
        const update = () => updateDropdownPosition();
        window.addEventListener('scroll', update, true);
        window.addEventListener('resize', update);
        if (window.visualViewport) {
            window.visualViewport.addEventListener('resize', update);
            window.visualViewport.addEventListener('scroll', update);
        }
        return () => {
            window.removeEventListener('scroll', update, true);
            window.removeEventListener('resize', update);
            if (window.visualViewport) {
                window.visualViewport.removeEventListener('resize', update);
                window.visualViewport.removeEventListener('scroll', update);
            }
        };
    }, [showSuggestions]);

    const fetchAddresses = async (query) => {
        addressRequestRef.current?.abort();
        const request = new AbortController();
        addressRequestRef.current = request;
        if (!query || query.length < 3) {
            setSuggestions([]);
            setShowSuggestions(false);
            return;
        }
        try {
            const res = await fetch(`https://api-adresse.data.gouv.fr/search/?q=${encodeURIComponent(query)}&limit=5`, { signal: request.signal });
            if (!res.ok) throw new Error('ADDRESS_SEARCH_UNAVAILABLE');
            const data = await res.json();
            if (request.signal.aborted) return;
            setSuggestions(data.features || []);
            updateDropdownPosition();
            setShowSuggestions(true);
        } catch (e) {
            if (request.signal.aborted) return;
            console.error("API Adresse error:", e);
        }
    };

    const handleAddressRelatedChange = (e) => {
        if (isCheckoutLocked) return;
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
        if (checkoutState === 'ready_to_pay') setCheckoutState('editing');

        // Build query using the latest value for the changed field
        const newForm = { ...formData, [name]: value };
        const query = [newForm.address, newForm.zip, newForm.city].filter(Boolean).join(' ');

        if (searchTimeout.current) clearTimeout(searchTimeout.current);
        addressRequestRef.current?.abort();
        searchTimeout.current = setTimeout(() => {
            fetchAddresses(query);
        }, 400);
    };

    const handleSelectSuggestion = (suggestion) => {
        if (isCheckoutLocked) return;
        window.clearTimeout(searchTimeout.current);
        addressRequestRef.current?.abort();
        const zipValue = suggestion.properties.postcode || '';
        const cityValue = suggestion.properties.city || '';
        const addressValue = suggestion.properties.name || '';

        setFormData(prev => ({
            ...prev,
            address: addressValue,
            zip: zipValue,
            city: cityValue
        }));
        setSuggestions([]);
        setShowSuggestions(false);
    };

    // --- TEMPS RÉEL : SURVEILLANCE STOCK ---
    useEffect(() => {
        if (cartItems.length === 0) return;
        if (fixtureContext) {
            // Les fixtures Gate 8 sont volontairement exclues du snapshot public.
            // Le callable v2 revalide scope, UID, prix et stock cote serveur.
            setUnavailableItems([]);
            return;
        }

        let cancelled = false;
        Promise.all(cartItems.map(async (item) => {
            const id = item.originalId || item.id;
            const response = await fetch(`/api/catalog?id=${encodeURIComponent(id)}`, {
                cache: 'no-store',
                headers: { accept: 'application/json' }
            });
            if (response.status === 404) return { item, product: null, deleted: true };
            if (!response.ok) return { item, skipped: true };
            const payload = await response.json();
            return { item, product: payload?.product || null };
        })).then((results) => {
            if (cancelled) return;
            setUnavailableItems(results.flatMap(({ item, product, deleted, skipped }) => {
                if (skipped || (product && isPurchasable(product))) return [];
                return [{
                    id: item.id,
                    name: item.name,
                    reason: deleted ? 'deleted' : getPurchaseUnavailableLabel(product)
                }];
            }));
        }).catch((error) => {
            console.error('Checkout catalog verification error:', error);
        });

        return () => { cancelled = true; };
    }, [cartItems, fixtureContext]);

    // --- ON CHANGE FORM ---
    const handleChange = (e) => {
        if (isCheckoutLocked) return;
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
        if (name === 'email') {
            setGuestOtp({
                status: 'idle',
                email: '',
                code: '',
                token: '',
                error: ''
            });
        }
        if (checkoutState === 'ready_to_pay') {
            setCheckoutState('editing');
        }
    };

    const handleOtpCodeChange = (e) => {
        const code = e.target.value.replace(/\D/g, '').slice(0, 6);
        setGuestOtp(prev => ({ ...prev, code, error: '' }));
        if (code.length === 6 && !guestOtpVerifyInFlightRef.current && guestOtp.status !== 'verified') {
            window.setTimeout(() => verifyGuestCheckoutOtp(code), 0);
        }
    };

    const isFormValid = useMemo(() => {
        const regexEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return formData.fullName.trim() && 
               regexEmail.test(formData.email.trim()) && 
               formData.phone.trim() &&
               formData.address.trim() && formData.city.trim() && formData.zip.trim() &&
               rgpdAccepted && formData.deliveryMode && !deliveryUnavailableReason(formData.deliveryMode, formData.zip);
    }, [formData, rgpdAccepted]);

    const isOtpEmailReady = useMemo(() => {
        const regexEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regexEmail.test(formData.email.trim());
    }, [formData.email]);

    const sendGuestCheckoutOtp = async () => {
        if (!isOtpEmailReady) {
            setGuestOtp(prev => ({ ...prev, error: 'Saisissez un email valide avant de demander le code.' }));
            return;
        }

            setGuestOtp(prev => ({
                ...prev,
                status: 'sending',
                email: normalizedCheckoutEmail,
                code: '',
                token: '',
                error: ''
            }));

        const startedAt = startClientPerf();
        try {
            const sendOtp = httpsCallable(functions, getFunctionTarget('sendGuestCheckoutOtp'));
            await sendOtp({ email: normalizedCheckoutEmail });
            logClientPerf('checkout.guest.sendGuestCheckoutOtp', startedAt, { phase: 'success' });
            setGuestOtp(prev => ({
                ...prev,
                status: 'sent',
                email: normalizedCheckoutEmail,
                code: '',
                token: '',
                error: ''
            }));
            toast('Code envoye. Verifiez aussi vos courriers indesirables.', { type: 'success' });
        } catch (error) {
            logClientPerf('checkout.guest.sendGuestCheckoutOtp', startedAt, {
                phase: 'error',
                code: error?.code || null
            });
            console.error('Guest checkout OTP send error:', error);
            const message = getCheckoutOtpError(error, "Impossible d’envoyer le code pour le moment.");
            setGuestOtp(prev => ({
                ...prev,
                status: 'idle',
                error: message
            }));
            toast(message, { type: 'error' });
        }
    };

    const verifyGuestCheckoutOtp = async (codeOverride = '') => {
        const code = codeOverride || guestOtp.code;
        if (guestOtpVerifyInFlightRef.current) return;
        if (code.length !== 6) {
            setGuestOtp(prev => ({ ...prev, error: 'Le code doit contenir 6 chiffres.' }));
            return;
        }

        guestOtpVerifyInFlightRef.current = true;
        setGuestOtp(prev => ({ ...prev, status: 'verifying', error: '' }));
        const startedAt = startClientPerf();

        try {
            const verifyOtp = httpsCallable(functions, getFunctionTarget('verifyGuestCheckoutOtp'));
            const result = await verifyOtp({
                email: normalizedCheckoutEmail,
                code
            });
            logClientPerf('checkout.guest.verifyGuestCheckoutOtp', startedAt, { phase: 'success' });
            if (!result.data?.success) {
                throw new Error('Validation OTP incomplete.');
            }
            setGuestOtp(prev => ({
                ...prev,
                status: 'verified',
                email: normalizedCheckoutEmail,
                token: result.data?.checkoutOtpToken || '',
                error: ''
            }));
            toast('Email verifie.', { type: 'success' });
        } catch (error) {
            logClientPerf('checkout.guest.verifyGuestCheckoutOtp', startedAt, {
                phase: 'error',
                code: error?.code || null
            });
            console.error('Guest checkout OTP verify error:', error);
            const message = getCheckoutOtpError(error, 'Le code est incorrect ou a expiré.');
            setGuestOtp(prev => ({
                ...prev,
                status: 'sent',
                error: message
            }));
            toast(message, { type: 'error' });
        } finally {
            guestOtpVerifyInFlightRef.current = false;
        }
    };

    // --- SUBMIT ACTION : FETCH STRIPE OU CONFIRM DEFERRED ---
    const handleActionClick = async () => {
        if (actionInFlightRef.current) return;
        actionInFlightRef.current = true;
        try {
            await performCheckoutAction();
        } finally {
            actionInFlightRef.current = false;
        }
    };
    const performCheckoutAction = async () => {
        if (await openExistingPayment()) return;
        if (!isFormValid) return;
        if (cartItems.length === 0) {
            toast('Votre panier est vide.', { type: 'warning' });
            return;
        }
        if (requiresGuestCheckoutOtp && !hasVerifiedGuestCheckoutOtp) {
            toast('Validez le code envoye par email avant de confirmer la commande.', { type: 'warning' });
            return;
        }
        if (unavailableItems.length > 0) {
            toast("Attention : Un article de votre panier n'est plus disponible.", { type: 'warning' });
            return;
        }

        const itemsWithCol = currentCartItems.map(i => ({
            ...i,
            collectionName: i.collectionName || 'furniture'
        }));
        const draftSubtotal = getCheckoutItemsTotal(itemsWithCol);
        setLockedOrderDraft({
            items: itemsWithCol,
            subtotal: draftSubtotal
        });
        setRecoveredOrderTotal(null);
        setAuthoritativeShippingCost(null);
        setAuthoritativeDiscount(null);

        if (paymentMethod === 'stripe_elements') {
            setCheckoutState('fetching_stripe');
        } else {
            setCheckoutState('processing_deferred');
        }

        const createOrderStartedAt = startClientPerf();
        try {
            if (COMMERCE_V2_CONSUMERS_ENABLED) {
                if (paymentMethod !== 'stripe_elements') {
                    throw new Error('COMMERCE_V2_OFFLINE_PAYMENT_DISABLED');
                }
                const identity = await ensureCheckoutAnonymousIdentity();
                if (!mountedRef.current) return;
                checkoutClientOrderIdRef.current ||= await getCheckoutRequestIdentity(identity.uid, {
                    items: itemsWithCol.map((item) => ({ id: item.originalId || item.productId || item.id, cartLineId: item.cartLineId, cartRevision: item.cartRevision, quantity: item.quantity })),
                    shipping: formData,
                    promotion: promotionPreview?.code || null,
                });
                if (!mountedRef.current) return;
                const clientOrderId = getCheckoutClientOrderId();
                advanceCheckoutController({
                    type: 'START',
                    clientOrderId
                });
                const input = buildCheckoutV2Input({
                    clientOrderId,
                    cartItems: itemsWithCol,
                    deliveryModeId: fixtureContext
                        ? 'fixture_delivery_fr'
                        : formData.deliveryMode,
                    shippingAddress: formData,
                    promotionCode: promotionPreview?.code || null
                });
                const result = await createCheckoutV2(input, {
                    fixture: fixtureContext,
                    customerEmail: normalizedCheckoutEmail,
                    checkoutOtpToken: guestOtp.token || ''
                });
                if (!mountedRef.current) return;
                setReservationExpiresAt(result.expiresAt);
                setProviderStatus(result.providerStatus);
                advanceCheckoutController({
                    type: 'CREATED',
                    clientOrderId,
                    orderId: result.orderId
                });
                const purchasedCartLines = input.items.map((line) => ({
                    cartLineId: line.cartLineId,
                    cartRevision: line.cartRevision
                }));
                writeCheckoutRecoveryDescriptor(
                    createCheckoutRecoveryDescriptor({
                        ownerUid: identity.uid,
                        clientOrderId,
                        orderId: result.orderId,
                        cartLines: purchasedCartLines
                    }),
                    { enabled: COMMERCE_V2_RECOVERY_ENABLED }
                );
                onCheckoutReserved?.();
                setClientSecret(result.clientSecret);
                setRecoveredOrderTotal(Number.isSafeInteger(result.totalCents)
                    ? result.totalCents / 100
                    : null);
                setAuthoritativeShippingCost(Number.isSafeInteger(result.shippingCents)
                    ? result.shippingCents / 100
                    : null);
                setAuthoritativeDiscount(Number.isSafeInteger(result.discountCents)
                    ? result.discountCents / 100
                    : null);
                if (result.promotion) setPromotionPreview(result.promotion);
                setCreatedOrderId(result.orderId);
                setCreatedOrderNumber(Number.isSafeInteger(result.orderNumber) ? result.orderNumber : null);
                setCreatedOrderOtpToken('');
                setCreatedStripeConnectedAccountId(
                    result.connectedAccountId || ''
                );
                setLockedOrderDraft({
                    items: itemsWithCol,
                    subtotal: draftSubtotal,
                    purchasedCartLines
                });
                setCheckoutState('ready_to_pay');
                logClientPerf('checkout.createOrderV2', createOrderStartedAt, {
                    phase: 'success',
                    paymentMethod
                });
                return;
            }
            const createOrder = httpsCallable(functions, getFunctionTarget('createOrder'));

            const result = await createOrder({
                orderData: {
                    shipping: formData,
                    paymentMethod,
                    items: itemsWithCol,
                    checkoutOtpToken: guestOtp.token || '',
                    clientOrderId: getCheckoutClientOrderId(),
                    total: finalTotal
                }
            });

            if (result.data.success) {
                logClientPerf('checkout.createOrder', createOrderStartedAt, {
                    phase: 'success',
                    paymentMethod
                });
                if (paymentMethod === 'stripe_elements') {
                    if (result.data.clientSecret) {
                        setClientSecret(result.data.clientSecret);
                        setCreatedOrderId(result.data.orderId);
                        setCreatedOrderNumber(Number.isSafeInteger(result.data.orderNumber) ? result.data.orderNumber : null);
                        setCreatedOrderOtpToken(guestOtp.token || '');
                        setCreatedStripeConnectedAccountId(result.data.stripeConnectedAccountId || '');
                        setCheckoutState('ready_to_pay');
                    } else {
                        throw new Error("Client secret manquant.");
                    }
                } else {
                    // Deferred: succès direct
                    await onPlaceOrder({
                        id: result.data.orderId,
                        ...formData,
                        paymentMethod,
                        total: finalTotal
                    });
                    resetCheckoutClientOrderId();
                }
            } else {
                throw new Error("Erreur de création de commande.");
            }
        } catch (error) {
            if (!mountedRef.current) return;
            if (
                COMMERCE_V2_CONSUMERS_ENABLED &&
                checkoutControllerRef.current.status === 'creating'
            ) {
                advanceCheckoutController({
                    type: 'FAILED_RETRYABLE',
                    errorCode: error?.code || 'checkout-create-failed'
                });
            }
            logClientPerf('checkout.createOrder', createOrderStartedAt, {
                phase: 'error',
                paymentMethod,
                code: error?.code || null
            });
            if (COMMERCE_V2_CONSUMERS_ENABLED && !['invalid-argument', 'functions/invalid-argument', 'failed-precondition', 'functions/failed-precondition', 'permission-denied', 'functions/permission-denied'].includes(error?.code)) {
                setCheckoutState('payment_paused');
                setPaymentResumeNotice('Le résultat doit être vérifié. Réessayez sur ce même dossier, sans modifier les informations.');
                return;
            }
            console.error("Order error:", error);
            setCheckoutState('editing');
            setLockedOrderDraft(null);
            setRecoveredOrderTotal(null);
            setAuthoritativeShippingCost(null);
            setAuthoritativeDiscount(null);
            if (error?.details?.reason === 'price_changed' && Array.isArray(error.details.items)) {
                setPriceOverrides((current) => ({
                    ...current,
                    ...Object.fromEntries(error.details.items.map((item) => [String(item.id), Number(item.newPrice)]))
                }));
                resetCheckoutClientOrderId();
                toast('Le prix du panier a change. Le total a ete actualise; confirmez-le avant de continuer.', { type: 'warning' });
                return;
            }
            let msg = "Nous n’avons pas pu préparer votre commande. Vérifiez vos informations puis réessayez.";
            if (error?.details?.reason === 'COMMERCE_DELIVERY_OUT_OF_ZONE') {
                msg = 'Ce mode de livraison ne dessert pas votre adresse. Choisissez le transporteur ou le retrait à l’atelier.';
            }
            if (error?.details?.reason === 'COMMERCE_CHECKOUT_PRODUCT_UNAVAILABLE') {
                msg = 'Une pièce est réservée ou indisponible. Aucun panier partiel n’a été réservé. Vérifiez la disponibilité dans la galerie.';
            }
            if (error.message?.includes('vendu')) {
                msg = "Désolé, cet article vient d'être vendu à l'instant.";
            } else if (error.message?.includes('stock')) {
                msg = "Stock insuffisant pour cet article.";
            }
            toast(msg, { type: 'error' });
        }
    };

    // --- STRIPE APPEARANCE ---
    const stripeElementsOptions = useMemo(() => {
        if (!clientSecret) return null;
        return {
            clientSecret,
            appearance: {
                theme: darkMode ? 'night' : 'stripe',
                variables: {
                    colorPrimary: darkMode ? '#ffffff' : '#1c1917',
                    colorBackground: darkMode ? '#1c1917' : '#ffffff',
                    colorText: darkMode ? '#fafaf9' : '#1c1917',
                    colorDanger: '#ef4444',
                    fontFamily: 'Outfit, system-ui, sans-serif',
                    borderRadius: '12px',
                    spacingUnit: '4px',
                },
                rules: {
                    '.Input': {
                        backgroundColor: darkMode ? '#0c0a09' : '#ffffff',
                        border: darkMode ? '1px solid #292524' : '1px solid #e5e7eb',
                        boxShadow: 'none',
                    },
                    '.Input:focus': {
                        borderColor: darkMode ? '#ffffff' : '#1c1917',
                        boxShadow: darkMode ? '0 0 0 1px #ffffff' : '0 0 0 1px #1c1917',
                    },
                    '.Label': {
                        fontWeight: '600',
                    }
                }
            },
            locale: 'fr',
        };
    }, [clientSecret, darkMode]);

    if (checkoutState === 'fetching_stripe' && recoveryExpected && !clientSecret) {
        return (
            <section className={`flex min-h-[100dvh] items-center px-5 py-12 ${darkMode ? 'bg-stone-950 text-white' : 'bg-[#f7f4ef] text-stone-950'}`} aria-live="polite">
                <div className="mx-auto w-full max-w-xl">
                    <p className={`text-[11px] font-semibold uppercase tracking-[0.2em] ${darkMode ? 'text-stone-500' : 'text-stone-500'}`}>
                        Reprise sécurisée
                    </p>
                    <h1 className="mt-4 text-3xl font-semibold tracking-[-0.04em] sm:text-4xl">
                        Nous retrouvons votre paiement
                    </h1>
                    <p className={`mt-4 max-w-[52ch] text-sm leading-6 ${darkMode ? 'text-stone-400' : 'text-stone-600'}`}>
                        Nous préparons la reprise de votre commande. Vous allez retrouver le paiement là où vous l’aviez laissé.
                    </p>
                    <div className={`mt-9 overflow-hidden rounded-full ${darkMode ? 'bg-white/10' : 'bg-stone-200'}`}>
                        <span className={`sv-auth-loading-bar block h-1.5 w-1/2 ${darkMode ? 'bg-stone-100' : 'bg-stone-900'}`} />
                    </div>
                </div>
            </section>
        );
    }


    // --- RENDU OUT OF STOCK ---
    // On ne bloque pas si on est en train de processer une commande (fetching_stripe, processing_deferred)
    // OU si on vient de générer le PaymentIntent (ready_to_pay), car dans ce cas, c'est NOUS qui avons 
    // mis le stock à sold=true pour le réserver !
    // On ne bloque pas non plus si on est en cours de nettoyage (isCleaningUp) après avoir fermé la modale Stripe, 
    // pour laisser le temps au serveur de remettre sold=false sans déclencher l'alerte !
    if (unavailableItems.length > 0 && checkoutState !== 'processing_deferred' && checkoutState !== 'fetching_stripe' && checkoutState !== 'ready_to_pay' && checkoutState !== 'payment_paused' && checkoutState !== 'order_success' && !isCleaningUp) {
        const unavailableMessage = unavailableItems.length === 1
            ? `L'article "${unavailableItems[0].name}" n'est plus disponible au paiement en ligne (${unavailableItems[0].reason || 'indisponible'}).`
            : "Certains articles ne sont plus disponibles au paiement en ligne.";
        return (
            <div className={`min-h-screen pt-12 px-6 flex items-center justify-center bg-transparent`}>
                <div className={`p-8 rounded-3xl shadow-xl max-w-md text-center space-y-6 border ${darkMode ? 'bg-stone-900 border-stone-800' : 'bg-white border-stone-100'}`}>
                    <div className="w-16 h-16 bg-red-50 text-red-500 rounded-full flex items-center justify-center mx-auto">
                        <AlertCircle size={32} />
                    </div>
                    <h2 className={`text-2xl font-black ${darkMode ? 'text-white' : 'text-stone-900'}`}>Victime de son succès</h2>
                    <p className={darkMode ? 'text-stone-400' : 'text-stone-500'}>
                        {unavailableMessage}
                    </p>
                    <button onClick={onBack} className={`w-full py-4 rounded-xl font-bold uppercase text-xs tracking-widest transition-all text-stone-900 bg-amber-500 hover:bg-amber-400`}>
                        Retourner à la boutique
                    </button>
                </div>
            </div>
        );
    }

    const inputClasses = `w-full p-3.5 md:p-4 rounded-xl ring-1 ring-inset outline-none focus:ring-2 font-bold text-base transition-all transform-gpu ${
        darkMode 
            ? 'bg-stone-900 ring-stone-800 focus:ring-white text-white placeholder:text-stone-600 autofill-dark' 
            : 'bg-stone-50 ring-stone-200 focus:ring-stone-900 text-stone-900 placeholder:text-stone-400 autofill-light'
    }`;
    const cardClasses = `space-y-4 rounded-2xl border p-5 md:p-6 ${darkMode ? 'border-stone-800/80 bg-stone-900/40' : 'border-stone-200/80 bg-white'}`;

    return (
        <>
        {confirmation}
        <div
            className={`min-h-[100dvh] px-4 pt-8 md:px-6 md:pt-10 animate-in fade-in transition-colors duration-700 bg-transparent`}
            style={{ paddingBottom: 'calc(env(safe-area-inset-bottom, 0px) + 6rem)' }}
        >
            <div className="max-w-[1240px] mx-auto w-full">
                {/* HEADER RETOUR */}
                <div className="mb-8 md:mb-12">
                    <button onClick={leaveCheckout} className={`flex items-center gap-2 font-bold text-[10px] md:text-xs uppercase tracking-widest transition-colors mb-6 ${darkMode ? 'text-stone-500 hover:text-white' : 'text-stone-400 hover:text-stone-900'}`}>
                        <ArrowLeft size={14} /> {createdOrderId ? 'Annuler et retourner à la galerie' : 'Continuer mes achats'}
                    </button>
                    {createdOrderId ? <p className="mb-4 text-sm"><a href="/mes-commandes">Consulter le dossier</a>{reservationExpiresAt ? ` · Réservation jusqu’à ${new Date(reservationExpiresAt).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}` : ''}</p> : null}
                    <h2 className={`text-3xl md:text-5xl font-black tracking-tighter ${darkMode ? 'text-white' : 'text-stone-900'}`}>
                        Finaliser la commande
                    </h2>
                </div>

                <div className="grid lg:grid-cols-[1fr_460px] gap-8 lg:gap-16 items-start">
                    
                    {/* COLONNE GAUCHE : FORMULAIRES & PAIEMENT */}
                    <fieldset disabled={isCheckoutLocked} className="min-w-0 space-y-6 w-full">
                        {isCheckoutLocked ? <p className="text-sm leading-6 text-stone-500">{createdOrderId ? 'Ces informations correspondent à votre réservation. Pour les modifier, annulez d’abord cette réservation depuis le bouton en haut de page.' : 'Vos informations sont conservées pendant la préparation ou la vérification de votre réservation.'}</p> : null}
                        
                        {/* GROUPE 1 : INFOS & ADRESSE COMBINÉS */}
                        <div className={cardClasses}>
                            <h3 className="text-[10px] md:text-xs font-black uppercase tracking-widest text-stone-400 flex items-center gap-2 mb-4">
                                <Truck size={14} /> Informations de Livraison
                            </h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
                                <div>
                                    <label htmlFor="checkout-fullName" className="sr-only">Nom complet</label>
                                    <input id="checkout-fullName" name="fullName" value={formData.fullName} onChange={handleChange} placeholder="Nom complet" autoComplete="name" className={inputClasses} required />
                                </div>
                                <div>
                                    <label htmlFor="checkout-phone" className="sr-only">Téléphone</label>
                                    <input id="checkout-phone" name="phone" value={formData.phone} onChange={handleChange} placeholder="Téléphone" type="tel" inputMode="tel" autoComplete="tel" maxLength={40} className={inputClasses} required />
                                </div>
                            </div>
                            <div>
                                <label htmlFor="checkout-email" className="sr-only">Email</label>
                                <input id="checkout-email" name="email" value={formData.email} onChange={handleChange} placeholder="Email" type="email" autoComplete="email" className={inputClasses} required />
                            </div>
                            {requiresGuestCheckoutOtp ? (
                                <div className={`rounded-2xl border p-4 space-y-3 ${darkMode ? 'border-stone-800 bg-stone-950/40' : 'border-stone-200 bg-stone-50'}`}>
                                    <div className="flex flex-col gap-1">
                                        <span className={`text-[10px] font-black uppercase tracking-widest ${darkMode ? 'text-stone-300' : 'text-stone-700'}`}>Verification email</span>
                                        <p className={`text-xs font-medium leading-relaxed ${darkMode ? 'text-stone-500' : 'text-stone-500'}`}>
                                            Entrez le code a 6 chiffres envoye a cette adresse pour continuer en invite.
                                        </p>
                                    </div>

                                    <div className="grid grid-cols-1 sm:grid-cols-[1fr_auto] gap-3">
                                        <button
                                            type="button"
                                            onClick={sendGuestCheckoutOtp}
                                            disabled={!isOtpEmailReady || guestOtp.status === 'sending' || guestOtp.status === 'verifying'}
                                            className={`relative h-12 overflow-hidden rounded-xl px-4 text-[10px] font-black uppercase tracking-widest transition-colors ${darkMode ? 'bg-white text-stone-950 disabled:bg-stone-800 disabled:text-stone-500' : 'bg-stone-950 text-white disabled:bg-stone-200 disabled:text-stone-400'}`}
                                        >
                                            {guestOtp.status === 'sending' ? <Loader2 size={13} className="mr-2 inline animate-spin" /> : null}
                                            {guestOtp.status === 'sending' ? 'Envoi...' : guestOtp.status === 'verified' ? 'Renvoyer un code' : 'Envoyer le code'}
                                            {guestOtp.status === 'sending' ? (
                                                <span className={`absolute inset-x-0 bottom-0 h-1 ${darkMode ? 'bg-stone-700' : 'bg-stone-300'}`}>
                                                    <span className="sv-auth-loading-bar block h-full w-1/2 bg-emerald-400" />
                                                </span>
                                            ) : null}
                                        </button>
                                        <div className="flex gap-2">
                                            <label htmlFor="checkout-otp-code" className="sr-only">Code email</label>
                                            <input
                                                id="checkout-otp-code"
                                                name="guestCheckoutOtp"
                                                value={guestOtp.code}
                                                onChange={handleOtpCodeChange}
                                                placeholder="000000"
                                                inputMode="numeric"
                                                autoComplete="one-time-code"
                                                pattern="[0-9]*"
                                                maxLength={6}
                                                disabled={guestOtp.status === 'verified'}
                                                className={`${inputClasses} text-center tracking-[0.35em]`}
                                            />
                                            <button
                                                type="button"
                                                onClick={() => verifyGuestCheckoutOtp()}
                                                disabled={guestOtp.code.length !== 6 || guestOtp.status === 'sending' || guestOtp.status === 'verifying' || guestOtp.status === 'verified'}
                                                className={`relative h-12 shrink-0 overflow-hidden rounded-xl px-4 text-[10px] font-black uppercase tracking-widest transition-colors ${darkMode ? 'border border-stone-700 text-white disabled:text-stone-600' : 'border border-stone-300 text-stone-900 disabled:text-stone-400'}`}
                                            >
                                                {guestOtp.status === 'verifying' ? <Loader2 size={13} className="mr-2 inline animate-spin" /> : null}
                                                {guestOtp.status === 'verifying' ? 'Verification...' : guestOtp.status === 'verified' ? 'OK' : 'Valider'}
                                                {guestOtp.status === 'verifying' ? (
                                                    <span className={`absolute inset-x-0 bottom-0 h-1 ${darkMode ? 'bg-stone-700' : 'bg-stone-300'}`}>
                                                        <span className="sv-auth-loading-bar block h-full w-1/2 bg-emerald-400" />
                                                    </span>
                                                ) : null}
                                            </button>
                                        </div>
                                    </div>

                                    {guestOtp.status === 'verified' ? (
                                        <p className="text-xs font-bold text-emerald-600">Email verifie pour cette commande.</p>
                                    ) : guestOtp.status === 'sent' ? (
                                        <p className={`text-xs font-medium ${darkMode ? 'text-stone-400' : 'text-stone-500'}`}>
                                            Code envoye. S&apos;il n&apos;apparait pas, verifiez aussi vos courriers indesirables.
                                        </p>
                                    ) : guestOtp.error ? (
                                        <p className="text-xs font-bold text-red-500">{guestOtp.error}</p>
                                    ) : null}
                                </div>
                            ) : null}
                            
                            {/* ADRESSE AVEC AUTOCOMPLÉTION INTELLIGENTE */}
                            <div className="flex flex-col gap-3 md:gap-4" ref={suggestionRef}>
                                <div>
                                    <label htmlFor="checkout-address" className="sr-only">Adresse (N°, Rue)</label>
                                    <input
                                        id="checkout-address"
                                        ref={addressInputRef}
                                        name="address"
                                        value={formData.address}
                                        onChange={handleAddressRelatedChange}
                                        onFocus={(e) => {
                                            e.target.select();
                                            if (suggestions.length > 0) { updateDropdownPosition(); setShowSuggestions(true); }
                                        }}
                                        placeholder="Adresse (N°, Rue)"
                                        className={inputClasses}
                                        required
                                        autoComplete="street-address"
                                    />
                                </div>

                                <div className="grid grid-cols-2 gap-3 md:gap-4">
                                    <div>
                                        <label htmlFor="checkout-zip" className="sr-only">Code Postal</label>
                                        <input
                                            id="checkout-zip"
                                            name="zip"
                                            value={formData.zip}
                                            onChange={handleAddressRelatedChange}
                                            onFocus={(e) => {
                                                e.target.select();
                                                if (suggestions.length > 0) { updateDropdownPosition(); setShowSuggestions(true); }
                                            }}
                                            placeholder="Code Postal"
                                            className={inputClasses}
                                            required
                                            autoComplete="postal-code"
                                            inputMode="numeric"
                                        />
                                    </div>
                                    <div>
                                        <label htmlFor="checkout-city" className="sr-only">Ville</label>
                                        <input
                                            id="checkout-city"
                                            name="city"
                                            value={formData.city}
                                            onChange={handleAddressRelatedChange}
                                            onFocus={(e) => {
                                                e.target.select();
                                                if (suggestions.length > 0) { updateDropdownPosition(); setShowSuggestions(true); }
                                            }}
                                            placeholder="Ville"
                                            className={inputClasses}
                                            required
                                            autoComplete="address-level2"
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* GROUPE 1.5 : MODE DE LIVRAISON & RGPD */}
                        <div className={cardClasses}>
                            <h3 className="text-[10px] md:text-xs font-black uppercase tracking-widest text-stone-400 flex items-center gap-2 mb-4">
                                <Truck size={14} /> Mode de Livraison
                            </h3>
                            <div className="space-y-3">
                                {Object.values(deliverySettings).filter(m => m.active).map(mode => {
                                    const unavailableReason = deliveryUnavailableReason(mode.id, formData.zip);
                                    return (
                                    <label htmlFor={`checkout-delivery-${mode.id}`} key={mode.id} className={`flex items-start gap-4 p-4 rounded-xl border transition-colors focus-within:ring-2 focus-within:ring-stone-400 focus-within:ring-offset-2 ${unavailableReason ? (darkMode ? 'cursor-not-allowed border-stone-800 bg-stone-900 opacity-60' : 'cursor-not-allowed border-stone-200 bg-stone-100 opacity-60') : `cursor-pointer ${formData.deliveryMode === mode.id ? (darkMode ? 'border-white bg-white/5' : 'border-stone-900 bg-stone-50') : (darkMode ? 'border-stone-800 hover:bg-stone-800' : 'border-stone-200 hover:bg-stone-50')}`}`}>
                                        <span className="sr-only">{mode.label}</span>
                                        <div className="pt-1 flex items-center">
                                            <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${formData.deliveryMode === mode.id ? 'border-current' : 'border-stone-300'}`}>
                                                {formData.deliveryMode === mode.id && <div className="w-2 h-2 rounded-full bg-current" />}
                                            </div>
                                            <input id={`checkout-delivery-${mode.id}`} type="radio" className="sr-only" name="deliveryMode" value={mode.id} disabled={Boolean(unavailableReason)} aria-describedby={`checkout-delivery-help-${mode.id}`} checked={!unavailableReason && formData.deliveryMode === mode.id} onChange={handleChange} />
                                        </div>
                                        <div className="flex-1">
                                            <div className="flex justify-between">
                                                <span className={`font-bold ${darkMode ? 'text-white' : 'text-stone-900'}`}>{mode.label}</span>
                                                <span className={`font-black ${darkMode ? 'text-white' : 'text-stone-900'}`}>{mode.price === 0 ? 'Gratuit' : `${mode.price} €`}</span>
                                            </div>
                                            <div id={`checkout-delivery-help-${mode.id}`} className="text-xs text-stone-500 font-medium mt-0.5">{unavailableReason || mode.sub}</div>
                                        </div>
                                    </label>
                                ); })}
                            </div>

                            <div className="mt-6 pt-6 border-t border-stone-200 dark:border-stone-800">
                                <label htmlFor="checkout-terms" className="flex cursor-pointer items-start gap-3 group">
                                    <div className="pt-0.5">
                                        <div className={`w-5 h-5 rounded flex items-center justify-center border-2 transition-colors ${rgpdAccepted ? (darkMode ? 'bg-white border-white text-stone-900' : 'bg-stone-900 border-stone-900 text-white') : (darkMode ? 'border-stone-600 bg-transparent group-hover:border-stone-500' : 'border-stone-300 bg-white group-hover:border-stone-400')}`}>
                                            {rgpdAccepted && <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>}
                                        </div>
                                        <input id="checkout-terms" type="checkbox" className="sr-only" checked={rgpdAccepted} onChange={(e) => setRgpdAccepted(e.target.checked)} />
                                    </div>
                                    <div className={`text-xs leading-5 ${darkMode ? 'text-stone-400' : 'text-stone-600'}`}>
                                        {LEGAL_DOCUMENTS_READY ? (
                                            <>
                                                J&apos;accepte les <a href={TERMS_URL} target="_blank" rel="noopener noreferrer" className="underline underline-offset-2">conditions générales de vente</a> et je confirme avoir pris connaissance de la <a href={PRIVACY_URL} target="_blank" rel="noopener noreferrer" className="underline underline-offset-2">politique de confidentialité</a>.
                                            </>
                                        ) : (
                                            <>J&apos;accepte les conditions générales de vente et je confirme avoir pris connaissance de la politique de confidentialité (RGPD).</>
                                        )}
                                    </div>
                                </label>
                            </div>
                        </div>

                        {/* GROUPE 2 : CHOIX DU PAIEMENT */}
                        <div className={`${cardClasses} ${!stripeEnabled ? 'w-full md:max-w-[400px]' : ''}`}>
                            <h3 className="text-[10px] md:text-xs font-black uppercase tracking-widest text-stone-400 flex items-center gap-2 mb-4">
                                <CreditCard size={14} /> Moyen de Paiement
                            </h3>
                            
                            <div className={stripeEnabled ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 xl:grid-cols-2 gap-4' : 'flex flex-col'}>
                                {/* PAIEMENT DIRECT */}
                                {stripeEnabled && <button
                                    type="button"
                                    aria-pressed={paymentMethod === 'stripe_elements'}
                                    onClick={() => {
                                        if (isCheckoutLocked) return;
                                        setPaymentMethod('stripe_elements');
                                        setCheckoutState('editing'); // Reset si on change d'avis
                                    }}
                                    className="group relative w-full cursor-pointer overflow-hidden rounded-[1.125rem] p-[1.5px] text-left transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-stone-900 focus-visible:ring-offset-2"
                                >
                                    {paymentMethod === 'stripe_elements' && (
                                        <div className={`absolute inset-0 z-0 rounded-[1.125rem] border-2 ${darkMode ? 'border-white/50' : 'border-stone-900'}`} />
                                    )}

                                    {/* DEFAULT BORDER FALLBACK */}
                                    {paymentMethod !== 'stripe_elements' && (
                                        <div className={`absolute inset-0 z-0 rounded-[1.125rem] border-2 transition-colors ${darkMode ? 'border-stone-800' : 'border-stone-200'}`} />
                                    )}

                                    {/* INNER CONTENT - OPAQUE MASKING (to hide the center of the wave) */}
                                    <div className={`relative z-10 w-full h-full p-4 rounded-2xl flex flex-col gap-6 transition-all ${paymentMethod === 'stripe_elements' ? (darkMode ? 'bg-stone-900' : 'bg-white') : (darkMode ? 'bg-transparent group-hover:bg-white/5' : 'bg-transparent group-hover:bg-black/5')} backdrop-blur-md`}>
                                        
                                        {/* EN-TÊTE : ICONE + TITRE */}
                                        <div className="flex items-center gap-4">
                                            <div className={`w-12 h-12 shrink-0 rounded-2xl flex items-center justify-center transition-colors ${paymentMethod === 'stripe_elements' ? (darkMode ? 'bg-stone-800 text-white' : 'bg-stone-900 text-white') : (darkMode ? 'bg-stone-800/50 text-stone-500' : 'bg-stone-100 text-stone-400')}`}>
                                                <Wallet size={22} />
                                            </div>
                                            <div className="flex-1">
                                                <div className="flex justify-between items-center">
                                                    <span className={`font-black text-base ${darkMode ? 'text-white' : 'text-stone-900'}`}>Paiement Stripe</span>
                                                </div>
                                                <p className="text-[10px] font-bold text-stone-500 uppercase tracking-widest mt-0.5">Carte et options disponibles</p>
                                            </div>
                                        </div>
                                        
                                        {/* METHODES STRIPE GENERIQUES : le Payment Element affiche seulement les moyens actifs et eligibles. */}
                                        <div className="flex flex-wrap items-center gap-2">
                                            {/* VISA */}
                                            <div className={`h-7 px-2.5 flex items-center justify-center rounded-md border ${darkMode ? 'bg-white border-stone-700' : 'bg-white border-stone-200 shadow-sm'}`}>
                                                <span className="text-[11px] font-black italic text-[#1434CB] tracking-tighter">VISA</span>
                                            </div>
                                            {/* MASTERCARD */}
                                            <div className={`h-7 w-10 relative overflow-hidden flex items-center justify-center rounded-md border ${darkMode ? 'bg-white border-stone-700' : 'bg-white border-stone-200 shadow-sm'}`}>
                                                <div className="w-4 h-4 rounded-full bg-[#EB001B] mix-blend-multiply absolute -translate-x-1.5" />
                                                <div className="w-4 h-4 rounded-full bg-[#F79E1B] mix-blend-multiply absolute justify-center translate-x-1.5" />
                                            </div>
                                            {/* METHODES DYNAMIQUES */}
                                            <div className={`h-7 px-2.5 flex items-center justify-center rounded-md border ${darkMode ? 'bg-stone-800 border-stone-700 text-stone-300' : 'bg-stone-100 border-stone-200 text-stone-600 shadow-sm'}`}>
                                                <span className="text-[10px] font-bold uppercase tracking-wider leading-none">Selon Stripe</span>
                                            </div>
                                            <div className={`h-7 px-2.5 flex items-center justify-center rounded-md border ${darkMode ? 'bg-stone-800 border-stone-700 text-stone-300' : 'bg-stone-100 border-stone-200 text-stone-600 shadow-sm'}`}>
                                                <span className="text-[10px] font-bold uppercase tracking-wider leading-none">Wallets eligibles</span>
                                            </div>
                                        </div>
                                    </div>
                                </button>}

                                {/* VIREMENT / WERO */}
                                {!COMMERCE_V2_CONSUMERS_ENABLED ? <button
                                    type="button"
                                    aria-pressed={paymentMethod === 'deferred'}
                                    onClick={() => {
                                        if (isCheckoutLocked) return;
                                        setPaymentMethod('deferred');
                                        setCheckoutState('editing');
                                    }}
                                    className="group relative w-full cursor-pointer overflow-hidden rounded-[1.125rem] p-[1.5px] text-left transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-stone-900 focus-visible:ring-offset-2"
                                >
                                    {paymentMethod === 'deferred' && (
                                        <div className={`absolute inset-0 z-0 rounded-[1.125rem] border-2 ${darkMode ? 'border-white/50' : 'border-stone-900'}`} />
                                    )}

                                    {/* DEFAULT BORDER FALLBACK */}
                                    {paymentMethod !== 'deferred' && (
                                        <div className={`absolute inset-0 z-0 rounded-[1.125rem] border-2 transition-colors ${darkMode ? 'border-stone-800' : 'border-stone-200'}`} />
                                    )}

                                    {/* INNER CONTENT - OPAQUE MASKING (to hide the center of the wave) */}
                                    <div className={`relative z-10 w-full h-full p-4 rounded-2xl flex flex-col gap-6 transition-all ${paymentMethod === 'deferred' ? (darkMode ? 'bg-stone-900' : 'bg-white') : (darkMode ? 'bg-transparent group-hover:bg-white/5' : 'bg-transparent group-hover:bg-black/5')} backdrop-blur-md`}>
                                        
                                        {/* EN-TÊTE : ICONE + TITRE */}
                                        <div className="flex items-center gap-4">
                                            <div className={`w-12 h-12 shrink-0 rounded-2xl flex items-center justify-center transition-colors ${paymentMethod === 'deferred' ? (darkMode ? 'bg-stone-800 text-white' : 'bg-stone-900 text-white') : (darkMode ? 'bg-stone-800/50 text-stone-500' : 'bg-stone-100 text-stone-400')}`}>
                                                <Landmark size={22} />
                                            </div>
                                            <div className="flex-1">
                                                <div className="flex justify-between items-center">
                                                    <span className={`font-black text-base ${darkMode ? 'text-white' : 'text-stone-900'}`}>Virement</span>
                                                </div>
                                                <p className="text-[10px] font-bold text-stone-500 uppercase tracking-widest mt-0.5">Instructions via email</p>
                                            </div>
                                        </div>
                                        
                                        {/* LOGOS VIREMENT / WERO (SUR LEUR PROPRE LIGNE) */}
                                        <div className="flex flex-wrap items-center gap-2">
                                            {/* BANQUE TRADITIONNELLE */}
                                            <div className={`h-7 px-2.5 flex items-center gap-1.5 justify-center rounded-md border ${darkMode ? 'bg-stone-800 border-stone-700 text-stone-300' : 'bg-stone-100 border-stone-200 text-stone-600 shadow-sm'}`}>
                                                <Landmark size={12} />
                                                <span className="text-[10px] font-bold uppercase tracking-widest leading-none mt-[1px]">Virement</span>
                                            </div>
                                            {/* WERO */}
                                            <div className={`h-7 px-3 flex items-center justify-center rounded-md border overflow-hidden ${darkMode ? 'bg-[#002B5E] border-transparent text-white' : 'bg-gradient-to-tr from-[#002B5E] to-[#0A4795] border-transparent text-white shadow-sm'}`}>
                                                <span className="text-[12px] font-black lowercase tracking-tight leading-none">wero</span>
                                            </div>
                                        </div>
                                    </div>
                                </button> : null}
                            </div>

                            {/* BOUTON D'ACTION DÉPLACÉ DANS LA COLONNE DE DROITE */}
                        </div>

                    </fieldset>

                    {/* COLONNE DROITE : RÉSUMÉ STICKY */}
                    <div className="relative w-full">
                        <div className="sticky top-24 space-y-6">
                            <div className={`relative overflow-hidden rounded-3xl border p-6 text-white md:p-8 ${darkMode ? 'border-stone-800 bg-stone-900' : 'border-stone-800 bg-[#20201e]'}`}>
                                <div className="relative z-10">
                                    <h3 className="text-xl font-black mb-6 text-white">Résumé de la commande</h3>
                                    
                                    <div className="space-y-4 mb-4">
                                        {checkoutItems.map((item, index) => (
                                            <div key={item.id || index} className="flex justify-between items-start text-sm">
                                                <div className="flex flex-col max-w-[70%]">
                                                    <span className="text-stone-300 font-medium">{item.name}</span>
                                                    {(item.variant || item.woodType || item.size || Object.values(item.options || {}).join(', ')) && (
                                                        <span className="text-xs text-stone-500 mt-0.5">
                                                            {item.variant || item.woodType || item.size || Object.values(item.options || {}).join(', ')}
                                                        </span>
                                                    )}
                                                </div>
                                                <span className="font-bold text-white tracking-tight">{item.price} €</span>
                                            </div>
                                        ))}
                                    </div>
                                    
                                    <div className="flex justify-between items-center text-sm mb-6 mt-4 pt-4 border-t border-white/5">
                                        <span className="text-stone-400 font-medium">Frais de livraison</span>
                                        <span className="font-bold text-white tracking-tight">{displayedShippingCost > 0 ? `+ ${displayedShippingCost} €` : 'Gratuit'}</span>
                                    </div>

                                    <div className="mb-5 rounded-2xl border border-white/10 bg-white/[0.035] p-3.5">
                                        <div className="flex items-center gap-2 text-xs font-bold text-stone-200">
                                            <TicketPercent size={15} strokeWidth={1.8} />
                                            Code avantage
                                        </div>
                                        {promotionPreview ? (
                                            <div className="mt-3 flex items-center justify-between gap-3 rounded-xl bg-emerald-400/10 px-3 py-2.5 text-emerald-200">
                                                <div className="min-w-0">
                                                    <p className="truncate text-xs font-black tracking-wide">{promotionPreview.code}</p>
                                                    <p className="mt-0.5 text-[11px] text-emerald-200/75">{promotionPreview.percentage} % appliqués · − {((promotionPreview.discountCents || 0) / 100).toFixed(2).replace('.', ',')} €</p>
                                                </div>
                                                {!isCheckoutLocked ? (
                                                    <button aria-label="Retirer le code promotionnel" className="rounded-lg p-1.5 transition hover:bg-white/10" onClick={clearPromotionCode} type="button"><X size={14} /></button>
                                                ) : <Check size={15} />}
                                            </div>
                                        ) : (
                                            <div className="mt-3 flex gap-2">
                                                <input
                                                    aria-label="Code promotionnel"
                                                    className="min-w-0 flex-1 rounded-xl border border-white/10 bg-black/15 px-3 py-2.5 text-sm font-bold uppercase tracking-wide text-white outline-none transition placeholder:text-stone-600 focus:border-amber-400/60"
                                                    disabled={isCheckoutLocked || promotionStatus === 'loading'}
                                                    onChange={(event) => {
                                                        setPromotionCode(event.target.value.toUpperCase());
                                                        setPromotionError('');
                                                    }}
                                                    onKeyDown={(event) => {
                                                        if (event.key === 'Enter') {
                                                            event.preventDefault();
                                                            void applyPromotionCode();
                                                        }
                                                    }}
                                                    placeholder="SV15-XXXXXX"
                                                    value={promotionCode}
                                                />
                                                <button
                                                    className="inline-flex min-w-24 items-center justify-center rounded-xl bg-white px-3 text-xs font-black text-stone-950 transition hover:bg-stone-200 disabled:opacity-50"
                                                    disabled={!promotionCode.trim() || isCheckoutLocked || promotionStatus === 'loading'}
                                                    onClick={() => void applyPromotionCode()}
                                                    type="button"
                                                >
                                                    {promotionStatus === 'loading' ? <Loader2 className="animate-spin" size={14} /> : 'Appliquer'}
                                                </button>
                                            </div>
                                        )}
                                        {promotionError ? <p className="mt-2 text-xs leading-5 text-red-300" role="alert">{promotionError}</p> : null}
                                    </div>

                                    {displayedDiscount > 0 ? (
                                        <div className="mb-5 flex justify-between text-sm text-emerald-300">
                                            <span className="font-medium">Avantage appliqué</span>
                                            <span className="font-black tabular-nums">− {displayedDiscount.toFixed(2).replace('.', ',')} €</span>
                                        </div>
                                    ) : null}
                                    
                                    <div className="border-t border-stone-800 pt-6 flex justify-between items-end">
                                        <span className="text-stone-400 text-[10px] font-black uppercase tracking-widest mb-[2px]">Total à payer</span>
                                        <span className="text-4xl lg:text-5xl font-black tracking-tighter text-white">{formatCheckoutEuros(finalTotal)} €</span>
                                    </div>
                                </div>
                            </div>
                            
                            {/* BOUTON D'ACTION PREMIUM (Magnetic Spotlight & Layout Morph) */}
                            <div className="flex flex-col gap-4 items-center">
                                {paymentResumeNotice ? (
                                    <div
                                        className={`w-full rounded-2xl border px-4 py-3 text-sm leading-6 ${
                                            darkMode
                                                ? 'border-amber-300/20 bg-amber-200/10 text-amber-100'
                                                : 'border-amber-200 bg-amber-50 text-amber-950'
                                        }`}
                                        role="status"
                                        aria-live="polite"
                                    >
                                        {paymentResumeNotice}
                                    </div>
                                ) : null}
                                <PremiumActionBtn
                                    onClick={handleActionClick}
                                    disabled={!hasPendingV2Payment && (!isFormValid || !hasVerifiedCheckoutEmail)}
                                    isLoading={checkoutState === 'fetching_stripe' || checkoutState === 'processing_deferred' || guestOtp.status === 'sending' || guestOtp.status === 'verifying'}
                                    darkMode={darkMode}
                                >
                                    {hasPendingV2Payment ? (
                                        <span>Reprendre le paiement sécurisé</span>
                                    ) : paymentMethod === 'stripe_elements' ? (
                                        <span>Procéder au paiement sécurisé</span>
                                    ) : (
                                        <span>Confirmer ma commande</span>
                                    )}
                                </PremiumActionBtn>

                                {/* TEXTE DE RÉASSURANCE POUR VIREMENT */}
                                {paymentMethod === 'deferred' && (
                                    <p className="text-center text-[10px] font-medium leading-relaxed text-stone-400 mt-2">
                                        En confirmant, vous réservez vos articles.<br />
                                        Les détails de paiement vous seront envoyés par email.
                                    </p>
                                )}
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </div>

        {/* ECRAN STRIPE PLEINE PAGE, rendu dans un portal pour rester independant du shell checkout. */}
        {checkoutState === 'ready_to_pay' && clientSecret && stripeElementsOptions && paymentMethod === 'stripe_elements' && (
            <Suspense fallback={null}>
                <CheckoutStripeModal
                    darkMode={darkMode}
                    finalTotal={finalTotal}
                    orderTotal={checkoutSubtotal}
                    createdOrderId={createdOrderId}
                    createdOrderNumber={createdOrderNumber}
                    checkoutOtpToken={createdOrderOtpToken}
                    stripeConnectedAccountId={createdStripeConnectedAccountId}
                    formData={formData}
                    stripeElementsOptions={stripeElementsOptions}
                    purchasedCartLines={lockedOrderDraft?.purchasedCartLines || []}
                    expiresAt={reservationExpiresAt}
                    initialVerification={providerStatus && !['requires_payment_method', 'requires_confirmation', 'requires_action'].includes(providerStatus)}
                    onSubmissionState={(state) => {
                        if (!COMMERCE_V2_CONSUMERS_ENABLED) return;
                        if (state === 'submitting' && checkoutControllerRef.current.status === 'awaiting_method') advanceCheckoutController({ type: 'SUBMIT' });
                        if (state === 'idle' && checkoutControllerRef.current.status === 'processing') advanceCheckoutController({ type: 'RETRY_METHOD' });
                    }}
                    onClose={handleClosePaymentModal}
                    onPlaceOrder={onPlaceOrder}
                    onPaymentConfirmed={(confirmedOrder) => {
                        if (Number.isSafeInteger(confirmedOrder?.orderNumber)) {
                            setCreatedOrderNumber(confirmedOrder.orderNumber);
                        }
                        if (COMMERCE_V2_CONSUMERS_ENABLED) {
                            advanceCheckoutController({ type: 'SUCCEEDED' });
                        }
                        setUnavailableItems([]);
                        setCheckoutState('order_success');
                        resetCheckoutClientOrderId();
                    }}
                />
            </Suspense>
        )}

        {/* PORTAL — dropdown suggestions rendu à la racine du body */}
        {!isCheckoutLocked && showSuggestions && suggestions.length > 0 && createPortal(
            dropdownPos.mobile ? (
                /* ── MOBILE : bottom sheet ancré au-dessus du clavier ── */
                <div
                    ref={dropdownRef}
                    style={{ position: 'fixed', bottom: 0, left: 0, right: 0, zIndex: 9999, borderRadius: '20px 20px 0 0' }}
                    className={`shadow-2xl overflow-hidden ${darkMode ? 'bg-stone-900 border-t border-stone-700' : 'bg-white border-t border-stone-100'}`}
                >
                    {/* Handle bar */}
                    <div className="flex justify-center pt-3 pb-1">
                        <div className={`w-10 h-1 rounded-full ${darkMode ? 'bg-stone-600' : 'bg-stone-200'}`} />
                    </div>
                    <div className="overflow-y-auto" style={{ maxHeight: '42vh' }}>
                        {suggestions.map((s, i) => (
                            <div
                                key={i}
                                onPointerDown={(e) => { e.preventDefault(); handleSelectSuggestion(s); }}
                                className={`px-5 py-4 flex flex-col gap-0.5 ${i < suggestions.length - 1 ? (darkMode ? 'border-b border-stone-800' : 'border-b border-stone-50') : ''} ${darkMode ? 'active:bg-stone-800' : 'active:bg-stone-50'}`}
                            >
                                <span className={`font-bold text-base leading-tight ${darkMode ? 'text-white' : 'text-stone-900'}`}>{s.properties.name}</span>
                                <span className={`text-xs font-medium uppercase tracking-wider ${darkMode ? 'text-stone-400' : 'text-stone-500'}`}>{s.properties.postcode} {s.properties.city}</span>
                            </div>
                        ))}
                        {/* safe-area iOS home indicator */}
                        <div style={{ height: 'env(safe-area-inset-bottom, 8px)' }} />
                    </div>
                </div>
            ) : (
                /* ── DESKTOP : dropdown positionné sous l'input ── */
                <div
                    ref={dropdownRef}
                    style={{ position: 'fixed', top: dropdownPos.top, left: dropdownPos.left, width: dropdownPos.width, zIndex: 9999 }}
                    className={`p-2 rounded-2xl border shadow-2xl max-h-64 overflow-y-auto ${darkMode ? 'bg-stone-800 border-stone-700' : 'bg-white border-stone-100'}`}
                >
                    {suggestions.map((s, i) => (
                        <div
                            key={i}
                            onPointerDown={(e) => { e.preventDefault(); handleSelectSuggestion(s); }}
                            className={`p-3 rounded-xl cursor-pointer transition-colors flex flex-col gap-0.5 ${darkMode ? 'hover:bg-stone-700 active:bg-stone-600' : 'hover:bg-stone-50 active:bg-stone-100'}`}
                        >
                            <span className={`font-bold text-sm leading-tight ${darkMode ? 'text-white' : 'text-stone-900'}`}>{s.properties.name}</span>
                            <span className={`text-[11px] font-medium uppercase tracking-wider ${darkMode ? 'text-stone-400' : 'text-stone-500'}`}>{s.properties.postcode} {s.properties.city}</span>
                        </div>
                    ))}
                </div>
            ),
            document.body
        )}
        </>
    );
};

export default CheckoutView;
