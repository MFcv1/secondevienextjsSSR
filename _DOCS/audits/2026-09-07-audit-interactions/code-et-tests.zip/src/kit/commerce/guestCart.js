export const GUEST_CART_STORAGE_KEY = 'secondevie:guest-cart:v1';
export const CHECKOUT_CART_HANDOFF_KEY = 'secondevie:checkout-cart-handoff:v1';
export const GUEST_CART_CHANGED_EVENT = 'sv:guest-cart-changed';
export const CART_STATE_CHANGED_EVENT = 'sv:cart-state-changed';
export const CART_ITEM_ADD_RESULT_EVENT = 'sv:cart-item-add-result';

const encodeCartKeyPart = (value) => encodeURIComponent(String(value || '').trim()).replace(/\./g, '%2E');
const createCartLineId = () => {
  const suffix = globalThis.crypto?.randomUUID?.()
    || `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  return `cart-line-${suffix}`;
};
const getLegacyCartLineId = (item) => (
  typeof item.id === 'string' && item.id.startsWith('cart_')
    ? `cart-line-legacy-${item.id.replace(/[^A-Za-z0-9_-]/g, '_')}`.slice(0, 160)
    : null
);

export const getCartDocumentId = (item = {}) => {
  const productId = item.originalId || item.productId || item.id;
  if (!productId) return '';
  const collectionName = item.collectionName || 'furniture';
  return `cart_${encodeCartKeyPart(collectionName)}_${encodeCartKeyPart(productId)}`;
};

const normalizeGuestCartItem = (item = {}) => {
  const productId = item.originalId || item.productId || item.id;
  if (!productId) return null;

  return {
    id: getCartDocumentId(item),
    originalId: productId,
    collectionName: item.collectionName || 'furniture',
    name: item.name || item.title || 'Piece Seconde Vie',
    price: Number(item.price || item.currentPrice || item.startingPrice || 0),
    stock: Number(item.stock || 0),
    sold: Boolean(item.sold),
    priceOnRequest: Boolean(item.priceOnRequest),
    image: item.image || item.imageUrl || '',
    material: item.material || 'Bois',
    quantity: Number(item.quantity || 1),
    cartLineId: item.cartLineId || getLegacyCartLineId(item) || createCartLineId(),
    cartRevision: Number.isSafeInteger(item.cartRevision) ? item.cartRevision : 1,
  };
};

export const readGuestCart = () => {
  if (typeof window === 'undefined') return [];
  try {
    const parsed = JSON.parse(window.localStorage.getItem(GUEST_CART_STORAGE_KEY) || '[]');
    if (!Array.isArray(parsed)) return [];
    return parsed.map(normalizeGuestCartItem).filter(Boolean);
  } catch {
    return [];
  }
};

export const writeGuestCart = (items) => {
  if (typeof window === 'undefined') return;
  const normalizedItems = (Array.isArray(items) ? items : [])
    .map(normalizeGuestCartItem)
    .filter(Boolean);
  window.localStorage.setItem(GUEST_CART_STORAGE_KEY, JSON.stringify(normalizedItems));
  window.dispatchEvent(new CustomEvent(GUEST_CART_CHANGED_EVENT, { detail: { items: normalizedItems } }));
  window.dispatchEvent(new CustomEvent(CART_STATE_CHANGED_EVENT, { detail: { items: normalizedItems } }));
};

export const addGuestCartItem = (item) => {
  const normalizedItem = normalizeGuestCartItem(item);
  if (!normalizedItem) return [];

  const existingItems = readGuestCart();
  const index = existingItems.findIndex((entry) => (
    entry.originalId === normalizedItem.originalId
    && entry.collectionName === normalizedItem.collectionName
  ));

  const nextItems = [...existingItems];
  if (index < 0) {
    nextItems.push(normalizedItem);
  }

  writeGuestCart(nextItems);
  return nextItems;
};

export const removeGuestCartItem = (cartItemId) => {
  const nextItems = readGuestCart().filter((item) => item.id !== cartItemId);
  writeGuestCart(nextItems);
  return nextItems;
};

export const clearGuestCart = () => writeGuestCart([]);

export const readCheckoutCartHandoff = () => {
  if (typeof window === 'undefined') return [];
  try {
    const parsed = JSON.parse(window.sessionStorage.getItem(CHECKOUT_CART_HANDOFF_KEY) || '[]');
    if (!Array.isArray(parsed)) return [];
    return parsed.map(normalizeGuestCartItem).filter(Boolean);
  } catch {
    return [];
  }
};

export const writeCheckoutCartHandoff = (items) => {
  if (typeof window === 'undefined') return;
  const normalizedItems = (Array.isArray(items) ? items : [])
    .map(normalizeGuestCartItem)
    .filter(Boolean);
  if (normalizedItems.length === 0) {
    window.sessionStorage.removeItem(CHECKOUT_CART_HANDOFF_KEY);
    return;
  }
  window.sessionStorage.setItem(CHECKOUT_CART_HANDOFF_KEY, JSON.stringify(normalizedItems));
};

export const clearCheckoutCartHandoff = () => {
  if (typeof window === 'undefined') return;
  window.sessionStorage.removeItem(CHECKOUT_CART_HANDOFF_KEY);
};
