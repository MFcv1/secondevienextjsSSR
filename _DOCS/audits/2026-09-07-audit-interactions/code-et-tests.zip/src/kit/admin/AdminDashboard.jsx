import { useState, useEffect, useRef, useMemo } from 'react';
import { motion, animate, useReducedMotion } from 'framer-motion';
import {
    TrendingUp, TrendingDown, ShoppingBag, RefreshCw,
    Archive, Users, Eye, FileText, Send, CircleDollarSign, PackageCheck
} from 'lucide-react';
import {
    collection, getDocs, limit,
    orderBy, query, where
} from 'firebase/firestore';
import { db } from '../config/firebase';
import { getCallableFunction } from '../config/firebaseLazy';
import { getAdminCacheGeneration, loadAdminCachedData } from './adminDataCache';
import { useAdminPreference } from './useAdminPreference';
import { getProductImageItems } from '../../utils/imageUtils';
import { getProductUrl } from '../../utils/slug';
import { getMillis } from '../../utils/time';
import { downloadCsv } from './exportCsv';
import { collectAdminUsers } from './adminUserExport';
import { getOrderJourney } from './components/orders/orderPresentation';
import { dashboardKpis, dashboardOrders, dashboardInsights } from './dashboardReads';
import orderReferenceModule from '../../../shared/orderReference.cjs';
import {
    CRITICAL_DOCUMENT_IDS,
    getConfirmedCapture,
    validateCriticalSnapshot,
    validateInsights
} from './adminDashboardProjection';

const { getOrderReference } = orderReferenceModule;

// ─── MOTION & FORMAT HELPERS ───

const EASE_OUT = [0.16, 1, 0.3, 1];

const sectionVariants = {
    hidden: { opacity: 0, y: 28 },
    visible: (i = 0) => ({
        opacity: 1,
        y: 0,
        transition: { duration: 0.7, delay: i * 0.09, ease: EASE_OUT }
    })
};

const formatEuroShort = (value) => {
    if (Math.abs(value) >= 1000) {
        const k = value / 1000;
        return `${k.toFixed(k >= 10 ? 0 : 1).replace('.', ',')}k€`;
    }
    return `${Math.round(value)}€`;
};

const formatEuroAmount = (value) => `${Number(value || 0).toLocaleString('fr-FR', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
})} €`;

const AnimatedNumber = ({ value, format, duration = 1.4 }) => {
    const ref = useRef(null);
    const reducedMotion = useReducedMotion();
    const formatRef = useRef(format);
    formatRef.current = format;

    useEffect(() => {
        const node = ref.current;
        if (!node) return undefined;
        const fmt = formatRef.current || ((v) => Math.round(v).toLocaleString('fr-FR'));
        if (reducedMotion) {
            node.textContent = fmt(value);
            return undefined;
        }
        const controls = animate(0, value, {
            duration,
            ease: EASE_OUT,
            onUpdate: (v) => { node.textContent = fmt(v); }
        });
        return () => controls.stop();
    }, [value, duration, reducedMotion]);

    return <span ref={ref} className="tabular-nums" />;
};

const TrendPill = ({ delta }) => {
    if (delta === null || delta === undefined || !Number.isFinite(delta)) return null;
    const positive = delta >= 0;
    return (
        <span className={`flex items-center gap-1 text-[10px] font-black px-2 py-1 rounded-lg tabular-nums ${positive ? 'text-emerald-500 bg-emerald-500/10' : 'text-red-500 bg-red-500/10'}`}>
            {positive ? <TrendingUp size={11} /> : <TrendingDown size={11} />}
            {positive ? '+' : ''}{Math.round(delta)}%
        </span>
    );
};

// ─── CUSTOM SVG CHARTS ───

const clampToRange = (value, min, max) => Math.max(min, Math.min(max, value));

// The Bézier control points are clamped to their adjacent values. This keeps
// the line smooth without inventing a dip below the zero baseline.
const buildBoundedMonotonePath = (points) => {
    if (points.length === 0) return '';
    if (points.length === 1) return `M ${points[0].x},${points[0].y}`;

    const widths = [];
    const slopes = [];
    for (let index = 0; index < points.length - 1; index += 1) {
        const width = points[index + 1].x - points[index].x;
        widths.push(width);
        slopes.push(width > 0 ? (points[index + 1].y - points[index].y) / width : 0);
    }

    const tangents = Array(points.length).fill(0);
    if (points.length === 2) {
        tangents[0] = slopes[0];
        tangents[1] = slopes[0];
    } else {
        const endpointTangent = (firstWidth, secondWidth, firstSlope, secondSlope) => {
            let tangent = ((2 * firstWidth + secondWidth) * firstSlope - firstWidth * secondSlope) / (firstWidth + secondWidth);
            if (Math.sign(tangent) !== Math.sign(firstSlope)) return 0;
            if (Math.sign(firstSlope) !== Math.sign(secondSlope) && Math.abs(tangent) > Math.abs(3 * firstSlope)) {
                tangent = 3 * firstSlope;
            }
            return tangent;
        };

        tangents[0] = endpointTangent(widths[0], widths[1], slopes[0], slopes[1]);
        tangents[points.length - 1] = endpointTangent(
            widths[widths.length - 1],
            widths[widths.length - 2],
            slopes[slopes.length - 1],
            slopes[slopes.length - 2]
        );

        for (let index = 1; index < points.length - 1; index += 1) {
            const previousSlope = slopes[index - 1];
            const nextSlope = slopes[index];
            if (previousSlope === 0 || nextSlope === 0 || Math.sign(previousSlope) !== Math.sign(nextSlope)) continue;

            const previousWeight = 2 * widths[index] + widths[index - 1];
            const nextWeight = widths[index] + 2 * widths[index - 1];
            tangents[index] = (previousWeight + nextWeight) / ((previousWeight / previousSlope) + (nextWeight / nextSlope));
        }
    }

    let path = `M ${points[0].x.toFixed(2)},${points[0].y.toFixed(2)}`;
    for (let index = 0; index < points.length - 1; index += 1) {
        const from = points[index];
        const to = points[index + 1];
        const width = widths[index];
        const minY = Math.min(from.y, to.y);
        const maxY = Math.max(from.y, to.y);
        const controlOneY = clampToRange(from.y + (tangents[index] * width) / 3, minY, maxY);
        const controlTwoY = clampToRange(to.y - (tangents[index + 1] * width) / 3, minY, maxY);

        path += ` C ${(from.x + width / 3).toFixed(2)},${controlOneY.toFixed(2)} ${(to.x - width / 3).toFixed(2)},${controlTwoY.toFixed(2)} ${to.x.toFixed(2)},${to.y.toFixed(2)}`;
    }
    return path;
};

const buildLinearPath = (points) => points.reduce(
    (path, point, index) => `${path}${index === 0 ? 'M' : ' L'} ${point.x.toFixed(2)},${point.y.toFixed(2)}`,
    ''
);

const RevenueChart = ({ data, darkMode }) => {
    const containerRef = useRef(null);
    const [dims, setDims] = useState({ w: 600, h: 240 });
    const [activeIdx, setActiveIdx] = useState(null);
    const reducedMotion = useReducedMotion();

    useEffect(() => {
        const el = containerRef.current;
        if (!el) return;
        const ro = new ResizeObserver(([entry]) => {
            if (entry.contentRect.width > 0) {
                setDims({ w: entry.contentRect.width, h: 240 });
            }
        });
        ro.observe(el);
        return () => ro.disconnect();
    }, []);

    const chartBounds = useMemo(() => {
        const values = data.map((point) => Number(point.value) || 0);
        return {
            min: Math.min(...values, 0),
            max: Math.max(...values, 100)
        };
    }, [data]);
    const valueRange = Math.max(1, chartBounds.max - chartBounds.min);
    const margin = { top: 48, right: 12, bottom: 26, left: dims.w < 420 ? 40 : 46 };
    const chartW = Math.max(10, dims.w - margin.left - margin.right);
    const chartH = dims.h - margin.top - margin.bottom;
    const baseY = margin.top + chartH;
    const zeroY = margin.top + ((chartBounds.max / valueRange) * chartH);
    const step = chartW / Math.max(1, data.length - 1);
    const denseSeries = data.length > 90;

    const points = useMemo(() => data.map((point, index) => {
        const value = Number(point.value) || 0;
        return {
            x: margin.left + index * step,
            y: margin.top + (((chartBounds.max - value) / valueRange) * chartH)
        };
    }), [chartBounds.max, chartH, data, margin.left, margin.top, step, valueRange]);

    const linePath = useMemo(
        () => (denseSeries ? buildLinearPath(points) : buildBoundedMonotonePath(points)),
        [denseSeries, points]
    );
    const areaPath = useMemo(() => {
        if (!linePath || points.length < 2) return '';
        const firstPoint = points[0];
        const lastPoint = points[points.length - 1];
        return `${linePath} L ${lastPoint.x.toFixed(2)},${zeroY.toFixed(2)} L ${firstPoint.x.toFixed(2)},${zeroY.toFixed(2)} Z`;
    }, [linePath, points, zeroY]);

    const peakIdx = useMemo(() => {
        let indexOfPeak = -1;
        let peak = Number.NEGATIVE_INFINITY;
        data.forEach((point, index) => {
            const value = Number(point.value) || 0;
            if (value > peak) {
                peak = value;
                indexOfPeak = index;
            }
        });
        return indexOfPeak;
    }, [data]);

    const xTickIndexes = useMemo(() => {
        if (data.length <= 7) return data.map((_, index) => index);
        if (data.length <= 31) {
            const every = Math.max(4, Math.ceil(data.length / 7));
            return data.reduce((indexes, point, index) => {
                const monthChanged = index > 0 && point.dateKey?.slice(0, 7) !== data[index - 1].dateKey?.slice(0, 7);
                if (index === 0 || index === data.length - 1 || index % every === 0 || monthChanged) indexes.push(index);
                return indexes;
            }, []);
        }

        const candidates = Array.from(new Set([
            0,
            ...data.reduce((indexes, point, index) => {
                if (point.dateKey?.slice(8, 10) === '01') indexes.push(index);
                return indexes;
            }, []),
            data.length - 1
        ])).sort((first, second) => first - second);
        const maximumTicks = Math.max(5, Math.floor(chartW / 60));
        if (candidates.length <= maximumTicks) return candidates;

        const every = Math.ceil((candidates.length - 2) / Math.max(1, maximumTicks - 2));
        return candidates.filter((_, index) => index === 0 || index === candidates.length - 1 || index % every === 0);
    }, [chartW, data]);

    const ticks = [
        chartBounds.max,
        chartBounds.min + (valueRange / 2),
        chartBounds.min
    ];
    const gridColor = darkMode ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.05)';
    const labelColor = darkMode ? 'rgba(255,255,255,0.35)' : 'rgba(0,0,0,0.35)';

    const handlePointerMove = (event) => {
        const rect = event.currentTarget.getBoundingClientRect();
        const x = event.clientX - rect.left - margin.left;
        let index = Math.round(x / step);
        index = Math.max(0, Math.min(data.length - 1, index));
        setActiveIdx(index);
    };

    return (
        <div
            ref={containerRef}
            className="relative h-[240px] min-w-0 w-full select-none overflow-hidden"
            role="img"
            aria-label="Évolution du chiffre d’affaires"
            onPointerMove={handlePointerMove}
            onPointerLeave={() => setActiveIdx(null)}
        >
            <svg
                viewBox={`0 0 ${dims.w} ${dims.h}`}
                width="100%"
                height={dims.h}
                preserveAspectRatio="none"
                className="block h-[240px] w-full"
            >
                <defs>
                    <linearGradient id="dashAreaGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#3B82F6" stopOpacity={denseSeries ? 0.14 : 0.22} />
                        <stop offset="60%" stopColor="#3B82F6" stopOpacity={denseSeries ? 0.025 : 0.05} />
                        <stop offset="100%" stopColor="#3B82F6" stopOpacity="0" />
                    </linearGradient>
                    <linearGradient id="dashLineGradient" x1="0" y1="0" x2="1" y2="0">
                        <stop offset="0%" stopColor="#60A5FA" />
                        <stop offset="100%" stopColor="#2563EB" />
                    </linearGradient>
                </defs>

                {ticks.map((tick, index) => {
                    const y = margin.top + (((chartBounds.max - tick) / valueRange) * chartH);
                    return (
                        <g key={tick}>
                            <line x1={margin.left} y1={y} x2={margin.left + chartW} y2={y}
                                  stroke={gridColor} strokeWidth="1" strokeDasharray={index === 2 ? undefined : '3 5'} />
                            <text x={margin.left - 10} y={y + 3} textAnchor="end"
                                  style={{ fontSize: 9, fontWeight: 700, fill: labelColor, letterSpacing: '0.05em' }}>
                                {formatEuroShort(tick)}
                            </text>
                        </g>
                    );
                })}

                {xTickIndexes.map((index) => (
                    <text key={`x-${index}`} x={points[index]?.x} y={baseY + 16} textAnchor="middle"
                          style={{ fontSize: 8, fontWeight: 700, fill: labelColor, letterSpacing: '0.08em', textTransform: 'uppercase' }}>
                        {data[index]?.axisLabel}
                    </text>
                ))}

                {data.length > 1 && (
                    <>
                        <motion.path
                            key={`area-${data.length}-${chartBounds.min}-${chartBounds.max}`}
                            d={areaPath}
                            fill="url(#dashAreaGradient)"
                            initial={reducedMotion ? false : { opacity: 0 }}
                            animate={{ opacity: 1 }}
                            transition={{ duration: 1.1, delay: 0.5 }}
                        />
                        <motion.path
                            key={`line-${data.length}-${chartBounds.min}-${chartBounds.max}`}
                            d={linePath}
                            fill="none"
                            stroke="url(#dashLineGradient)"
                            strokeWidth={denseSeries ? 1.65 : 2.5}
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            initial={reducedMotion ? false : { pathLength: 0 }}
                            animate={{ pathLength: 1 }}
                            transition={{ duration: 1.35, ease: EASE_OUT }}
                        />
                        {peakIdx >= 0 && activeIdx === null && points[peakIdx] && (
                            <g>
                                <circle cx={points[peakIdx].x} cy={points[peakIdx].y} r={denseSeries ? 6 : 9} fill="#3B82F6" opacity="0.12" />
                                <circle cx={points[peakIdx].x} cy={points[peakIdx].y} r={denseSeries ? 2.75 : 3.5}
                                        fill={darkMode ? '#0a0a0a' : '#ffffff'} stroke="#3B82F6" strokeWidth="2" />
                            </g>
                        )}
                        {activeIdx !== null && points[activeIdx] && (
                            <g>
                                <line x1={points[activeIdx].x} y1={margin.top} x2={points[activeIdx].x} y2={baseY}
                                      stroke={darkMode ? 'rgba(255,255,255,0.18)' : 'rgba(0,0,0,0.12)'} strokeDasharray="4 4" />
                                <circle cx={points[activeIdx].x} cy={points[activeIdx].y} r="9" fill="#3B82F6" opacity="0.15" />
                                <circle cx={points[activeIdx].x} cy={points[activeIdx].y} r="4"
                                        fill={darkMode ? '#0a0a0a' : '#ffffff'} stroke="#3B82F6" strokeWidth="2" />
                            </g>
                        )}
                    </>
                )}
            </svg>

            {activeIdx !== null && data[activeIdx] && points[activeIdx] && (
                <div
                    className={`pointer-events-none absolute top-1 z-10 -translate-x-1/2 rounded-xl px-3 py-1.5 ring-1 shadow-[0_14px_36px_-22px_rgba(25,32,28,0.48)] ${darkMode ? 'bg-[#1a1a19] ring-white/10 text-white' : 'bg-[#fffdfa] ring-stone-900/8 text-stone-900'}`}
                    style={{ left: clampToRange(points[activeIdx].x, 68, Math.max(68, dims.w - 68)) }}
                >
                    <p className="mb-0.5 whitespace-nowrap text-[9px] uppercase tracking-wider opacity-50">{data[activeIdx].tooltipLabel || data[activeIdx].label}</p>
                    <p className="whitespace-nowrap text-sm font-black tabular-nums">{Math.round(data[activeIdx].value).toLocaleString('fr-FR')} €</p>
                </div>
            )}
        </div>
    );
};

const PanelFrame = ({ children, className = '', innerClassName = '', darkMode, as = 'section' }) => {
    const Component = as;
    return (
        <Component className={`min-w-0 max-w-full rounded-[30px] p-1.5 ring-1 ${darkMode ? 'bg-white/[0.025] ring-white/[0.07]' : 'bg-[#e9e5df]/65 ring-[#25221f]/[0.055]'} ${className}`}>
            <div className={`h-full min-w-0 max-w-full rounded-[24px] shadow-[inset_0_1px_0_rgba(255,255,255,0.58),0_26px_72px_-54px_rgba(48,43,37,0.62)] ${darkMode ? 'bg-[#171817] text-white' : 'bg-[#fffdfa] text-[#242320]'} ${innerClassName}`}>
                {children}
            </div>
        </Component>
    );
};

const KpiCard = ({
    label,
    value,
    format,
    icon: Icon,
    meta,
    delta,
    darkMode,
    loading = false,
    unavailable = false,
    accent = false,
    action = null,
    className = ''
}) => (
    <PanelFrame darkMode={darkMode} className={className} innerClassName="relative overflow-hidden p-6 sm:p-7">
        <div className="flex h-full flex-col justify-between gap-7">
            <div className="flex items-center justify-between gap-4">
                <p className={`text-[10px] font-bold uppercase tracking-[0.18em] ${darkMode ? 'text-white/42' : 'text-stone-500'}`}>{label}</p>
                <span className={`flex h-9 w-9 items-center justify-center rounded-xl ring-1 ${accent ? (darkMode ? 'bg-[#94b7a0]/16 text-[#b8d2c0] ring-[#94b7a0]/20' : 'bg-[#dfe9e2] text-[#315843] ring-[#315843]/10') : (darkMode ? 'bg-white/[0.045] text-white/58 ring-white/[0.06]' : 'bg-[#f0ece6] text-stone-600 ring-stone-900/[0.05]')}`}>
                    <Icon size={17} strokeWidth={1.45} />
                </span>
            </div>
            <div>
                <div className="flex flex-wrap items-end gap-3">
                    {loading ? (
                        <span
                            aria-label={`${label} en cours de chargement`}
                            aria-busy="true"
                            className={`block h-12 w-36 animate-pulse rounded-xl ${darkMode ? 'bg-white/10' : 'bg-stone-200/80'}`}
                        />
                    ) : unavailable ? (
                        <span className={`text-[clamp(2rem,3.8vw,3.7rem)] font-semibold leading-none ${darkMode ? 'text-white/55' : 'text-stone-400'}`}>
                            —
                        </span>
                    ) : (
                        <p className={`whitespace-nowrap text-[clamp(2rem,3.8vw,3.7rem)] font-semibold leading-none tracking-[-0.055em] tabular-nums ${darkMode ? 'text-white' : 'text-[#22221f]'}`}>
                            <AnimatedNumber value={value} format={format} />
                        </p>
                    )}
                    <TrendPill delta={delta} />
                </div>
                <div className={`mt-3 flex min-h-5 items-center justify-between gap-3 text-[11px] font-medium ${darkMode ? 'text-white/46' : 'text-stone-500'}`}>
                    <span>{loading ? 'Chargement des données…' : unavailable ? 'Données momentanément indisponibles' : meta}</span>
                    {action}
                </div>
            </div>
        </div>
        {accent && (
            <div aria-hidden="true" className={`pointer-events-none absolute -bottom-16 -right-12 h-36 w-36 rounded-full ${darkMode ? 'bg-[#82a78d]/[0.08]' : 'bg-[#b9cebe]/25'}`} />
        )}
    </PanelFrame>
);

const StatusDonut = ({ counts, darkMode, unavailable = false }) => {
    const reducedMotion = useReducedMotion();
    if (unavailable) {
        return (
            <div className={`flex min-h-[286px] items-center justify-center rounded-2xl text-sm font-semibold ring-1 ${darkMode ? 'bg-white/[0.025] text-white/42 ring-white/[0.055]' : 'bg-[#f6f3ee] text-stone-400 ring-stone-900/[0.045]'}`}>
                Indisponible
            </div>
        );
    }
    const total = counts.paid + counts.pending + counts.shipped;
    const segments = [
        { key: 'paid', label: 'Payées', value: counts.paid, color: '#4f9870', radius: 62 },
        { key: 'shipped', label: 'Expédiées', value: counts.shipped, color: '#4e88c7', radius: 51 },
        { key: 'pending', label: 'En attente', value: counts.pending, color: '#dc921f', radius: 40 }
    ];
    const trackFraction = 0.78;
    const startAngle = 130;
    const trackDegrees = 360 * trackFraction;

    return (
        <div className="flex min-h-[286px] min-w-0 flex-col justify-between gap-5">
            <div className="relative mx-auto h-[190px] w-[190px] sm:h-[210px] sm:w-[210px]">
                <svg
                    viewBox="0 0 140 140"
                    className="h-full w-full overflow-visible"
                    role="img"
                    aria-label={`Répartition de ${total} commandes : ${counts.paid} payées, ${counts.shipped} expédiées et ${counts.pending} en attente`}
                >
                    {segments.map((segment, index) => {
                        const circumference = 2 * Math.PI * segment.radius;
                        const trackLength = circumference * trackFraction;
                        const progress = total > 0 ? segment.value / total : 0;
                        const progressLength = trackLength * progress;
                        const endAngle = (startAngle + (trackDegrees * progress)) * (Math.PI / 180);
                        const endX = 70 + (segment.radius * Math.cos(endAngle));
                        const endY = 70 + (segment.radius * Math.sin(endAngle));

                        return (
                            <g key={segment.key}>
                                <circle
                                    cx="70"
                                    cy="70"
                                    r={segment.radius}
                                    fill="none"
                                    stroke={darkMode ? 'rgba(255,255,255,0.065)' : 'rgba(45,43,39,0.065)'}
                                    strokeWidth="7"
                                    strokeDasharray={`${trackLength} ${circumference - trackLength}`}
                                    strokeLinecap="round"
                                    transform={`rotate(${startAngle} 70 70)`}
                                />
                            <motion.circle
                                cx="70"
                                cy="70"
                                r={segment.radius}
                                fill="none"
                                stroke={segment.color}
                                strokeWidth="7"
                                strokeDasharray={`${progressLength} ${circumference - progressLength}`}
                                strokeLinecap="round"
                                transform={`rotate(${startAngle} 70 70)`}
                                initial={reducedMotion ? false : { opacity: 0, strokeDashoffset: progressLength }}
                                animate={{ opacity: 1, strokeDashoffset: 0 }}
                                transition={{ duration: 0.9, delay: index * 0.1, ease: EASE_OUT }}
                            />
                                {progress > 0 && (
                                    <motion.circle
                                        cx={endX}
                                        cy={endY}
                                        r="3.5"
                                        fill={segment.color}
                                        initial={reducedMotion ? false : { opacity: 0, scale: 0.5 }}
                                        animate={{ opacity: 1, scale: 1 }}
                                        transition={{ duration: 0.45, delay: 0.55 + (index * 0.1), ease: EASE_OUT }}
                                        style={{ transformOrigin: `${endX}px ${endY}px` }}
                                    />
                                )}
                            </g>
                        );
                    })}
                </svg>
                <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
                    <span className={`text-[2.35rem] font-semibold leading-none tracking-[-0.065em] tabular-nums sm:text-[2.65rem] ${darkMode ? 'text-white' : 'text-stone-900'}`}>
                        {total}
                    </span>
                    <span className={`mt-2 text-[8px] font-bold uppercase tracking-[0.18em] ${darkMode ? 'text-white/38' : 'text-stone-400'}`}>
                        Commandes
                    </span>
                </div>
            </div>
            <div className={`grid min-w-0 grid-cols-3 divide-x rounded-2xl px-2 py-3 ring-1 ${darkMode ? 'divide-white/[0.07] bg-white/[0.025] ring-white/[0.055]' : 'divide-stone-900/[0.06] bg-[#f6f3ee] ring-stone-900/[0.045]'}`}>
                {segments.map((segment) => (
                    <div key={segment.key} className="min-w-0 px-2 text-center">
                        <span className={`flex min-w-0 items-center justify-center gap-1.5 text-[8px] font-bold uppercase tracking-[0.08em] sm:text-[9px] ${darkMode ? 'text-white/42' : 'text-stone-500'}`}>
                            <span className="h-1.5 w-1.5 shrink-0 rounded-full" style={{ backgroundColor: segment.color }} />
                            <span className="truncate">{segment.label}</span>
                        </span>
                        <div className="mt-2 flex items-baseline justify-center gap-1.5">
                            <span className={`text-base font-semibold tabular-nums ${darkMode ? 'text-white' : 'text-stone-900'}`}>
                                {segment.value}
                            </span>
                            <span className={`text-[8px] font-medium tabular-nums ${darkMode ? 'text-white/28' : 'text-stone-400'}`}>
                                {total > 0 ? Math.round((segment.value / total) * 100) : 0}%
                            </span>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

const QuoteFunnel = ({ quote, loading, error, periodLabel, darkMode }) => {
    const stages = [
        { key: 'visits', label: 'Visites de la page', value: quote.visits, icon: Eye },
        { key: 'starts', label: 'Formulaires démarrés', value: quote.starts, icon: FileText },
        { key: 'submitted', label: 'Demandes enregistrées', value: quote.submitted, icon: Send }
    ];
    const maxValue = Math.max(...stages.map(stage => stage.value), 1);
    const reducedMotion = useReducedMotion();

    if (loading) {
        return <div className={`h-44 rounded-2xl ${darkMode ? 'bg-white/[0.035]' : 'bg-stone-900/[0.035]'}`} aria-label="Chargement des signaux devis" />;
    }

    if (error) {
        return (
            <div className={`flex min-h-44 items-center justify-center rounded-2xl px-6 text-center text-sm ${darkMode ? 'bg-white/[0.035] text-white/45' : 'bg-stone-900/[0.035] text-stone-500'}`}>
                Les signaux devis sont temporairement indisponibles.
            </div>
        );
    }

    if (stages.every((stage) => stage.value === 0)) {
        return (
            <div className={`flex min-h-44 flex-col items-center justify-center rounded-2xl px-6 text-center ${darkMode ? 'bg-white/[0.035]' : 'bg-stone-900/[0.035]'}`}>
                <FileText size={22} strokeWidth={1.35} className={darkMode ? 'text-white/28' : 'text-stone-300'} />
                <p className={`mt-3 text-sm font-semibold ${darkMode ? 'text-white/58' : 'text-stone-600'}`}>
                    Aucune intention de devis sur {periodLabel}
                </p>
                <p className={`mt-1 text-[10px] ${darkMode ? 'text-white/32' : 'text-stone-400'}`}>
                    Les visites et démarrages apparaîtront automatiquement ici.
                </p>
            </div>
        );
    }

    return (
        <div className="grid min-w-0 max-w-full gap-3 overflow-hidden">
            {stages.map((stage, index) => {
                const previous = index > 0 ? stages[index - 1].value : null;
                const rate = previous > 0 ? Math.round((stage.value / previous) * 100) : null;
                const Icon = stage.icon;
                return (
                    <div key={stage.key}>
                        {index > 0 && (
                            <div className={`mb-2 ml-8 flex min-w-0 items-center gap-2 text-[8px] font-bold uppercase tracking-[0.11em] sm:ml-12 sm:text-[9px] sm:tracking-[0.14em] ${darkMode ? 'text-white/30' : 'text-stone-400'}`}>
                                <span className={`h-4 w-px ${darkMode ? 'bg-white/10' : 'bg-stone-300'}`} />
                                <span className="min-w-0 break-words">
                                    {rate === null ? 'Conversion non mesurable' : `${rate}% de l’étape précédente`}
                                </span>
                            </div>
                        )}
                        <div className={`relative min-w-0 max-w-full overflow-hidden rounded-2xl px-3 py-3.5 ring-1 sm:px-4 ${darkMode ? 'bg-white/[0.035] ring-white/[0.055]' : 'bg-[#f4f1ec] ring-stone-900/[0.045]'}`}>
                            <motion.div
                                aria-hidden="true"
                                className={`absolute inset-y-0 left-0 origin-left ${index === 2 ? (darkMode ? 'bg-[#789782]/14' : 'bg-[#cbdccf]/55') : (darkMode ? 'bg-white/[0.025]' : 'bg-[#e7e1d9]/70')}`}
                                initial={reducedMotion ? false : { scaleX: 0 }}
                                animate={{ scaleX: stage.value / maxValue }}
                                transition={{ duration: 0.75, delay: index * 0.1, ease: EASE_OUT }}
                                style={{ width: '100%' }}
                            />
                            <div className="relative flex min-w-0 items-center justify-between gap-3">
                                <div className="flex min-w-0 items-center gap-3">
                                    <span className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-xl ${darkMode ? 'bg-white/[0.055] text-white/58' : 'bg-white/75 text-stone-600'}`}>
                                        <Icon size={15} strokeWidth={1.45} />
                                    </span>
                                    <span className={`min-w-0 break-words text-[10px] font-semibold leading-tight sm:text-[11px] ${darkMode ? 'text-white/68' : 'text-stone-600'}`}>{stage.label}</span>
                                </div>
                                <span className={`shrink-0 text-lg font-semibold tracking-[-0.04em] tabular-nums sm:text-xl ${darkMode ? 'text-white' : 'text-stone-900'}`}>{stage.value}</span>
                            </div>
                        </div>
                    </div>
                );
            })}
            <p className={`mt-2 min-w-0 max-w-full break-words text-[10px] leading-relaxed ${darkMode ? 'text-white/34' : 'text-stone-400'}`}>
                « Demande enregistrée » confirme la réception dans le back-office, pas encore l’acceptation d’un devis.
            </p>
        </div>
    );
};

const MiniSparkline = ({ values, darkMode }) => {
    const width = 62;
    const height = 24;
    const max = Math.max(...values, 1);
    const points = values.map((value, index) => ({
        x: values.length > 1 ? (index / (values.length - 1)) * width : width,
        y: height - ((value / max) * (height - 8)) - 4
    }));
    const linePath = values.length > 1 ? buildBoundedMonotonePath(points) : '';
    const areaPath = linePath ? `${linePath} L ${width},${height} L 0,${height} Z` : '';
    const lastPoint = points[points.length - 1];

    return (
        <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} aria-hidden="true">
            <line
                x1="0"
                y1={height - 1}
                x2={width}
                y2={height - 1}
                stroke={darkMode ? 'rgba(255,255,255,0.08)' : 'rgba(73,69,63,0.09)'}
            />
            {linePath && (
                <>
                    <path
                        d={areaPath}
                        fill={darkMode ? 'rgba(216,211,202,0.08)' : 'rgba(98,94,87,0.08)'}
                    />
                    <path
                        d={linePath}
                        fill="none"
                        stroke={darkMode ? '#d8d3ca' : '#625e57'}
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                    />
                    <circle
                        cx={lastPoint.x}
                        cy={lastPoint.y}
                        r="2.5"
                        fill={darkMode ? '#e4dfd6' : '#4f4b45'}
                    />
                </>
            )}
        </svg>
    );
};

const TrendingProducts = ({ products, loading, error, darkMode }) => {
    if (loading) {
        return (
            <div className="flex min-w-0 max-w-full gap-2.5 overflow-hidden" aria-label="Chargement des tendances produits">
                {Array.from({ length: 5 }, (_, index) => (
                    <div
                        key={index}
                        className={`h-[266px] w-[min(72vw,190px)] shrink-0 overflow-hidden rounded-[18px] ring-1 ${darkMode ? 'bg-white/[0.025] ring-white/[0.05]' : 'bg-stone-900/[0.025] ring-stone-900/[0.035]'}`}
                    >
                        <div className={`h-[130px] ${darkMode ? 'bg-white/[0.055]' : 'bg-white/75'}`} />
                        <div className="space-y-3 p-3">
                            <span className={`block h-3 w-3/4 rounded-full ${darkMode ? 'bg-white/[0.055]' : 'bg-stone-900/[0.055]'}`} />
                            <span className={`block h-2 w-1/2 rounded-full ${darkMode ? 'bg-white/[0.035]' : 'bg-stone-900/[0.035]'}`} />
                        </div>
                    </div>
                ))}
            </div>
        );
    }

    if (error) {
        return (
            <div className={`flex min-h-72 items-center justify-center rounded-2xl px-6 text-center text-sm ${darkMode ? 'bg-white/[0.035] text-white/45' : 'bg-stone-900/[0.035] text-stone-500'}`}>
                Les tendances produits sont temporairement indisponibles.
            </div>
        );
    }

    if (products.length === 0) {
        return (
            <div className={`flex min-h-72 flex-col items-center justify-center rounded-2xl px-6 text-center ${darkMode ? 'bg-white/[0.035]' : 'bg-stone-900/[0.035]'}`}>
                <Eye size={22} strokeWidth={1.35} className={darkMode ? 'text-white/28' : 'text-stone-300'} />
                <p className={`mt-3 text-sm font-semibold ${darkMode ? 'text-white/58' : 'text-stone-600'}`}>Aucune fiche produit vue sur la période</p>
            </div>
        );
    }

    return (
        <ol className="no-scrollbar flex min-w-0 max-w-full snap-x snap-mandatory gap-2.5 overflow-x-auto overscroll-x-contain pb-2 pr-3 [scrollbar-width:none]">
            {products.map((product, index) => {
                return (
                    <motion.li
                        key={product.id}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ duration: 0.42, delay: index * 0.045, ease: EASE_OUT }}
                        className={`group relative isolate h-[266px] w-[min(72vw,190px)] shrink-0 snap-start overflow-hidden rounded-[18px] ring-1 transition-[background-color,box-shadow] duration-300 ease-out sm:w-[190px] hover:shadow-[0_18px_38px_-30px_rgba(45,42,38,0.42)] ${darkMode ? 'bg-white/[0.028] ring-white/[0.06] hover:bg-white/[0.038]' : 'bg-[#f6f3ee] ring-stone-900/[0.045] hover:bg-[#f1ede7]'}`}
                    >
                        <div className={`relative h-[130px] w-full overflow-hidden border-b ${darkMode ? 'bg-[#20231f] border-white/[0.06]' : 'bg-[#e9e5df] border-white/70'}`}>
                            {product.imageUrl ? (
                                // Le snapshot fournit deja une miniature WebP 320/384; pas de proxy Next pour l'admin.
                                // eslint-disable-next-line @next/next/no-img-element
                                <img
                                    src={product.imageUrl}
                                    alt={product.imageAlt}
                                    loading="lazy"
                                    decoding="async"
                                    className="h-full w-full object-cover transition-[filter] duration-300 group-hover:saturate-[1.06]"
                                />
                            ) : (
                                <span className={`flex h-full w-full items-center justify-center ${darkMode ? 'text-white/25' : 'text-stone-400'}`} aria-hidden="true">
                                    <PackageCheck size={23} strokeWidth={1.25} />
                                </span>
                            )}
                            <span className={`absolute left-2 top-2 rounded-md px-1.5 py-1 text-[8px] font-bold tracking-[0.08em] tabular-nums backdrop-blur-md ${index === 0 ? (darkMode ? 'bg-white/90 text-stone-900' : 'bg-stone-900/90 text-white') : (darkMode ? 'bg-black/60 text-white/75' : 'bg-white/85 text-stone-700')}`}>
                                #{String(index + 1).padStart(2, '0')}
                            </span>
                        </div>

                        <div className="relative flex h-[136px] flex-col p-3.5">
                            <p className={`truncate text-[13px] font-semibold tracking-[-0.01em] ${darkMode ? 'text-white/88' : 'text-stone-800'}`} title={product.name}>
                                {product.name}
                            </p>
                            <div className="mt-1 flex min-w-0 items-center gap-1.5">
                                <span className={`truncate text-[9px] font-medium ${darkMode ? 'text-white/38' : 'text-stone-500'}`}>
                                    {product.viewers} session{product.viewers > 1 ? 's' : ''} intéressée{product.viewers > 1 ? 's' : ''}
                                </span>
                                {product.price !== null && (
                                    <>
                                        <span className={darkMode ? 'text-white/16' : 'text-stone-300'} aria-hidden="true">•</span>
                                        <span className={`shrink-0 text-[8px] font-semibold tabular-nums ${darkMode ? 'text-white/42' : 'text-stone-500'}`}>
                                            {product.price.toLocaleString('fr-FR')} €
                                        </span>
                                    </>
                                )}
                            </div>

                            <div className="mt-auto flex items-end justify-between gap-2">
                                <MiniSparkline values={product.dailyViews} darkMode={darkMode} />
                                <div className="shrink-0 text-right">
                                    <p className={`text-lg font-semibold leading-none tracking-[-0.04em] tabular-nums ${darkMode ? 'text-white' : 'text-stone-900'}`}>{product.views}</p>
                                    <p className={`mt-1 text-[7px] font-bold uppercase tracking-[0.12em] ${darkMode ? 'text-white/32' : 'text-stone-500'}`}>vues</p>
                                </div>
                            </div>
                        </div>
                    </motion.li>
                );
            })}
        </ol>
    );
};

const DashboardSkeleton = ({ darkMode }) => (
    <div className="space-y-6 pb-20" aria-busy="true" aria-label="Chargement du tableau de bord">
        <div className={`h-20 rounded-[28px] ${darkMode ? 'bg-white/[0.035]' : 'bg-stone-900/[0.035]'}`} />
        <div className="grid gap-5 lg:grid-cols-12">
            {[5, 2, 2, 3].map((span, index) => (
                <div
                    key={`${span}-${index}`}
                    className={`h-44 rounded-[28px] ${darkMode ? 'bg-white/[0.035]' : 'bg-stone-900/[0.035]'} ${span === 5 ? 'lg:col-span-5' : span === 3 ? 'lg:col-span-3' : 'lg:col-span-2'}`}
                />
            ))}
        </div>
        <div className="grid gap-5 lg:grid-cols-12">
            <div className={`h-96 rounded-[28px] lg:col-span-8 ${darkMode ? 'bg-white/[0.035]' : 'bg-stone-900/[0.035]'}`} />
            <div className={`h-96 rounded-[28px] lg:col-span-4 ${darkMode ? 'bg-white/[0.035]' : 'bg-stone-900/[0.035]'}`} />
        </div>
        <span className="sr-only">Chargement des statistiques…</span>
    </div>
);

const buildDashboardProductVisualMap = (items) => {
    const products = new Map();
    (Array.isArray(items) ? items : []).forEach((item) => {
        const [primaryImage] = getProductImageItems(item);
        const imageUrl = primaryImage?.thumb320
            || primaryImage?.thumb384
            || primaryImage?.thumb
            || primaryImage?.card
            || item?.thumbnailUrl
            || item?.imageUrl
            || null;

        const productName = String(item?.name || item?.title || 'Meuble').trim();
        const pathKey = decodeURIComponent(String(getProductUrl(item)).split('/').filter(Boolean).pop() || '');
        const visual = {
            imageUrl,
            imageAlt: productName ? `${productName}, meuble du catalogue` : 'Meuble du catalogue',
            catalogName: productName,
            catalogPrice: Number.isFinite(Number(item?.price)) ? Number(item.price) : null
        };

        [item?.id, item?.originalId, pathKey]
            .map((value) => String(value || '').trim())
            .filter(Boolean)
            .forEach((key) => products.set(key, visual));
    });
    return products;
};

const getOrderStatus = (order) => {
    const journey = getOrderJourney(order);
    return { ...journey, tone: ({ positive: 'success', transit: 'info', progress: 'warning', danger: 'warning', neutral: 'info' })[journey.tone] || journey.tone };
};

const getRelativeOrderDate = (value) => {
    const timestamp = getMillis(value);
    if (!timestamp) return 'Date inconnue';
    const diffDays = Math.floor((Date.now() - timestamp) / (24 * 60 * 60 * 1000));
    if (diffDays <= 0) return "Aujourd’hui";
    if (diffDays === 1) return 'Hier';
    if (diffDays < 7) return `Il y a ${diffDays} jours`;
    return new Date(timestamp).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short' });
};

const QUOTE_PERIODS = Object.freeze([
    { id: '30d', label: '30 jours', shortLabel: '30 j' },
    { id: '3m', label: '3 mois', shortLabel: '3 mois' },
    { id: '6m', label: '6 mois', shortLabel: '6 mois' },
    { id: '1y', label: '1 an', shortLabel: '1 an' }
]);
const EMPTY_QUOTE_WINDOWS = Object.freeze(Object.fromEntries(
    QUOTE_PERIODS.map(({ id }) => [id, Object.freeze({ visits: 0, starts: 0, submitted: 0 })])
));

const EMPTY_INSIGHTS = Object.freeze({
    loading: true,
    error: false,
    productsState: 'not_materialized',
    quote: { visits: 0, starts: 0, submitted: 0 },
    quoteWindows: EMPTY_QUOTE_WINDOWS,
    products: [],
    totalProductViews: 0,
    productViewingSessions: 0
});

const readInsights = (snapshot) => {
        const data = snapshot?.exists() ? validateInsights(snapshot.data()) : null;
        if (!data) throw new Error('ADMIN_DASHBOARD_INSIGHTS_UNAVAILABLE');
        return {
            loading: false,
            error: false,
            productsState: data.productsState,
            quote: data.quote,
            quoteWindows: data.quoteWindows || {
                ...EMPTY_QUOTE_WINDOWS,
                '30d': data.quote
            },
            products: data.productsState === 'ready' ? data.products : [],
            totalProductViews: data.products.reduce((sum, product) => sum + Number(product.views || 0), 0),
            productViewingSessions: Number(data.productViewingSessions || 0)
        };
};

// The Stats data path is listener-driven. This export remains a code-preload
// compatibility hook and deliberately performs no Firestore read.
export const preloadAdminDashboardData = async () => undefined;
// ─── ADMIN DASHBOARD ───

const AdminDashboard = ({
    user,
    darkMode = false,
    isSuperAdmin = false,
    items = [],
    onLoadCatalog = null,
    strongAuthReadyAt = null,
    backOfficeReadyAt = null,
    commerceStatus = { status: 'loading', data: null, error: null }
}) => {
    void isSuperAdmin;
    void commerceStatus;
    let cachedInsights = null;
    try { cachedInsights = readInsights(dashboardInsights.get()); } catch { /* Première lecture ou projection invalide. */ }
    const unavailableDomains = () => Object.fromEntries(
        CRITICAL_DOCUMENT_IDS.map((id) => [id, { status: 'unavailable', data: null }])
    );
    const [projection, setProjection] = useState(() => dashboardKpis.get() ? {
        ...validateCriticalSnapshot(dashboardKpis.get()), loading: false
    } : {
        loading: true,
        fromCache: false,
        serverConfirmed: false,
        domains: unavailableDomains()
    });
    const [criticalAccessFailed, setCriticalAccessFailed] = useState(false);
    const revisionsRef = useRef({});
    const timingRef = useRef({ backOfficeReadyAt, strongAuthReadyAt });
    timingRef.current = { backOfficeReadyAt, strongAuthReadyAt };
    const insightsAnchorRef = useRef(null);
    const [insightsRetry, setInsightsRetry] = useState(0);
    const [salesPanelView, setSalesPanelView] = useState('summary');
    const [timeFilter, setTimeFilter] = useAdminPreference('stats:finance-period', '1month');
    const [intradayOrders, setIntradayOrders] = useState(null);
    const [intradayOrdersLoading, setIntradayOrdersLoading] = useState(false);
    const intradayRequestRef = useRef(false);
    const historyRequestRef = useRef(0);
    const mountedRef = useRef(true);
    useEffect(() => {
        mountedRef.current = true;
        return () => { mountedRef.current = false; historyRequestRef.current++; };
    }, []);
    const [dailySales, setDailySales] = useState([]);
    const [financialHistoryLoading, setFinancialHistoryLoading] = useState(false);
    const [financialHistoryError, setFinancialHistoryError] = useState(false);
    const [recentOrders, setRecentOrders] = useState(() => (dashboardOrders.get()?.docs || [])
        .map(document => ({ id: document.id, ...document.data() }))
        .filter(order => !['cancelled', 'cancelled_by_client', 'canceled'].includes(order.status)));
    const [recentOrdersStatus, setRecentOrdersStatus] = useState(dashboardOrders.get() ? 'ready' : 'loading');
    const [insights, setInsights] = useState(cachedInsights || EMPTY_INSIGHTS);
    const [quotePeriod, setQuotePeriod] = useAdminPreference('stats:quote-period', '30d');
    const trendingProducts = useMemo(() => {
        const visuals = buildDashboardProductVisualMap(items);
        return insights.products
            .filter((product) => visuals.has(product.id))
            .slice(0, 5)
            .map((product) => {
                const visual = visuals.get(product.id);
                return {
                    ...product,
                    name: product.name === product.id && visual?.catalogName ? visual.catalogName : product.name,
                    price: product.price ?? visual?.catalogPrice ?? null,
                    ...visual
                };
            });
    }, [insights.products, items]);
    const reducedMotion = useReducedMotion();

    // Operation states
    const [exportingUsers, setExportingUsers] = useState(false);
    const [intradayOrdersError, setIntradayOrdersError] = useState(false);

    const selectTimeFilter = async (filterId) => {
        const request = ++historyRequestRef.current;
        setTimeFilter(filterId);
        if (!['1hour', '1day'].includes(filterId)) {
            setFinancialHistoryLoading(true);
            setFinancialHistoryError(false);
            try {
                let historyQuery;
                if (filterId === '7days' || filterId === '1month') {
                    const days = filterId === '7days' ? 7 : 30;
                    const cutoff = new Date(Date.now() - ((days - 1) * 24 * 60 * 60 * 1000))
                        .toISOString().slice(0, 10);
                    historyQuery = query(
                        collection(db, 'admin_finance_history_days'),
                        where('dateKey', '>=', cutoff),
                        orderBy('dateKey', 'asc'),
                        limit(days)
                    );
                } else if (filterId === '1year') {
                    const start = new Date();
                    start.setUTCDate(1);
                    start.setUTCHours(0, 0, 0, 0);
                    start.setUTCMonth(start.getUTCMonth() - 11);
                    const cutoff = start.toISOString().slice(0, 7);
                    historyQuery = query(
                        collection(db, 'admin_finance_history_months'),
                        where('monthKey', '>=', cutoff),
                        orderBy('monthKey', 'asc'),
                        limit(12)
                    );
                } else {
                    historyQuery = query(
                        collection(db, 'admin_finance_history_years'),
                        orderBy('yearKey', 'desc'),
                        limit(50)
                    );
                }
                const key = `admin-dashboard:history:${filterId}:${new Date().toISOString().slice(0, 10)}:${projection.domains.finance.data?.revision ?? 'unknown'}`;
                const rows = await loadAdminCachedData(key, async () => {
                    const snapshot = await getDocs(historyQuery);
                    return snapshot.docs.map((document) => ({ id: document.id, ...document.data() }));
                }, { maxAgeMs: 30_000 });
                if (request !== historyRequestRef.current) return;
                setDailySales(filterId === 'max' ? [...rows].reverse() : rows);
            } catch (error) {
                if (request !== historyRequestRef.current) return;
                console.error('Failed to fetch requested financial history', error?.code || error?.name);
                setDailySales([]);
                setFinancialHistoryError(true);
            } finally {
                if (request === historyRequestRef.current) setFinancialHistoryLoading(false);
            }
            return;
        }
        setFinancialHistoryLoading(false);
        setFinancialHistoryError(false);
        if (intradayOrders !== null || intradayRequestRef.current) return;

        intradayRequestRef.current = true;
        setIntradayOrdersError(false);
        setIntradayOrdersLoading(true);
        const cutoff = new Date(Date.now() - (24 * 60 * 60 * 1000)).toISOString();
        try {
            const snapshot = await getDocs(query(
                collection(db, 'orders'),
                where('payment.succeededAt', '>=', cutoff),
                orderBy('payment.succeededAt', 'asc'),
                limit(301)
            ));
            if (!mountedRef.current) return;
            if (snapshot.size > 300) throw new Error('INTRADAY_ORDER_LIMIT');
            setIntradayOrders(snapshot.docs.map((docSnap) => ({ id: docSnap.id, ...docSnap.data() })));
        } catch (error) {
            if (!mountedRef.current) return;
            console.error('Failed to fetch intraday sales', error?.code || error?.message);
            setIntradayOrdersError(true);
        } finally {
            intradayRequestRef.current = false;
            setIntradayOrdersLoading(false);
        }
    };

    const chartData = useMemo(() => {
        if (['1hour', '1day'].includes(timeFilter)) {
            if (!intradayOrders) return [];
            const end = Date.now();
            const duration = timeFilter === '1hour' ? 60 * 60 * 1000 : 24 * 60 * 60 * 1000;
            const step = timeFilter === '1hour' ? 5 * 60 * 1000 : 60 * 60 * 1000;
            const pointCount = Math.ceil(duration / step);
            const start = end - duration;
            const points = Array.from({ length: pointCount }, (_, index) => {
                const slotStart = start + (index * step);
                const slotEnd = slotStart + step;
                const date = new Date(slotStart);
                const axisLabel = date.toLocaleTimeString('fr-FR', {
                    hour: '2-digit',
                    minute: timeFilter === '1hour' ? '2-digit' : undefined
                });
                return {
                    dateKey: new Date(slotStart).toISOString(),
                    axisLabel,
                    label: axisLabel,
                    tooltipLabel: `${date.toLocaleDateString('fr-FR', {
                        day: 'numeric',
                        month: 'short'
                    })} · ${axisLabel}`,
                    slotStart,
                    slotEnd,
                    value: 0
                };
            });

            intradayOrders.forEach((order) => {
                    const capture = getConfirmedCapture(order);
                    if (!capture) return;
                    const { timestamp, amount } = capture;
                    if (!timestamp || timestamp < start || timestamp > end) return;
                    const pointIndex = Math.min(pointCount - 1, Math.floor((timestamp - start) / step));
                    points[pointIndex].value += amount;
                });

            return points;
        }

        if (!dailySales.length) return [];
        if (timeFilter === '1year' || timeFilter === 'max') {
            return dailySales.map((entry) => {
                const key = timeFilter === '1year' ? entry.monthKey : entry.yearKey;
                const date = new Date(timeFilter === '1year' ? `${key}-01T00:00:00Z` : `${key}-01-01T00:00:00Z`);
                return {
                    dateKey: key,
                    axisLabel: timeFilter === '1year'
                        ? date.toLocaleDateString('fr-FR', { month: 'short', timeZone: 'UTC' })
                        : key,
                    label: timeFilter === '1year'
                        ? date.toLocaleDateString('fr-FR', { month: 'long', year: 'numeric', timeZone: 'UTC' })
                        : key,
                    tooltipLabel: timeFilter === '1year'
                        ? date.toLocaleDateString('fr-FR', { month: 'long', year: 'numeric', timeZone: 'UTC' })
                        : `Année ${key}`,
                    value: Number(entry.totalRevenueCents || 0) / 100
                };
            });
        }
        const now = new Date();
        const endOfTodayUtc = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate());
        const earliestDailyTimestamp = Date.parse(`${dailySales[0]?.dateKey}T00:00:00Z`);
        const periodDays = timeFilter === '7days'
            ? 7
            : timeFilter === '1month'
                ? 30
                : timeFilter === 'max' && Number.isFinite(earliestDailyTimestamp)
                    ? Math.max(1, Math.floor((endOfTodayUtc - earliestDailyTimestamp) / (24 * 60 * 60 * 1000)) + 1)
                    : 365;
        const revenueByDate = new Map();

        dailySales.forEach(({ dateKey, totalRevenueCents }) => {
            if (!dateKey) return;
            revenueByDate.set(dateKey, (revenueByDate.get(dateKey) || 0) + (Number(totalRevenueCents || 0) / 100));
        });

        return Array.from({ length: periodDays }, (_, index) => {
            const date = new Date(endOfTodayUtc - ((periodDays - 1 - index) * 24 * 60 * 60 * 1000));
            const dateKey = date.toISOString().slice(0, 10);
            const axisLabel = date.toLocaleDateString('fr-FR', {
                day: '2-digit',
                month: 'short',
                timeZone: 'UTC'
            });

            return {
                dateKey,
                axisLabel,
                label: axisLabel,
                tooltipLabel: date.toLocaleDateString('fr-FR', {
                    weekday: 'long',
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric',
                    timeZone: 'UTC'
                }),
                value: Number(revenueByDate.get(dateKey)) || 0
            };
        });
    }, [dailySales, intradayOrders, timeFilter]);

    const revenueSummary = useMemo(() => {
        const periodTotal = chartData.reduce((sum, point) => sum + Number(point.value || 0), 0);
        const bestPoint = chartData.reduce(
            (best, point) => Number(point.value || 0) > Number(best?.value || 0) ? point : best,
            null
        );

        return {
            periodTotal,
            bestPoint
        };
    }, [chartData]);
    useEffect(() => {
        revisionsRef.current = {};
        setInsights(EMPTY_INSIGHTS);
        if (!dashboardKpis.get()) setProjection({ loading: true, fromCache: false, serverConfirmed: false, domains: unavailableDomains() });
        setCriticalAccessFailed(false);
        setDailySales([]);
        setFinancialHistoryLoading(false);
        setFinancialHistoryError(false);
        setIntradayOrders(null);
        if (!user?.uid) return undefined;
        if (typeof performance !== 'undefined') performance.mark('admin-dashboard-listener-start');
        return dashboardKpis.subscribe((snapshot) => {
            const { backOfficeReadyAt, strongAuthReadyAt } = timingRef.current;
            const validated = validateCriticalSnapshot(snapshot, revisionsRef.current);
            revisionsRef.current = validated.revisions;
            setCriticalAccessFailed(false);
            setProjection({ ...validated, loading: false });
            if (validated.serverConfirmed && typeof performance !== 'undefined') {
                const measuredAt = performance.now();
                performance.mark('admin-dashboard-kpi-server', {
                    detail: { criticalProjectionDocuments: snapshot.size }
                });
                performance.measure(
                    'admin-dashboard-listener-to-kpi',
                    'admin-dashboard-listener-start',
                    'admin-dashboard-kpi-server'
                );
                if (Number.isFinite(backOfficeReadyAt)) {
                    performance.measure('admin-dashboard-backoffice-ready-to-kpi', {
                        start: backOfficeReadyAt,
                        end: measuredAt,
                        detail: { criticalProjectionDocuments: snapshot.size }
                    });
                }
                if (Number.isFinite(strongAuthReadyAt)) {
                    performance.measure('admin-dashboard-strong-auth-to-kpi', {
                        start: strongAuthReadyAt,
                        end: measuredAt,
                        detail: { criticalProjectionDocuments: snapshot.size }
                    });
                }
            }
        }, (error) => {
            console.error('Admin dashboard projection listener failed', error?.code || error?.name);
            revisionsRef.current = {};
            setRecentOrders([]);
            setDailySales([]);
            setIntradayOrders(null);
            setInsights({ ...EMPTY_INSIGHTS, loading: false, error: true });
            dashboardInsights.clear();
            setCriticalAccessFailed(true);
            setProjection({ loading: false, fromCache: false, serverConfirmed: false, domains: unavailableDomains() });
        });
    }, [user?.uid]);

    useEffect(() => {
        if (projection.loading || criticalAccessFailed || !user?.uid) return undefined;
        return dashboardOrders.subscribe((snapshot) => {
            setRecentOrdersStatus(snapshot.metadata?.fromCache && snapshot.size === 0 ? 'loading' : 'ready');
            setRecentOrders(snapshot.docs
                .map((document) => ({ id: document.id, ...document.data() }))
                .filter((order) => !['cancelled', 'cancelled_by_client', 'canceled'].includes(order.status)));
        }, () => { setRecentOrders([]); setRecentOrdersStatus('error'); });
    }, [criticalAccessFailed, projection.loading, user?.uid]);

    useEffect(() => {
        const anchor = insightsAnchorRef.current;
        if (!anchor || projection.loading || criticalAccessFailed || !user?.uid) return undefined;
        let cancelled = false;
        let requested = false;
        let stopInsights;
        const requestInsights = () => {
            if (requested || cancelled) return;
            requested = true;
            stopInsights = dashboardInsights.subscribe(snapshot => {
                if (cancelled) return;
                try {
                    const data = readInsights(snapshot);
                    setInsights(data);
                    if (data.products.length) void Promise.resolve(onLoadCatalog?.()).catch(() => {});
                }
                catch { setInsights({ ...EMPTY_INSIGHTS, loading: false, error: true }); }
            }, () => { if (!cancelled) setInsights({ ...EMPTY_INSIGHTS, loading: false, error: true }); });
        };
        if (typeof IntersectionObserver !== 'function') {
            requestInsights();
            return () => { cancelled = true; stopInsights?.(); };
        }
        const observer = new IntersectionObserver(([entry]) => {
            if (entry?.isIntersecting) {
                observer.disconnect();
                requestInsights();
            }
        }, { rootMargin: '240px 0px' });
        observer.observe(anchor);
        return () => {
            cancelled = true;
            stopInsights?.();
            observer.disconnect();
        };
    }, [criticalAccessFailed, projection.loading, onLoadCatalog, user?.uid, insightsRetry]);
    // ─── ACTIONS ───
    const handleExportUsers = async () => {
        if (exportingUsers) return;
        setExportingUsers(true);
        const generation = getAdminCacheGeneration();
        try {
            const getUserStatsFn = await getCallableFunction('getUserStats');
            const users = await collectAdminUsers(getUserStatsFn, () => mountedRef.current && generation === getAdminCacheGeneration());

            const data = users.map(u => ({
                'ID': u.uid, 'Email': u.email, 'Nom': u.displayName,
                'Inscription': new Date(u.creationTime).toLocaleDateString(),
                'Connexion': new Date(u.lastSignInTime).toLocaleDateString()
            }));

            downloadCsv(data, 'Clients');

            alert(`✅ Export réussi : ${users.length} clients exportés.`);
        } catch (error) { if (mountedRef.current) alert("Erreur export utilisateurs: " + error.message); }
        finally { if (mountedRef.current) setExportingUsers(false); }
    };

    if (projection.loading) return <DashboardSkeleton darkMode={darkMode} />;

    const textBase = darkMode ? 'text-white' : 'text-stone-900';
    const textMuted = darkMode ? 'text-white/40' : 'text-stone-400';
    const financeDomain = projection.domains.finance;
    const ordersDomain = projection.domains.orders;
    const activityDomain = projection.domains.activity;
    const financialAmounts = financeDomain.data;
    const orderSummary = ordersDomain.data;
    const activity = activityDomain.data;
    const financialUnavailable = financeDomain.status !== 'ready';
    const ordersUnavailable = ordersDomain.status !== 'ready';
    const activityUnavailable = activityDomain.status !== 'ready';
    const capturedRevenue = financialAmounts?.capturedCents / 100 || 0;
    const refundedRevenue = financialAmounts?.refundedCents / 100 || 0;
    const netRevenue = financialAmounts?.netCents / 100 || 0;
    const displayedStatusCounts = {
        paid: Number(orderSummary?.paidOrders || 0),
        shipped: Number(orderSummary?.shippedOrders || 0),
        pending: Number(orderSummary?.pendingOrders || 0)
    };
    const displayedOrderCount = Number(orderSummary?.totalOrders || 0);
    const paidOrderCount = Number(financialAmounts?.capturedOrderCount || 0);
    const averagePaidOrderValue = paidOrderCount > 0 ? capturedRevenue / paidOrderCount : 0;
    const projectionFreshnessLabel = criticalAccessFailed ? 'Lecture impossible' : projection.serverConfirmed
        ? Object.values(projection.domains).every(domain => domain.status === 'ready') ? 'Synchronisés' : 'Données partielles'
        : 'Actualisation…';
    const selectedQuotePeriod = QUOTE_PERIODS.find(({ id }) => id === quotePeriod) || QUOTE_PERIODS[0];
    const selectedQuote = insights.quoteWindows?.[selectedQuotePeriod.id] || EMPTY_QUOTE_WINDOWS[selectedQuotePeriod.id];

    const getFilterLabel = () => {
        if (timeFilter === '1hour') return "la dernière heure";
        if (timeFilter === '1day') return "les dernières 24 heures";
        if (timeFilter === '7days') return "les 7 derniers jours";
        if (timeFilter === '1month') return "les 30 derniers jours";
        if (timeFilter === 'max') return "tout l’historique disponible";
        return "les 365 derniers jours";
    };

    const chartGranularityLabel = timeFilter === '1hour'
        ? 'Vue par 5 minutes'
        : timeFilter === '1day'
            ? 'Vue horaire'
            : timeFilter === '1year'
                ? 'Vue mensuelle'
                : timeFilter === 'max'
                    ? 'Vue annuelle'
                    : 'Vue quotidienne';
    const bestPointLabel = ['1hour', '1day'].includes(timeFilter)
        ? 'Meilleur créneau'
        : timeFilter === '1year'
            ? 'Meilleur mois'
            : timeFilter === 'max'
                ? 'Meilleure année'
                    : 'Meilleur jour';
    const intraday = ['1hour', '1day'].includes(timeFilter);
    const chartUnavailable = intraday ? intradayOrdersError : financialHistoryError;
    const chartLoading = intraday ? intradayOrdersLoading : financialHistoryLoading;
    return (
        <motion.div
            initial={reducedMotion ? false : 'hidden'}
            animate="visible"
            className="space-y-5 pb-20 font-sans sm:space-y-6"
        >
            <p aria-live="polite" className={`text-right text-[10px] font-semibold ${textMuted}`}>
                KPI · {projectionFreshnessLabel}
                {criticalAccessFailed && <button className="ml-3 underline" onClick={() => dashboardKpis.retry()}>Réessayer</button>}
            </p>
            <motion.div custom={0} variants={sectionVariants} className="grid gap-5 lg:grid-cols-12">
                <KpiCard
                    label="Ventes nettes"
                    value={netRevenue}
                    format={formatEuroAmount}
                    icon={CircleDollarSign}
                    meta={refundedRevenue > 0 ? `${formatEuroAmount(refundedRevenue)} remboursés` : 'Après remboursements'}
                    delta={null}
                    darkMode={darkMode}
                    loading={false}
                    unavailable={financialUnavailable}
                    accent
                    className="lg:col-span-3"
                />
                <KpiCard
                    label="Commandes"
                    value={displayedOrderCount}
                    icon={ShoppingBag}
                    meta={`${paidOrderCount} encaissées`}
                    darkMode={darkMode}
                    unavailable={ordersUnavailable}
                    className="lg:col-span-3"
                />
                <KpiCard
                    label="Panier moyen"
                    value={averagePaidOrderValue}
                    format={formatEuroAmount}
                    icon={PackageCheck}
                    meta={paidOrderCount > 0 ? `Sur ${paidOrderCount} commandes encaissées` : 'Aucune commande encaissée'}
                    darkMode={darkMode}
                    loading={false}
                    unavailable={financialUnavailable}
                    className="lg:col-span-3"
                />
                <KpiCard
                    label="Clients inscrits"
                    value={activity?.users?.registeredUsers || 0}
                    icon={Users}
                    meta={activityUnavailable
                        ? 'Valeur catalogue : —'
                        : `Catalogue : ${(activity.catalog.stockValueCents / 100).toLocaleString('fr-FR')} €`}
                    darkMode={darkMode}
                    loading={false}
                    unavailable={activityUnavailable}
                    className="lg:col-span-3"
                    action={(
                        <button
                            type="button"
                            onClick={handleExportUsers}
                            disabled={exportingUsers}
                            aria-label="Exporter les clients au format CSV"
                            className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-xl ring-1 transition-[transform,background-color,color] duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#62816c] disabled:cursor-wait disabled:opacity-50 ${darkMode ? 'bg-white/[0.055] text-white/58 ring-white/[0.07] hover:bg-white/10 hover:text-white' : 'bg-[#eee9e2] text-stone-600 ring-stone-900/[0.055] hover:bg-[#ded7ce] hover:text-stone-900'}`}
                        >
                            {exportingUsers ? <RefreshCw size={14} className="animate-spin" strokeWidth={1.45} /> : <Archive size={14} strokeWidth={1.45} />}
                        </button>
                    )}
                />
            </motion.div>

            <motion.div custom={1} variants={sectionVariants} className="grid gap-5 lg:grid-cols-12">
                <PanelFrame darkMode={darkMode} className="min-w-0 lg:col-span-8" innerClassName="overflow-hidden p-5 sm:p-7">
                    <div className="flex min-w-0 flex-col gap-6">
                        <div className="flex flex-col justify-between gap-5 xl:flex-row xl:items-start">
                            <div>
                                <p className={`text-[9px] font-bold uppercase tracking-[0.18em] ${textMuted}`}>
                                    {salesPanelView === 'summary' ? 'Paiements' : 'Performance'}
                                </p>
                                <h2 className={`mt-2 text-xl font-semibold tracking-[-0.03em] ${textBase}`}>
                                    {salesPanelView === 'summary' ? 'Bilan des ventes' : 'Évolution du chiffre d’affaires'}
                                </h2>
                                <p className={`mt-1 text-[11px] ${textMuted}`}>
                                    {salesPanelView === 'summary'
                                        ? 'Montants cumulés après remboursements'
                                        : `${chartGranularityLabel} · ${getFilterLabel()}${intraday ? ' · Paiements des commandes, avant remboursements et hors factures manuelles' : ''}`}
                                </p>
                            </div>
                            <div className="flex w-full flex-col gap-1.5 xl:w-auto xl:items-end">
                                <div
                                    role="group"
                                    aria-label="Affichage des ventes"
                                    className={`grid w-full grid-cols-2 gap-0.5 rounded-[10px] p-0.5 ring-1 xl:w-auto ${darkMode ? 'bg-white/[0.035] ring-white/[0.055]' : 'bg-[#f1ede7] ring-stone-900/[0.045]'}`}
                                >
                                    {[
                                        { id: 'summary', label: 'Bilan' },
                                        { id: 'chart', label: 'Graphique' }
                                    ].map((view) => (
                                        <button
                                            type="button"
                                            key={view.id}
                                            onClick={() => {
                                                setSalesPanelView(view.id);
                                                if (view.id === 'chart') void selectTimeFilter(timeFilter);
                                            }}
                                            aria-pressed={salesPanelView === view.id}
                                            className={`rounded-lg px-4 py-1.5 text-[8px] font-bold uppercase tracking-[0.08em] transition-[transform,background-color,color] duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] active:scale-[0.98] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#62816c] ${
                                                salesPanelView === view.id
                                                    ? (darkMode ? 'bg-[#f4f2ed] text-[#1e211f]' : 'bg-white text-stone-900 shadow-[0_8px_22px_-20px_rgba(38,35,31,0.62)]')
                                                    : (darkMode ? 'text-white/38 hover:text-white/75' : 'text-stone-400 hover:text-stone-700')
                                            }`}
                                        >
                                            {view.label}
                                        </button>
                                    ))}
                                </div>
                                {salesPanelView === 'chart' && (
                                    <div
                                        role="group"
                                        aria-label="Période du graphique"
                                        className={`grid w-full shrink-0 grid-cols-3 gap-0.5 rounded-[10px] p-0.5 ring-1 sm:grid-cols-6 xl:w-auto ${darkMode ? 'bg-white/[0.035] ring-white/[0.055]' : 'bg-[#f1ede7] ring-stone-900/[0.045]'}`}
                                    >
                                        {[
                                            { id: '1hour', label: '1h' },
                                            { id: '1day', label: '24h' },
                                            { id: '7days', label: '7j' },
                                            { id: '1month', label: '1 mois' },
                                            { id: '1year', label: '1 an' },
                                            { id: 'max', label: 'Max' }
                                        ].map((filter) => (
                                            <button
                                                type="button"
                                                key={filter.id}
                                                onClick={() => void selectTimeFilter(filter.id)}
                                                aria-pressed={timeFilter === filter.id}
                                                className={`rounded-lg px-2.5 py-1.5 text-[8px] font-bold uppercase tracking-[0.06em] transition-[transform,background-color,color] duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] active:scale-[0.98] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#62816c] ${
                                                    timeFilter === filter.id
                                                        ? (darkMode ? 'bg-[#f4f2ed] text-[#1e211f]' : 'bg-white text-stone-900 shadow-[0_8px_22px_-20px_rgba(38,35,31,0.62)]')
                                                        : (darkMode ? 'text-white/38 hover:text-white/75' : 'text-stone-400 hover:text-stone-700')
                                                }`}
                                            >
                                                {filter.label}
                                            </button>
                                        ))}
                                    </div>
                                )}
                            </div>
                        </div>
                        {salesPanelView === 'summary' ? (
                            <div className="grid gap-3 sm:grid-cols-3">
                                {[
                                    ['Encaissé', financialAmounts?.capturedCents],
                                    ['Remboursé', financialAmounts?.refundedCents],
                                    ['Ventes nettes', financialAmounts?.netCents]
                                ].map(([label, cents]) => (
                                    <div key={label} className={`rounded-2xl p-4 ring-1 ${darkMode ? 'bg-white/[0.03] ring-white/[0.06]' : 'bg-stone-900/[0.025] ring-stone-900/[0.05]'}`}>
                                        <p className={`text-[9px] font-bold uppercase tracking-[0.14em] ${textMuted}`}>{label}</p>
                                        <p className={`mt-2 text-lg font-semibold tabular-nums ${textBase}`}>
                                            {Number.isSafeInteger(cents) ? `${(cents / 100).toLocaleString('fr-FR', { minimumFractionDigits: 2 })} €` : '—'}
                                        </p>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <>
                                <div className="flex gap-5">
                                    <div>
                                        <p className={`text-[8px] font-bold uppercase tracking-[0.13em] ${textMuted}`}>Total période</p>
                                        <p className={`mt-1 text-sm font-semibold tabular-nums ${textBase}`}>{chartUnavailable || chartLoading ? '—' : `${Math.round(revenueSummary.periodTotal).toLocaleString('fr-FR')} €`}</p>
                                    </div>
                                    <div>
                                        <p className={`text-[8px] font-bold uppercase tracking-[0.13em] ${textMuted}`}>{bestPointLabel}</p>
                                        <p className={`mt-1 text-sm font-semibold tabular-nums ${textBase}`}>{revenueSummary.bestPoint?.label || '—'}</p>
                                    </div>
                                </div>
                                {chartLoading ? (
                                    <div className={`flex h-[240px] items-center justify-center rounded-2xl px-6 text-center text-sm ${darkMode ? 'bg-white/[0.03] text-white/38' : 'bg-stone-900/[0.03] text-stone-400'}`}>
                                        Chargement des ventes récentes…
                                    </div>
                                ) : chartUnavailable ? (
                                    <div className={`flex h-[240px] items-center justify-center rounded-2xl px-6 text-center text-sm ${darkMode ? 'bg-white/[0.03] text-white/38' : 'bg-stone-900/[0.03] text-stone-400'}`}>
                                        Données indisponibles.
                                    </div>
                                ) : chartData.length > 0 ? (
                                    <RevenueChart data={chartData} darkMode={darkMode} />
                                ) : (
                                    <div className={`flex h-[240px] items-center justify-center rounded-2xl px-6 text-center text-sm ${darkMode ? 'bg-white/[0.03] text-white/38' : 'bg-stone-900/[0.03] text-stone-400'}`}>
                                        Le chiffre d’affaires apparaîtra après la première vente.
                                    </div>
                                )}
                            </>
                        )}
                    </div>
                </PanelFrame>

                <PanelFrame darkMode={darkMode} className="lg:col-span-4" innerClassName="p-5 sm:p-7">
                    <div className="mb-4">
                        <p className={`text-[9px] font-bold uppercase tracking-[0.18em] ${textMuted}`}>Flux des commandes</p>
                        <h2 className={`mt-2 text-xl font-semibold tracking-[-0.03em] ${textBase}`}>Répartition des statuts</h2>
                    </div>
                    <StatusDonut counts={displayedStatusCounts} darkMode={darkMode} unavailable={ordersUnavailable} />
                </PanelFrame>
            </motion.div>

            <motion.div ref={insightsAnchorRef} custom={2} variants={sectionVariants} className="grid min-w-0 max-w-full gap-5 lg:grid-cols-12">
                {insights.error && <button type="button" className="lg:col-span-12" onClick={() => { dashboardInsights.retry(); setInsights(EMPTY_INSIGHTS); setInsightsRetry((value) => value + 1); }}>Réessayer le chargement des tendances</button>}
                <PanelFrame darkMode={darkMode} className="min-w-0 lg:col-span-5" innerClassName="overflow-hidden p-5 sm:p-7">
                    <div className="mb-5 flex items-start justify-between gap-4">
                        <div>
                            <p className={`text-[9px] font-bold uppercase tracking-[0.18em] ${textMuted}`}>Restauration</p>
                            <h2 className={`mt-2 text-xl font-semibold tracking-[-0.03em] ${textBase}`}>Intentions de devis</h2>
                            <p className={`mt-1 text-[11px] ${textMuted}`}>Parcours pré-calculé, sans session brute</p>
                        </div>
                        <span className={`flex h-10 w-10 items-center justify-center rounded-xl ring-1 ${darkMode ? 'bg-white/[0.045] text-white/54 ring-white/[0.065]' : 'bg-[#eee9e2] text-stone-600 ring-stone-900/[0.05]'}`}>
                            <FileText size={17} strokeWidth={1.4} />
                        </span>
                    </div>
                    <div className={`mb-5 grid grid-cols-4 rounded-xl p-1 ring-1 ${darkMode ? 'bg-white/[0.025] ring-white/[0.055]' : 'bg-[#f3efe9] ring-stone-900/[0.045]'}`} aria-label="Période des intentions de devis">
                        {QUOTE_PERIODS.map((period) => {
                            const active = period.id === selectedQuotePeriod.id;
                            return (
                                <button
                                    key={period.id}
                                    type="button"
                                    onClick={() => setQuotePeriod(period.id)}
                                    aria-pressed={active}
                                    className={`rounded-lg px-1.5 py-2 text-[9px] font-bold transition-colors ${active
                                        ? (darkMode ? 'bg-white/10 text-white' : 'bg-white text-stone-900 shadow-sm')
                                        : (darkMode ? 'text-white/38 hover:text-white/65' : 'text-stone-400 hover:text-stone-600')}`}
                                >
                                    {period.shortLabel}
                                </button>
                            );
                        })}
                    </div>
                    <QuoteFunnel
                        quote={selectedQuote}
                        loading={insights.loading}
                        error={insights.error}
                        periodLabel={selectedQuotePeriod.label}
                        darkMode={darkMode}
                    />
                </PanelFrame>

                <PanelFrame darkMode={darkMode} className="min-w-0 lg:col-span-7" innerClassName="overflow-hidden p-5 sm:p-7">
                    <div className="mb-6 flex flex-col justify-between gap-4 sm:flex-row sm:items-start">
                        <div>
                            <p className={`text-[9px] font-bold uppercase tracking-[0.18em] ${textMuted}`}>Intérêt catalogue</p>
                            <h2 className={`mt-2 text-xl font-semibold tracking-[-0.03em] ${textBase}`}>Meubles en tendance</h2>
                            <p className={`mt-1 text-[11px] ${textMuted}`}>Classement par vues de fiche sur 30 jours</p>
                        </div>
                        <div className="flex gap-2">
                            {insights.coverageLimited && (
                                <span className={`rounded-xl px-3 py-2 text-[9px] font-semibold ring-1 ${darkMode ? 'bg-amber-400/[0.07] text-amber-200/70 ring-amber-300/10' : 'bg-amber-50 text-amber-700 ring-amber-900/10'}`}>
                                    Échantillon plafonné
                                </span>
                            )}
                            {insights.productsState === 'ready' ? (
                                <>
                                    <span className={`rounded-xl px-3 py-2 text-[9px] font-semibold tabular-nums ring-1 ${darkMode ? 'bg-white/[0.035] text-white/48 ring-white/[0.055]' : 'bg-[#f1ede7] text-stone-500 ring-stone-900/[0.045]'}`}>
                                        {insights.totalProductViews} vues
                                    </span>
                                    <span className={`rounded-xl px-3 py-2 text-[9px] font-semibold tabular-nums ring-1 ${darkMode ? 'bg-white/[0.035] text-white/48 ring-white/[0.055]' : 'bg-[#f1ede7] text-stone-500 ring-stone-900/[0.045]'}`}>
                                        {insights.productViewingSessions} sessions
                                    </span>
                                </>
                            ) : (
                                <span className={`rounded-xl px-3 py-2 text-[9px] font-semibold ring-1 ${darkMode ? 'bg-white/[0.035] text-white/42 ring-white/[0.055]' : 'bg-[#f1ede7] text-stone-500 ring-stone-900/[0.045]'}`}>
                                    Données indisponibles
                                </span>
                            )}
                        </div>
                    </div>
                    <TrendingProducts
                        products={trendingProducts}
                        loading={insights.loading}
                        error={insights.error || insights.productsState !== 'ready'}
                        darkMode={darkMode}
                    />
                </PanelFrame>
            </motion.div>

            <motion.div custom={3} variants={sectionVariants}>
                <PanelFrame darkMode={darkMode} innerClassName="p-5 sm:p-7">
                    <div className="mb-6 flex flex-col justify-between gap-3 sm:flex-row sm:items-end">
                        <div>
                            <p className={`text-[9px] font-bold uppercase tracking-[0.18em] ${textMuted}`}>Activité récente</p>
                            <h2 className={`mt-2 text-xl font-semibold tracking-[-0.03em] ${textBase}`}>Dernières commandes</h2>
                        </div>
                        <p className={`text-[10px] ${textMuted}`}>Hors commandes annulées</p>
                    </div>
                    <div className="w-full overflow-x-auto">
                        <table className="w-full min-w-[640px] border-collapse text-left">
                            <thead>
                                <tr className={`text-[9px] font-bold uppercase tracking-[0.16em] ${textMuted}`}>
                                    <th className="pb-3 font-medium">Client</th>
                                    <th className="pb-3 font-medium">Commande</th>
                                    <th className="pb-3 font-medium">Date</th>
                                    <th className="pb-3 text-right font-medium">Statut</th>
                                    <th className="pb-3 text-right font-medium">Montant</th>
                                </tr>
                            </thead>
                            <tbody>
                                {recentOrdersStatus !== 'ready' ? (
                                    <tr><td colSpan={5} className="p-6 text-center text-sm">{recentOrdersStatus === 'loading' ? 'Chargement des commandes…' : <button onClick={() => dashboardOrders.retry()}>Lecture impossible · Réessayer</button>}</td></tr>
                                ) : recentOrders.length === 0 ? (
                                    <tr>
                                        <td colSpan="5" className={`rounded-2xl py-12 text-center text-xs ${textMuted}`}>Aucune transaction récente.</td>
                                    </tr>
                                ) : (
                                    recentOrders.map((order) => {
                                        const status = getOrderStatus(order);
                                        const clientName = order.shipping?.fullName || 'Client invité';
                                        const initials = clientName.split(/\s+/).slice(0, 2).map((part) => part[0]).join('').toUpperCase();
                                        return (
                                            <tr key={order.id} className={`group transition-colors duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] ${darkMode ? 'hover:bg-white/[0.025]' : 'hover:bg-[#f5f1eb]'}`}>
                                                <td className="rounded-l-2xl py-3.5 pl-2 pr-4">
                                                    <div className="flex items-center gap-3">
                                                        <span className={`flex h-9 w-9 items-center justify-center rounded-xl text-[10px] font-bold ring-1 ${darkMode ? 'bg-white/[0.045] text-white/58 ring-white/[0.06]' : 'bg-[#ece6de] text-stone-600 ring-stone-900/[0.045]'}`}>{initials || 'CI'}</span>
                                                        <span className={`text-[12px] font-semibold ${textBase}`}>{clientName}</span>
                                                    </div>
                                                </td>
                                                <td className={`px-4 py-3.5 font-mono text-[10px] ${darkMode ? 'text-white/36' : 'text-stone-400'}`}>{getOrderReference(order)}</td>
                                                <td className={`px-4 py-3.5 text-[11px] ${darkMode ? 'text-white/46' : 'text-stone-500'}`}>{getRelativeOrderDate(order.createdAt)}</td>
                                                <td className="px-4 py-3.5 text-right">
                                                    <span
                                                        data-role={status.tone}
                                                        className={`inline-flex rounded-lg px-2.5 py-1.5 text-[8px] font-bold uppercase tracking-[0.12em] ${
                                                            status.tone === 'success'
                                                                ? (darkMode ? 'bg-emerald-400/10 text-emerald-300' : 'bg-emerald-50 text-emerald-700')
                                                                : status.tone === 'info'
                                                                    ? (darkMode ? 'bg-sky-400/10 text-sky-300' : 'bg-sky-50 text-sky-700')
                                                                    : (darkMode ? 'bg-amber-400/10 text-amber-300' : 'bg-amber-50 text-amber-700')
                                                        }`}
                                                    >
                                                        {status.label}
                                                    </span>
                                                </td>
                                                <td className={`rounded-r-2xl py-3.5 pl-4 pr-2 text-right text-sm font-semibold tabular-nums ${textBase}`}>
                                                    {Number(order.total || 0).toLocaleString('fr-FR')} €
                                                </td>
                                            </tr>
                                        );
                                    })
                                )}
                            </tbody>
                        </table>
                    </div>
                </PanelFrame>
            </motion.div>

        </motion.div>
    );
};

export default AdminDashboard;
