'use client';

import { Check, Loader2 } from 'lucide-react';

const BASE_PHASES = [
  { id: 'authorization', label: 'Vérification sécurisée' },
  { id: 'photos', label: 'Préparation et envoi des photos' },
  { id: 'record', label: 'Enregistrement du meuble' },
  { id: 'catalog', label: 'Mise à jour de la galerie' },
];

export default function PublicationProgressDialog({
  darkMode = false,
  includeSocial = false,
  open,
  phase,
  message,
  productName,
  batchCount = 0,
}) {
  if (!open) return null;

  const phases = includeSocial
    ? [...BASE_PHASES, { id: 'social', label: 'Publication sur les réseaux' }]
    : BASE_PHASES;
  const activeIndex = phase === 'complete'
    ? phases.length
    : Math.max(0, phases.findIndex((entry) => entry.id === phase));
  const complete = phase === 'complete';
  const isBatch = batchCount > 0;
  const stepLabel = complete ? 'Terminé' : `Étape ${Math.min(activeIndex + 1, phases.length)}/${phases.length}`;

  return (
    <div
      className="absolute inset-0 z-40 grid place-items-center bg-stone-950/35 px-4 backdrop-blur-[2px]"
      role="dialog"
      aria-modal="true"
      aria-labelledby="publication-progress-title"
      aria-describedby="publication-progress-message"
    >
      <div className={`w-full max-w-[430px] rounded-[22px] border p-5 shadow-[0_24px_70px_rgba(28,25,23,0.24)] sm:p-6 ${darkMode ? 'border-white/10 bg-[#171714] text-white' : 'border-stone-200 bg-white text-stone-950'}`}>
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className={`text-[9px] font-extrabold uppercase tracking-[0.14em] ${complete ? 'text-emerald-600' : (darkMode ? 'text-stone-500' : 'text-stone-400')}`}>{complete ? 'Publication réussie' : isBatch ? `${batchCount} publications en cours` : 'Publication en cours'}</p>
            <h3 id="publication-progress-title" className="mt-1.5 text-[18px] font-extrabold tracking-[-0.035em]">{complete ? (isBatch ? 'Le lot est en ligne' : 'Le meuble est en ligne') : (isBatch ? 'Mise en ligne du lot' : 'Mise en ligne de l’ouvrage')}</h3>
            {complete && productName ? <p className={`mt-1 text-[11px] font-semibold ${darkMode ? 'text-stone-400' : 'text-stone-500'}`}>{productName}</p> : null}
          </div>
          <span className={`rounded-full px-3 py-1.5 text-[11px] font-extrabold tabular-nums ${darkMode ? 'bg-white/[0.07] text-stone-300' : 'bg-stone-100 text-stone-600'}`}>{stepLabel}</span>
        </div>

        <ol className="mt-6 space-y-2.5" aria-label="Étapes de mise en ligne">
          {phases.map((entry, index) => {
            const done = index < activeIndex;
            const active = phase !== 'complete' && index === activeIndex;
            return (
              <li key={entry.id} className={`flex min-h-8 items-center gap-3 text-[11px] font-bold ${active ? (darkMode ? 'text-white' : 'text-stone-950') : done ? 'text-emerald-600' : (darkMode ? 'text-stone-600' : 'text-stone-400')}`}>
                <span className={`grid h-6 w-6 shrink-0 place-items-center rounded-full ${done ? 'bg-emerald-500 text-white' : active ? 'bg-emerald-500/12 text-emerald-600 ring-1 ring-emerald-500/25' : (darkMode ? 'bg-white/[0.05]' : 'bg-stone-100')}`}>
                  {done ? <Check size={12} strokeWidth={2.8} /> : active ? <Loader2 size={12} strokeWidth={2.2} className="animate-spin" /> : index + 1}
                </span>
                {isBatch && entry.id === 'record' ? 'Enregistrement des meubles' : entry.label}
              </li>
            );
          })}
        </ol>

        <p id="publication-progress-message" role="status" aria-live="polite" className={`mt-5 min-h-5 text-[10px] font-semibold ${darkMode ? 'text-stone-400' : 'text-stone-500'}`}>
          {message || 'Préparation de la publication…'}
        </p>
        <p className={`mt-2 text-[9px] leading-4 ${darkMode ? 'text-stone-600' : 'text-stone-400'}`}>
          {complete
            ? `Ouverture automatique de la vue Publications${isBatch ? ` · ${batchCount} meubles` : ''}…`
            : 'Chaque coche correspond à une opération terminée. La durée varie selon les photos et la mise à jour du catalogue.'}
        </p>
      </div>
    </div>
  );
}
