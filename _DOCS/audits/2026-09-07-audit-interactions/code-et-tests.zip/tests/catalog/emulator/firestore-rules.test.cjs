const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { after, before, beforeEach, test } = require('node:test');
const { assertFails, assertSucceeds, initializeTestEnvironment } = require('@firebase/rules-unit-testing');
const {
  collection, doc, documentId, getDoc, getDocs, limit, orderBy, query, setDoc, updateDoc, where,
} = require('firebase/firestore');
const { PROJECT_ID, assertEmulatorEnvironment } = require('./emulator-guard.cjs');

let environment;

before(async () => {
  assertEmulatorEnvironment();
  environment = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: { rules: fs.readFileSync(path.resolve(__dirname, '../../../firestore.rules'), 'utf8') },
  });
});

beforeEach(async () => environment.clearFirestore());
after(async () => environment?.cleanup());

test('visitors cannot read products or public/meta and admin access remains rule-scoped', async () => {
  await environment.withSecurityRulesDisabled(async (context) => {
    await setDoc(doc(context.firestore(), 'artifacts/secondevie/public/data/furniture/published'), {
      status: 'published', name: 'Published', description: '', images: [], stock: 1,
    });
    await setDoc(doc(context.firestore(), 'artifacts/secondevie/public/data/furniture/draft'), {
      status: 'draft', name: 'Draft', description: '', images: [], stock: 1,
    });
    await setDoc(doc(context.firestore(), 'artifacts/secondevie/public/meta'), { catalogVersion: 1 });
    await setDoc(doc(context.firestore(), 'sys_admin_access/admin-1'), { active: true });
  });
  const visitor = environment.unauthenticatedContext().firestore();
  await assertFails(getDoc(doc(visitor, 'artifacts/secondevie/public/data/furniture/published')));
  await assertFails(getDoc(doc(visitor, 'artifacts/secondevie/public/data/furniture/draft')));
  await assertFails(getDoc(doc(visitor, 'artifacts/secondevie/public/meta')));
  const admin = environment.authenticatedContext('admin-1', {
    admin: true,
    firebase: { sign_in_provider: 'google.com' },
  }).firestore();
  await assertSucceeds(getDoc(doc(admin, 'artifacts/secondevie/public/data/furniture/published')));
  await assertFails(getDoc(doc(admin, 'artifacts/secondevie/public/meta')));
});

test('catalog publication state is backend-only for every client role', async () => {
  await environment.withSecurityRulesDisabled(async (context) => {
    await setDoc(doc(context.firestore(), 'sys_admin_access/admin-1'), { active: true });
    await setDoc(doc(context.firestore(), 'sys_catalog_publication/secondevie'), { mode: 'active', desiredRevision: 1 });
  });
  const contexts = [
    environment.unauthenticatedContext(),
    environment.authenticatedContext('owner-1'),
    environment.authenticatedContext('admin-1', {
      admin: true,
      firebase: { sign_in_provider: 'google.com' },
    }),
  ];
  const collections = [
    'sys_catalog_publication/secondevie',
    'sys_catalog_publication_events/event',
    'sys_catalog_publication_builds/build',
    'sys_catalog_media_gc/media',
    'product_publication_sessions/publication-session-0001',
  ];
  for (const context of contexts) {
    for (const target of collections) {
      const ref = doc(context.firestore(), target);
      await assertFails(getDoc(ref));
      await assertFails(setDoc(ref, { attack: true }));
    }
  }
  assert.equal(contexts.length, 3);
});

test('quote requests and their audit remain backend-only for every client role', async () => {
  await environment.withSecurityRulesDisabled(async (context) => {
    await setDoc(doc(context.firestore(), 'sys_admin_access/admin-1'), { active: true });
    await setDoc(doc(context.firestore(), 'quote_requests/quote_private'), {
      requestNumber: 'DEV-TEST',
      customer: { email: 'client@example.test' },
      status: 'new',
    });
    await setDoc(doc(context.firestore(), 'sys_audit_quotes/audit_private'), { quoteId: 'quote_private' });
  });
  const contexts = [
    environment.unauthenticatedContext(),
    environment.authenticatedContext('customer-1'),
    environment.authenticatedContext('admin-1', {
      admin: true,
      firebase: { sign_in_provider: 'google.com' },
    }),
  ];
  for (const context of contexts) {
    const quoteRef = doc(context.firestore(), 'quote_requests/quote_private');
    const auditRef = doc(context.firestore(), 'sys_audit_quotes/audit_private');
    await assertFails(getDoc(quoteRef));
    await assertFails(setDoc(quoteRef, { status: 'closed' }));
    await assertFails(getDoc(auditRef));
    await assertFails(setDoc(auditRef, { attack: true }));
  }
});

test('newsletter plays and rewards remain backend-only while subscribers stay admin-readable', async () => {
  await environment.withSecurityRulesDisabled(async (context) => {
    await setDoc(doc(context.firestore(), 'sys_admin_access/admin-1'), { active: true });
    await setDoc(doc(context.firestore(), 'newsletter_reward_plays/play_private'), { percentage: 10 });
    await setDoc(doc(context.firestore(), 'newsletter_rewards/reward_private'), {
      code: 'SV10-PRIVATE', emailHash: 'hash', percentage: 10,
    });
    await setDoc(doc(context.firestore(), 'newsletter_subscribers/subscriber_private'), {
      contactInfo: 'client@example.test', status: 'subscribed',
    });
    await setDoc(doc(context.firestore(), 'admin_newsletter_summary/current'), {
      schemaVersion: 1, activeCount: 1, revision: 1,
    });
    await setDoc(doc(context.firestore(), 'admin_newsletter_subscriber_projections/subscriber_private'), {
      schemaVersion: 1, present: true,
    });
  });
  const visitor = environment.unauthenticatedContext().firestore();
  const customer = environment.authenticatedContext('customer-1').firestore();
  const admin = environment.authenticatedContext('admin-1', {
    admin: true,
    firebase: { sign_in_provider: 'google.com' },
  }).firestore();

  for (const firestore of [visitor, customer, admin]) {
    await assertFails(getDoc(doc(firestore, 'newsletter_reward_plays/play_private')));
    await assertFails(setDoc(doc(firestore, 'newsletter_reward_plays/play_attack'), { percentage: 15 }));
    await assertFails(getDoc(doc(firestore, 'newsletter_rewards/reward_private')));
    await assertFails(setDoc(doc(firestore, 'newsletter_rewards/reward_attack'), { code: 'FORGED' }));
  }
  await assertFails(getDoc(doc(visitor, 'newsletter_subscribers/subscriber_private')));
  await assertFails(getDoc(doc(customer, 'newsletter_subscribers/subscriber_private')));
  await assertSucceeds(getDoc(doc(admin, 'newsletter_subscribers/subscriber_private')));
  await assertSucceeds(getDoc(doc(admin, 'admin_newsletter_summary/current')));
  await assertFails(getDocs(collection(admin, 'admin_newsletter_summary')));
  await assertFails(setDoc(doc(admin, 'admin_newsletter_summary/current'), { activeCount: 99 }));
  for (const firestore of [visitor, customer, admin]) {
    await assertFails(getDoc(doc(firestore, 'admin_newsletter_subscriber_projections/subscriber_private')));
  }
});

test('active Google or passkey admins can edit back-office content without a time window', async () => {
  await environment.withSecurityRulesDisabled(async (context) => {
    await setDoc(doc(context.firestore(), 'sys_admin_access/admin-google'), { active: true, role: 'admin' });
    await setDoc(doc(context.firestore(), 'sys_admin_access/admin-passkey'), { active: true, role: 'admin' });
    await setDoc(doc(context.firestore(), 'artifacts/secondevie/public/data/furniture/editable'), {
      status: 'published', name: 'Editable', description: '', images: [], stock: 1, startingPrice: 450,
    });
    await setDoc(doc(context.firestore(), 'sys_metadata/theme_settings'), { accent: 'stone' });
    await setDoc(doc(context.firestore(), 'sys_metadata/delivery'), { retrait: { active: true, price: 0 } });
  });

  const google = environment.authenticatedContext('admin-google', {
    admin: true,
    firebase: { sign_in_provider: 'google.com' },
  }).firestore();
  await assertSucceeds(updateDoc(
    doc(google, 'artifacts/secondevie/public/data/furniture/editable'),
    { name: 'Editable Google' }
  ));
  await assertFails(updateDoc(
    doc(google, 'artifacts/secondevie/public/data/furniture/editable'),
    { startingPrice: 1 }
  ));
  await assertFails(updateDoc(doc(google, 'sys_metadata/delivery'), { retrait: { active: false, price: 0 } }));

  const passkey = environment.authenticatedContext('admin-passkey', {
    admin: true,
    authMethod: 'passkey',
    authAssurance: 'aal2',
    userVerified: true,
    auth_time: Math.floor(Date.now() / 1000) - 86400,
  }).firestore();
  await assertSucceeds(updateDoc(doc(passkey, 'sys_metadata/theme_settings'), { accent: 'sauge' }));
});

test('catalog live expose uniquement le signal courant minimal et refuse toute ecriture client', async () => {
  await environment.withSecurityRulesDisabled(async (context) => {
    await setDoc(doc(context.firestore(), 'sys_catalog_live/current'), {
      schemaVersion: 1,
      revision: 7,
      aggregateSha256: 'a'.repeat(64),
      changedProductIds: ['mirror-a'],
      affectedCategoryIds: ['miroirs', 'decorations'],
      affectsGallery: true,
      affectsSearch: true,
      full: false,
    });
    await setDoc(doc(context.firestore(), 'sys_catalog_live/history'), { revision: 6 });
  });
  const visitor = environment.unauthenticatedContext().firestore();
  await assertSucceeds(getDoc(doc(visitor, 'sys_catalog_live/current')));
  await assertFails(getDoc(doc(visitor, 'sys_catalog_live/history')));
  await assertFails(setDoc(doc(visitor, 'sys_catalog_live/current'), {
    schemaVersion: 1,
    revision: 8,
    aggregateSha256: 'b'.repeat(64),
    changedProductIds: Array.from({ length: 1000 }, (_, index) => `product-${index}`),
  }));

  const admin = environment.authenticatedContext('admin-1', {
    admin: true,
    firebase: { sign_in_provider: 'google.com' },
  }).firestore();
  await assertSucceeds(getDoc(doc(admin, 'sys_catalog_live/current')));
  await assertFails(setDoc(doc(admin, 'sys_catalog_live/current'), { revision: 9 }));
});

test('dashboard projections require strong active admin and remain backend-write-only', async () => {
  await environment.withSecurityRulesDisabled(async (context) => {
    await setDoc(doc(context.firestore(), 'sys_admin_access/admin-strong'), { active: true, role: 'admin' });
    await setDoc(doc(context.firestore(), 'sys_admin_access/admin-removed'), { active: false, role: 'admin' });
    for (const id of ['finance', 'orders', 'activity', 'insights', 'future']) {
      await setDoc(doc(context.firestore(), `admin_dashboard/${id}`), { schemaVersion: 1, revision: 1 });
    }
    await setDoc(doc(context.firestore(), 'admin_incident_summary/current'), {
      schemaVersion: 1, activeCritical: 0, activeWarnings: 0, activeTotal: 0,
    });
    await setDoc(doc(context.firestore(), 'admin_system_incident_summary/current'), {
      schemaVersion: 1, revision: 1, recentTotal: 1, recentCritical: 0, recentErrors: 1,
      incidents: [{ schemaVersion: 1, fingerprint: 'runtime-error', occurrenceCount: 1 }],
    });
    await setDoc(doc(context.firestore(), 'admin_action_summary/current'), {
      schemaVersion: 1, pendingReturns: 1, totalPending: 1, revision: 1,
    });
    await setDoc(doc(context.firestore(), 'analytics_session_exclusions/private-session'), {
      schemaVersion: 1, reason: 'admin_identity_resolved',
    });
    await setDoc(doc(context.firestore(), 'admin_system_incidents/runtime-error'), {
      schemaVersion: 1, fingerprint: 'runtime-error', lastSeen: new Date(), occurrenceCount: 1,
    });
    await setDoc(doc(context.firestore(), 'admin_system_incident_events/private-ledger'), {
      schemaVersion: 1, fingerprint: 'runtime-error',
    });
    await setDoc(doc(context.firestore(), 'admin_finance_history_days/2026-09-02'), {
      schemaVersion: 1, dateKey: '2026-09-02', totalRevenueCents: 100,
    });
    await setDoc(doc(context.firestore(), 'admin_finance_history_months/2026-09'), {
      schemaVersion: 1, monthKey: '2026-09', totalRevenueCents: 100,
    });
    await setDoc(doc(context.firestore(), 'admin_finance_history_years/2026'), {
      schemaVersion: 1, yearKey: '2026', totalRevenueCents: 100,
    });
  });
  const strong = environment.authenticatedContext('admin-strong', {
    admin: true,
    firebase: { sign_in_provider: 'google.com' },
  }).firestore();
  const weak = environment.authenticatedContext('admin-strong', {
    admin: true,
    firebase: { sign_in_provider: 'password' },
  }).firestore();
  const removed = environment.authenticatedContext('admin-removed', {
    admin: true,
    firebase: { sign_in_provider: 'google.com' },
  }).firestore();
  const client = environment.authenticatedContext('client-1').firestore();
  const anonymous = environment.unauthenticatedContext().firestore();

  const criticalQuery = query(
    collection(strong, 'admin_dashboard'),
    where(documentId(), 'in', ['finance', 'orders', 'activity'])
  );
  await assertSucceeds(getDocs(criticalQuery));
  await assertSucceeds(getDoc(doc(strong, 'admin_dashboard/insights')));
  await assertSucceeds(getDoc(doc(strong, 'admin_incident_summary/current')));
  await assertSucceeds(getDoc(doc(strong, 'admin_system_incident_summary/current')));
  await assertSucceeds(getDoc(doc(strong, 'admin_action_summary/current')));
  await assertSucceeds(getDocs(query(
    collection(strong, 'admin_finance_history_days'),
    where('dateKey', '>=', '2026-09-01'),
    orderBy('dateKey', 'asc'),
    limit(30)
  )));
  await assertSucceeds(getDocs(query(
    collection(strong, 'admin_finance_history_months'),
    orderBy('monthKey', 'asc'),
    limit(12)
  )));
  await assertSucceeds(getDocs(query(
    collection(strong, 'admin_finance_history_years'),
    orderBy('yearKey', 'desc'),
    limit(50)
  )));
  await assertFails(getDocs(collection(strong, 'admin_system_incidents')));
  await assertFails(getDoc(doc(strong, 'admin_system_incidents/runtime-error')));
  await assertFails(getDoc(doc(strong, 'admin_system_incident_events/private-ledger')));
  await assertFails(getDocs(collection(strong, 'admin_dashboard')));
  await assertFails(getDoc(doc(strong, 'admin_dashboard/future')));
  await assertFails(setDoc(doc(strong, 'admin_dashboard/finance'), { schemaVersion: 1, revision: 2 }));
  await assertFails(setDoc(doc(strong, 'admin_incident_summary/current'), { activeTotal: 1 }));
  await assertFails(setDoc(doc(strong, 'admin_system_incidents/forged'), { occurrenceCount: 999 }));
  await assertFails(setDoc(doc(strong, 'admin_system_incident_summary/current'), { recentTotal: 999 }));
  await assertFails(setDoc(doc(strong, 'admin_action_summary/current'), { pendingReturns: 999 }));
  await assertFails(getDoc(doc(strong, 'analytics_session_exclusions/private-session')));
  await assertFails(setDoc(doc(strong, 'analytics_session_exclusions/private-session'), { reason: 'forged' }));

  for (const firestore of [weak, removed, client, anonymous]) {
    await assertFails(getDoc(doc(firestore, 'admin_dashboard/finance')));
    await assertFails(getDoc(doc(firestore, 'admin_incident_summary/current')));
    await assertFails(getDoc(doc(firestore, 'admin_system_incident_summary/current')));
    await assertFails(getDoc(doc(firestore, 'admin_action_summary/current')));
    await assertFails(getDoc(doc(firestore, 'admin_system_incidents/runtime-error')));
    await assertFails(getDoc(doc(firestore, 'admin_finance_history_days/2026-09-02')));
  }
});
