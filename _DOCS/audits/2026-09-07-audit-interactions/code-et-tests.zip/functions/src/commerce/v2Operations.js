'use strict';

const crypto = require('node:crypto');
const admin = require('firebase-admin');
const functions = require('firebase-functions/v1');
const { APP_ID, getSiteUrl } = require('../../helpers/config');
const {
    GMAIL_EMAIL,
    GMAIL_PASSWORD,
    RESEND_API_KEY,
    RESEND_FROM_EMAIL,
    TRANSACTIONAL_EMAIL_PROVIDER
} = require('../../helpers/secrets');
const {
    checkActiveStrongAdmin,
    normalizeFirestoreId
} = require('../../helpers/security');
const { regionalFunctions } = require('../../helpers/runtime');
const {
    createTransactionalEmailSender
} = require('../email/transactionalEmail');
const {
    renderCommerceEmail
} = require('../email/commerceEmailTemplates');
const {
    buildPaymentReceipt,
    buildRefundConfirmation
} = require('./domain/commerceDocuments');
const {
    materializeCommerceDocumentArtifact
} = require('./domain/commerceDocumentArtifact');
const {
    resolveStorageBucketName
} = require('./domain/commerceDocumentStorage');
const { hashPayload } = require('./domain/idempotency');
const {
    buildFinancialRollupDelta
} = require('./domain/financialRollup');
const {
    createFirestoreWorkerQueries
} = require('./domain/firestoreWorkerQueries');
const {
    planFixtureCleanup
} = require('./domain/fixtureCleanup');
const {
    effectiveCommerceHealth,
    evaluateCommerceHealth
} = require('./domain/operationsHealth');
const {
    createOutboxRepository
} = require('./domain/outboxRepository');
const {
    createOutboxWorker
} = require('./domain/outboxWorker');
const {
    createBoundedWorkerSweeper
} = require('./domain/boundedWorkerSweeper');
const {
    assertWorkerRunComplete,
    buildWorkerRunSummary
} = require('./domain/workerRunHealth');

const db = admin.firestore();
const OUTBOX_SECRETS = [GMAIL_EMAIL, GMAIL_PASSWORD, RESEND_API_KEY];
const COMMERCE_OUTBOX_RUNTIME_SERVICE_ACCOUNT =
    'commerce-outbox-dispatcher@secondevienextjsssr.iam.gserviceaccount.com';
const COMMERCE_OPERATIONS_RUNTIME_SERVICE_ACCOUNT =
    'commerce-operations-reconciler@secondevienextjsssr.iam.gserviceaccount.com';
const DOCUMENT_REPAIR_PAGE_SIZE = 25;
const MAX_FACTS_PER_ORDER_REPAIR = 100;
const FIXTURE_COLLECTIONS = [
    'commerce_checkout_identities',
    'commerce_command_results',
    'commerce_financial_facts',
    'commerce_incidents',
    'commerce_order_access_tokens',
    'commerce_outbox',
    'commerce_webhook_inbox',
    'inventory_movements',
    'inventory_reservations',
    'orders'
];

function operationsError(code) {
    const error = new Error(code);
    error.code = code;
    return error;
}

function createClock() {
    return Object.freeze({
        now: () => new Date().toISOString(),
        nowMillis: () => Date.now()
    });
}

function outboxRefs() {
    return {
        outbox: (outboxId) => db.doc(`commerce_outbox/${outboxId}`)
    };
}

function createEmailSender() {
    const provider = String(TRANSACTIONAL_EMAIL_PROVIDER.value() || 'gmail').toLowerCase();
    return createTransactionalEmailSender({
        provider,
        gmail: {
            user: GMAIL_EMAIL.value(),
            password: GMAIL_PASSWORD.value()
        },
        resend: {
            apiKey: RESEND_API_KEY.value()
        }
    });
}

function messageFor(entry, order, senderEmail) {
    if (!entry?.template) throw operationsError('COMMERCE_OUTBOX_TEMPLATE_UNSUPPORTED');
    return {
        from: `Seconde Vie <${senderEmail}>`,
        replyTo: senderEmail,
        ...renderCommerceEmail({
            template: entry.template,
            order,
            payload: entry.payloadSnapshot || {},
            senderEmail,
            siteUrl: getSiteUrl()
        })
    };
}

function ambiguousGmailError(error, provider) {
    return provider === 'gmail' && (
        ['ECONNRESET', 'ESOCKET', 'ETIMEDOUT', 'GMAIL_SEND_FAILED'].includes(error?.code)
    );
}

function refundSuccessOutboxIsCurrent({ entry, order, attempt = null }) {
    if (!['order-refunded', 'order-refunded-admin'].includes(entry?.template)) return true;
    if (entry?.payload?.refundRequestId) {
        return attempt?.status === 'succeeded' &&
            attempt?.refundId === entry.payload?.refundId;
    }
    return Number(order?.amounts?.refundedCents || 0) >=
        Number(entry?.payload?.amountCents || 0);
}

function createOutboxRuntime() {
    const clock = createClock();
    const sender = createEmailSender();
    const repository = createOutboxRepository({
        db: { runTransaction: (run) => db.runTransaction(run) },
        refs: outboxRefs()
    });
    const worker = createOutboxWorker({
        repository,
        ids: { leaseToken: () => crypto.randomUUID() },
        clock,
        send: async (entry) => {
            const orderId = normalizeFirestoreId(
                entry.payload?.orderId || entry.aggregateId || entry.payloadSnapshot?.orderId,
                'Commande outbox'
            );
            const orderSnapshot = await db.doc(`orders/${orderId}`).get();
            if (!orderSnapshot.exists) throw operationsError('COMMERCE_OUTBOX_ORDER_MISSING');
            try {
                const order = { id: orderId, ...orderSnapshot.data() };
                if (['order-refunded', 'order-refunded-admin'].includes(entry.template)) {
                    const refundRequestId = entry.payload?.refundRequestId;
                    let attempt = null;
                    if (refundRequestId) {
                        const normalizedRefundRequestId = normalizeFirestoreId(
                            refundRequestId,
                            'Tentative remboursement outbox'
                        );
                        const attemptSnapshot = await db.doc(
                            `orders/${orderId}/refunds/${normalizedRefundRequestId}`
                        ).get();
                        attempt = attemptSnapshot.exists ? attemptSnapshot.data() : null;
                    }
                    if (!refundSuccessOutboxIsCurrent({ entry, order, attempt })) {
                        return {
                            suppressed: true,
                            reason: 'refund_no_longer_succeeded'
                        };
                    }
                }
                const message = messageFor(
                    {
                        template: entry.template,
                        payloadSnapshot: entry.payload
                    },
                    order,
                    sender.provider === 'resend'
                        ? RESEND_FROM_EMAIL.value()
                        : GMAIL_EMAIL.value()
                );
                if (entry.template === 'commerce-document-copy') {
                    const documentId = normalizeFirestoreId(
                        entry.payload?.documentId,
                        'Document outbox'
                    );
                    const documentRef = db.doc(`orders/${orderId}/documents/${documentId}`);
                    const documentSnapshot = await documentRef.get();
                    if (!documentSnapshot.exists) {
                        throw operationsError('COMMERCE_OUTBOX_DOCUMENT_MISSING');
                    }
                    const artifact = await materializeCommerceDocumentArtifact({
                        bucket: admin.storage().bucket(
                            await resolveStorageBucketName(process.env, admin.app().options)
                        ),
                        artifactRef: documentRef.collection('artifacts').doc('current'),
                        order,
                        document: documentSnapshot.data()
                    });
                    message.attachments = [{
                        filename: artifact.filename,
                        content: artifact.buffer,
                        contentType: artifact.contentType
                    }];
                }
                const result = await sender.send(
                    message,
                    { idempotencyKey: entry.idempotencyKey }
                );
                if (!result?.id) {
                    const error = operationsError('COMMERCE_OUTBOX_PROVIDER_RESPONSE_INVALID');
                    error.deliveryUnknown = true;
                    throw error;
                }
                return { providerMessageId: result.id };
            } catch (error) {
                if (ambiguousGmailError(error, sender.provider)) {
                    error.code = 'GMAIL_DELIVERY_UNKNOWN';
                    error.deliveryUnknown = true;
                }
                throw error;
            }
        }
    });
    const queries = createFirestoreWorkerQueries({ db });
    const sweeper = (listEligible) => createBoundedWorkerSweeper({
        listEligible,
        processItem: (item) => worker.process(item.id),
        clock,
        pageSize: 25,
        maxPages: 4
    });
    return {
        worker,
        due: sweeper(queries.listDueOutbox),
        expiredLeases: sweeper(queries.listExpiredOutboxLeases)
    };
}

async function upsertImmutableDocument(reference, document) {
    try {
        await reference.create(document);
        return 'created';
    } catch (error) {
        if (error?.code !== 6 && error?.code !== 'already-exists') throw error;
        const existing = await reference.get();
        if (!existing.exists || existing.data()?.contentHash !== document.contentHash) {
            throw operationsError('COMMERCE_DOCUMENT_IMMUTABILITY_CONFLICT');
        }
        return 'reused';
    }
}

async function _rebuildDocuments(_facts = [], { cursor = null } = {}) {
    let query = db.collection('orders')
        .orderBy(admin.firestore.FieldPath.documentId())
        .limit(DOCUMENT_REPAIR_PAGE_SIZE);
    if (cursor) query = query.startAfter(cursor);
    let orders = await query.get();
    let wrapped = false;
    if (orders.empty && cursor) {
        wrapped = true;
        orders = await db.collection('orders')
            .orderBy(admin.firestore.FieldPath.documentId())
            .limit(DOCUMENT_REPAIR_PAGE_SIZE)
            .get();
    }
    let created = 0;
    let reused = 0;
    for (const snapshot of orders.docs) {
        const order = { id: snapshot.id, ...snapshot.data() };
        if (order.schemaVersion !== 2) continue;
        const factsSnapshot = await db.collection('commerce_financial_facts')
            .where('orderId', '==', snapshot.id)
            .limit(MAX_FACTS_PER_ORDER_REPAIR + 1)
            .get();
        if (factsSnapshot.size > MAX_FACTS_PER_ORDER_REPAIR) {
            throw operationsError('COMMERCE_ORDER_FACTS_REPAIR_LIMIT_EXCEEDED');
        }
        const orderFacts = factsSnapshot.docs.map((document) => document.data());
        if (order.payment?.status === 'succeeded') {
            const receipt = buildPaymentReceipt({
                order,
                facts: orderFacts,
                issuedAt: order.payment.succeededAt || new Date().toISOString()
            });
            const result = await upsertImmutableDocument(
                snapshot.ref.collection('documents').doc(receipt.documentId),
                receipt
            );
            if (result === 'created') created += 1;
            else reused += 1;
        }
        const reversedRefundIds = new Set(
            orderFacts
                .filter((fact) => fact.type === 'refund_reversal')
                .map((fact) => fact.providerObjectId)
        );
        const refundIds = [...new Set(
            orderFacts
                .filter((fact) => fact.type === 'refund' && !reversedRefundIds.has(
                    fact.providerObjectId
                ))
                .map((fact) => fact.providerObjectId)
        )];
        for (const refundId of refundIds) {
            const confirmation = buildRefundConfirmation({
                order,
                facts: orderFacts,
                refundId,
                issuedAt: orderFacts.find((fact) => fact.providerObjectId === refundId)?.effectiveAt
            });
            const result = await upsertImmutableDocument(
                snapshot.ref.collection('documents').doc(confirmation.documentId),
                confirmation
            );
            if (result === 'created') created += 1;
            else reused += 1;
        }
    }
    return {
        scannedOrders: orders.size,
        created,
        reused,
        cursor: orders.empty ? null : orders.docs[orders.docs.length - 1].id,
        wrapped
    };
}

async function buildProjectionFromRollups(builtAt) {
    const totalsSnapshot = await db.collection('commerce_financial_totals').limit(20).get();
    const currencies = {};
    let factCount = 0;
    for (const document of totalsSnapshot.docs) {
        const data = document.data();
        const currency = String(data.currency || document.id).toUpperCase();
        currencies[currency] = {
            capturedCents: Number(data.capturedCents || 0),
            refundedCents: Number(data.refundedCents || 0),
            netCents: Number(data.netCents || 0)
        };
        factCount += Number(data.factCount || 0);
    }
    const content = {
        schemaVersion: 2,
        source: 'commerce_financial_incremental_rollups',
        factCount,
        currencies,
        days: {},
        orders: {},
        accounts: {},
        divergences: [],
        validationMode: 'bounded_totals_plus_primary_incidents'
    };
    return {
        ...content,
        projectionHash: hashPayload(content),
        builtAt
    };
}

async function countQuery(query) {
    const snapshot = await query.limit(100).get();
    return snapshot.size;
}

async function buildLiveOutboxFailureCounters() {
    const [failedOutbox, deadLetterOutbox] = await Promise.all([
        countQuery(db.collection('commerce_outbox').where('status', '==', 'failed')),
        countQuery(db.collection('commerce_outbox').where('status', '==', 'dead_letter'))
    ]);
    return { failedOutbox, deadLetterOutbox };
}

async function connectDriftCount() {
    const [legacy, control] = await Promise.all([
        db.doc('sys_metadata/stripe_connect').get(),
        db.doc('sys_commerce_control/current').get()
    ]);
    const activeAccountId = legacy.exists ? legacy.data()?.activeAccountId : null;
    const policyVersion = control.exists ? control.data()?.activePolicyVersion : null;
    if (!activeAccountId || !policyVersion) return 1;
    const [account, policy] = await Promise.all([
        db.doc(`commerce_connect_accounts/${activeAccountId}`).get(),
        db.doc(`commerce_policy_versions/${policyVersion}`).get()
    ]);
    if (!account.exists || !policy.exists) return 1;
    return (
        account.data()?.active !== true ||
        account.data()?.chargesEnabled !== true ||
        account.data()?.detailsSubmitted !== true ||
        account.data()?.livemode === true ||
        policy.data()?.stripeConnectedAccountId !== activeAccountId
    ) ? 1 : 0;
}

async function buildHealth(projection) {
    const nowMillis = Date.now();
    const now = new Date(nowMillis).toISOString();
    const openIncidentsPromise = db.collection('commerce_incidents')
        .where('status', '==', 'open')
        .limit(101)
        .get();
    const [
        dueInbox,
        expiredInboxLeases,
        failedOutbox,
        deadLetterOutbox,
        deliveryUnknown,
        expiredHolds,
        openIncidents,
        connectDrift
    ] = await Promise.all([
        countQuery(db.collection('commerce_webhook_inbox')
            .where('status', 'in', ['received', 'failed'])
            .where('nextAttemptAt', '<=', nowMillis)),
        countQuery(db.collection('commerce_webhook_inbox')
            .where('status', '==', 'processing')
            .where('processingUntil', '<=', nowMillis)),
        countQuery(db.collection('commerce_outbox').where('status', '==', 'failed')),
        countQuery(db.collection('commerce_outbox').where('status', '==', 'dead_letter')),
        countQuery(db.collection('commerce_outbox').where('status', '==', 'delivery_unknown')),
        countQuery(db.collection('inventory_reservations')
            .where('status', '==', 'held')
            .where('expiresAt', '<=', now)),
        openIncidentsPromise,
        connectDriftCount()
    ]);
    const openIncidentData = openIncidents.docs.map((document) => ({
        id: document.id,
        ...document.data()
    }));
    const incidentCodes = openIncidentData.map((incident) => incident.code);
    const orphanPayments = incidentCodes
        .filter((code) => ['payment_orphan', 'payment_intent_orphan'].includes(code))
        .length;
    const refundStockDivergences = incidentCodes
        .filter((code) => ['refund_stock_divergence', 'inventory_conflict'].includes(code))
        .length;
    return evaluateCommerceHealth({
        dueInbox,
        expiredInboxLeases,
        failedOutbox,
        deadLetterOutbox,
        deliveryUnknown,
        expiredHolds,
        orphanPayments,
        refundStockDivergences,
        connectDrift,
        projectionDivergences: projection.divergences.length,
        primaryIncidents: openIncidentData,
        primaryIncidentsTruncated: openIncidents.size > 100
    }, { evaluatedAt: new Date().toISOString() });
}

async function persistHealthIncidents(health) {
    const batch = db.batch();
    for (const [code, count] of Object.entries(health.counters)) {
        const reference = db.doc(`commerce_incidents/operations-${code}`);
        batch.set(reference, {
            schemaVersion: 2,
            code: `operations_${code}`,
            status: count > 0 ? 'open' : 'closed',
            count,
            source: 'commerce_operations_reconciler',
            updatedAt: admin.firestore.FieldValue.serverTimestamp()
        }, { merge: true });
    }
    await batch.commit();
}

async function persistFinancialRollups(facts, projection, builtAt) {
    const counts = new Map();
    for (const fact of facts) {
        if (fact?.status && fact.status !== 'succeeded') continue;
        const delta = buildFinancialRollupDelta(fact);
        const dayId = `${delta.dateKey}_${delta.currency}`;
        counts.set(dayId, (counts.get(dayId) || 0) + 1);
        counts.set(delta.currency, (counts.get(delta.currency) || 0) + 1);
    }
    const writes = [];
    for (const [currency, amounts] of Object.entries(projection.currencies)) {
        writes.push({
            reference: db.doc(`commerce_financial_totals/${currency}`),
            data: {
                schemaVersion: 2,
                currency,
                ...amounts,
                factCount: counts.get(currency) || 0,
                rebuiltAt: builtAt,
                updatedAt: builtAt
            }
        });
    }
    for (const day of Object.values(projection.days)) {
        const dayId = `${day.date}_${day.currency}`;
        writes.push({
            reference: db.doc(`commerce_financial_daily/${dayId}`),
            data: {
                schemaVersion: 2,
                dateKey: day.date,
                currency: day.currency,
                capturedCents: day.capturedCents,
                refundedCents: day.refundedCents,
                netCents: day.netCents,
                factCount: counts.get(dayId) || 0,
                rebuiltAt: builtAt,
                updatedAt: builtAt
            }
        });
    }
    let repairedDocuments = 0;
    let newerDocumentsPreserved = 0;
    for (let offset = 0; offset < writes.length; offset += 100) {
        const chunk = writes.slice(offset, offset + 100);
        const result = await db.runTransaction(async (transaction) => {
            const snapshots = await Promise.all(
                chunk.map((write) => transaction.get(write.reference))
            );
            let repaired = 0;
            let preserved = 0;
            snapshots.forEach((snapshot, index) => {
                const write = chunk[index];
                const currentFactCount = snapshot.exists
                    ? Number(snapshot.data()?.factCount || 0)
                    : -1;
                if (currentFactCount > write.data.factCount) {
                    preserved += 1;
                    return;
                }
                transaction.set(write.reference, write.data);
                repaired += 1;
            });
            return { repaired, preserved };
        });
        repairedDocuments += result.repaired;
        newerDocumentsPreserved += result.preserved;
    }
    return {
        totalDocuments: Object.keys(projection.currencies).length,
        dailyDocuments: Object.keys(projection.days).length,
        repairedDocuments,
        newerDocumentsPreserved
    };
}

async function runOperationsRebuild() {
    const builtAt = new Date().toISOString();
    const baseProjection = await buildProjectionFromRollups(builtAt);
    const [absoluteOrders, projectedOrdersSnapshot, projectedFinanceSnapshot] = await Promise.all([
        buildAdminOrderSummary(),
        db.doc('admin_dashboard/orders').get(),
        db.doc('admin_dashboard/finance').get()
    ]);
    const divergences = [];
    const projectedOrders = projectedOrdersSnapshot.exists ? projectedOrdersSnapshot.data() : null;
    for (const key of ['totalOrders', 'paidOrders', 'shippedOrders', 'pendingOrders', 'cancelledOrders']) {
        if (!projectedOrders || Number(projectedOrders[key]) !== Number(absoluteOrders[key])) {
            divergences.push({ domain: 'orders', field: key });
        }
    }
    const totalEur = baseProjection.currencies.EUR;
    const projectedFinance = projectedFinanceSnapshot.exists ? projectedFinanceSnapshot.data() : null;
    for (const key of ['capturedCents', 'refundedCents', 'netCents']) {
        if (!projectedFinance || Number(projectedFinance[key]) !== Number(totalEur?.[key])) {
            divergences.push({ domain: 'finance', field: key });
        }
    }
    const projectionContent = { ...baseProjection, divergences };
    const projection = {
        ...projectionContent,
        projectionHash: hashPayload(projectionContent)
    };
    await db.doc('commerce_financial_projections/current').set(projection);
    const documents = {
        mode: 'manual_or_targeted_only',
        scannedOrders: 0,
        created: 0,
        reused: 0,
        cursor: null
    };
    const financialRollups = {
        source: 'atomic_incremental_writes',
        rebuilt: false,
        factCount: projection.factCount
    };
    const health = await buildHealth(projection);
    await Promise.all([
        db.doc('sys_commerce_operations/current').set({
            ...health,
            projection: {
                source: projection.source,
                projectionHash: projection.projectionHash,
                factCount: projection.factCount,
                builtAt,
                divergenceCount: projection.divergences.length,
                currencies: projection.currencies
            },
            documents,
            financialRollups,
            appId: APP_ID
        }),
        persistHealthIncidents(health)
    ]);
    const healthLog = {
        schemaVersion: health.schemaVersion,
        status: health.status,
        primaryOpenIncidentCount: health.primaryOpenIncidentCount,
        incidentSampleCodes: health.incidentSampleCodes,
        truncated: health.truncated,
        validUntil: health.validUntil
    };
    if (health.status === 'stop') console.error('commerce_health_unhealthy', healthLog);
    else if (health.status === 'warning') console.warn('commerce_health_unhealthy', healthLog);
    else console.info('commerce_health_healthy', healthLog);
    return { projection, health, documents, financialRollups };
}

async function runOutboxDispatcher({
    logger = console,
    nowMillis = () => Date.now(),
    runId = () => crypto.randomUUID()
} = {}) {
    const startedAtMillis = nowMillis();
    const runtime = createOutboxRuntime();
    const due = await runtime.due.run();
    const expiredLeases = await runtime.expiredLeases.run();
    const summary = buildWorkerRunSummary({
        worker: 'commerce_outbox',
        runId: runId(),
        startedAtMillis,
        finishedAtMillis: nowMillis(),
        results: [
            { name: 'due', result: due },
            { name: 'expired_leases', result: expiredLeases }
        ]
    });
    if (summary.status === 'incomplete') logger.error('commerce_worker_incomplete', summary);
    else logger.info('commerce_worker_completed', summary);
    assertWorkerRunComplete(summary);
    return { due, expiredLeases };
}

async function runWebhookCoverageWatchdog({ nowMillis = () => Date.now() } = {}) {
    const observedAtMillis = nowMillis();
    const inbox = db.collection('commerce_webhook_inbox');
    const probes = [
        {
            incidentId: 'operations-dueInbox',
            code: 'operations_dueInbox',
            query: inbox
                .where('status', 'in', ['received', 'failed'])
                .where('nextAttemptAt', '<=', observedAtMillis)
                .limit(1)
        },
        {
            incidentId: 'operations-expiredInboxLeases',
            code: 'operations_expiredInboxLeases',
            query: inbox
                .where('status', '==', 'processing')
                .where('processingUntil', '<=', observedAtMillis)
                .limit(1)
        }
    ];
    const results = await Promise.all(probes.map((probe) => probe.query.get()));
    const incidentReferences = probes.map((probe) => (
        db.doc(`commerce_incidents/${probe.incidentId}`)
    ));
    const currentIncidents = await db.getAll(...incidentReferences);
    const batch = db.batch();
    let changed = 0;
    probes.forEach((probe, index) => {
        const open = !results[index].empty;
        const current = currentIncidents[index].exists ? currentIncidents[index].data() : null;
        const nextStatus = open ? 'open' : 'closed';
        if (current?.status === nextStatus && current?.code === probe.code) return;
        changed += 1;
        batch.set(incidentReferences[index], {
            schemaVersion: 2,
            code: probe.code,
            severity: 'critical',
            category: 'webhook',
            status: nextStatus,
            count: open ? 1 : 0,
            source: 'webhook_coverage_watchdog',
            updatedAt: admin.firestore.FieldValue.serverTimestamp()
        }, { merge: true });
    });
    if (changed > 0) await batch.commit();
    return {
        changed,
        dueInbox: results[0].empty ? 0 : 1,
        expiredInboxLeases: results[1].empty ? 0 : 1
    };
}

const PAID_ORDER_STATUSES = [
    'paid',
    'completed',
    'refunded',
    'refund_pending',
    'refund_failed'
];
const CANCELLED_ORDER_STATUSES = [
    'cancelled',
    'cancelled_by_client',
    'canceled'
];

async function countOrders(query) {
    const snapshot = await query.count().get();
    return Number(snapshot.data().count || 0);
}

async function buildAdminOrderSummary() {
    const orders = db.collection('orders');
    const [allOrders, cancelledOrders, paidOrders, shippedOrders] = await Promise.all([
        countOrders(orders),
        countOrders(orders.where('status', 'in', CANCELLED_ORDER_STATUSES)),
        countOrders(orders.where('status', 'in', PAID_ORDER_STATUSES)),
        countOrders(orders.where('status', '==', 'shipped'))
    ]);
    const totalOrders = Math.max(0, allOrders - cancelledOrders);
    const pendingOrders = Math.max(0, totalOrders - paidOrders - shippedOrders);
    return {
        totalOrders,
        paidOrders,
        shippedOrders,
        pendingOrders,
        cancelledOrders,
        countedAt: new Date().toISOString()
    };
}

async function buildAdminFinancialSummary() {
    const snapshot = await db.doc('commerce_financial_totals/EUR').get();
    if (!snapshot.exists) return null;
    const amounts = snapshot.data();
    return {
        currencies: {
            EUR: {
                capturedCents: Number(amounts.capturedCents || 0),
                refundedCents: Number(amounts.refundedCents || 0),
                netCents: Number(amounts.netCents || 0)
            }
        },
        countedAt: amounts.updatedAt || new Date().toISOString(),
        source: 'commerce_financial_totals'
    };
}

async function buildAdminFinancialDaily() {
    const snapshot = await db.collection('commerce_financial_daily')
        .orderBy('dateKey', 'desc')
        .limit(366)
        .get();
    return snapshot.docs
        .map((document) => {
            const day = document.data();
            return {
                dateKey: day.dateKey,
                currency: day.currency,
                capturedCents: Number(day.capturedCents || 0),
                refundedCents: Number(day.refundedCents || 0),
                netCents: Number(day.netCents || 0)
            };
        })
        .sort((left, right) => String(left.dateKey).localeCompare(String(right.dateKey)));
}

const commerceOutboxDispatcher = regionalFunctions()
    .runWith({
        serviceAccount: COMMERCE_OUTBOX_RUNTIME_SERVICE_ACCOUNT,
        secrets: OUTBOX_SECRETS,
        timeoutSeconds: 300,
        memory: '512MB',
        maxInstances: 1
    })
    .pubsub.schedule('every 60 minutes')
    .onRun(runOutboxDispatcher);

const commerceOperationsReconciler = regionalFunctions()
    .runWith({
        serviceAccount: COMMERCE_OPERATIONS_RUNTIME_SERVICE_ACCOUNT,
        timeoutSeconds: 300,
        memory: '512MB',
        maxInstances: 1
    })
    .pubsub.schedule('17 3 * * *')
    .onRun(runOperationsRebuild);

const getCommerceOperationsStatusAdmin = regionalFunctions()
    .runWith({ enforceAppCheck: true })
    .https.onCall(async (_data, context) => {
        await checkActiveStrongAdmin(context);
        const [
            operations,
            control,
            orderSummary,
            financialSummary,
            financialDaily,
            liveOutboxFailures
        ] = await Promise.all([
            db.doc('sys_commerce_operations/current').get(),
            db.doc('sys_commerce_control/current').get(),
            buildAdminOrderSummary(),
            buildAdminFinancialSummary(),
            buildAdminFinancialDaily(),
            buildLiveOutboxFailureCounters()
        ]);
        const operationsData = operations.exists ? operations.data() : null;
        const storedEffective = effectiveCommerceHealth(operationsData);
        const hasLiveOutboxFailure = Object.values(liveOutboxFailures)
            .some((count) => count > 0);
        return {
            success: true,
            operations: operationsData ? {
                ...operationsData,
                storedStatus: operationsData.status || 'unknown',
                status: hasLiveOutboxFailure ? 'stop' : operationsData.status,
                counters: {
                    ...(operationsData.counters || {}),
                    ...liveOutboxFailures
                },
                effective: {
                    ...storedEffective,
                    effectiveStatus: hasLiveOutboxFailure
                        ? 'stop'
                        : storedEffective.effectiveStatus
                }
            } : null,
            orderSummary,
            financialSummary,
            financialDaily,
            control: control.exists ? {
                newCheckoutMode: control.data()?.newCheckoutMode || 'off',
                adminMutationMode: control.data()?.adminMutationMode || 'read_only',
                fixtureScopeVersion: control.data()?.fixtureScopeVersion || null,
                controlRevision: control.data()?.controlRevision || null
            } : null
        };
    });

const rebuildCommerceOperationsAdmin = regionalFunctions()
    .runWith({ enforceAppCheck: true, timeoutSeconds: 300, memory: '512MB' })
    .https.onCall(async (_data, context) => {
        await checkActiveStrongAdmin(context);
        const result = await runOperationsRebuild();
        return {
            success: true,
            projectionHash: result.projection.projectionHash,
            factCount: result.projection.factCount,
            healthStatus: result.health.status,
            documents: result.documents,
            financialRollups: result.financialRollups
        };
    });

const cleanupFixtureRunAdmin = regionalFunctions()
    .runWith({ enforceAppCheck: true, timeoutSeconds: 180, memory: '512MB' })
    .https.onCall(async (data, context) => {
        await checkActiveStrongAdmin(context);
        const runId = normalizeFirestoreId(data?.runId, 'Run fixture');
        if (!runId.startsWith('run_')) {
            throw new functions.https.HttpsError('invalid-argument', 'Run fixture invalide.');
        }
        const dryRun = data?.commit !== true;
        if (!dryRun && data?.confirm !== `QUARANTINE_${runId}`) {
            throw new functions.https.HttpsError(
                'failed-precondition',
                'Confirmation de quarantaine fixture invalide.'
            );
        }
        const documents = [];
        let boundedLimitReached = false;
        for (const collection of FIXTURE_COLLECTIONS) {
            const snapshot = await db.collection(collection)
                .where('testContext.runId', '==', runId)
                .limit(100)
                .get();
            if (snapshot.size === 100) boundedLimitReached = true;
            for (const document of snapshot.docs) {
                documents.push({
                    collection,
                    id: document.id,
                    status: document.data()?.status || null,
                    testContext: document.data()?.testContext || null
                });
            }
        }
        const plan = planFixtureCleanup({ runId, documents, dryRun });
        if (!dryRun) {
            const quarantine = plan.actions.filter((entry) => entry.action === 'quarantine');
            for (let offset = 0; offset < quarantine.length; offset += 400) {
                const batch = db.batch();
                for (const entry of quarantine.slice(offset, offset + 400)) {
                    batch.set(db.doc(`${entry.collection}/${entry.id}`), {
                        fixtureCleanup: {
                            schemaVersion: 2,
                            status: 'quarantined',
                            runId,
                            reason: entry.reason,
                            operationId: `cleanup_${runId}`
                        },
                        updatedAt: admin.firestore.FieldValue.serverTimestamp()
                    }, { merge: true });
                }
                await batch.commit();
            }
        }
        return {
            success: true,
            complete: !boundedLimitReached,
            plan
        };
    });

module.exports = {
    buildAdminFinancialDaily,
    buildAdminFinancialSummary,
    buildAdminOrderSummary,
    cleanupFixtureRunAdmin,
    commerceOperationsReconciler,
    commerceOutboxDispatcher,
    createOutboxRuntime,
    getCommerceOperationsStatusAdmin,
    messageFor,
    refundSuccessOutboxIsCurrent,
    rebuildCommerceOperationsAdmin,
    persistFinancialRollups,
    runOperationsRebuild,
    runOutboxDispatcher,
    runWebhookCoverageWatchdog
};
