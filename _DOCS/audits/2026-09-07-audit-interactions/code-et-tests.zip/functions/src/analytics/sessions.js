/**
 * ANALYTICS: Sessions en direct
 *
 * - initLiveSession: Crée une session pseudonymisee sans IP
 * - syncSession: Met à jour le parcours
 * - syncSessionBeacon: Endpoint fiable pour fermeture de page
 * - deleteSessionGen2: targeted admin cleanup
 */
const { functions, regionalFunctions } = require('../../helpers/runtime');
const { onCall, onRequest } = require('firebase-functions/v2/https');
const admin = require('firebase-admin');
const crypto = require('crypto');
const { planSessionMessage, legacySessionProtocolAllowed } = require('./sessionSequence');
const { getSiteUrl } = require('../../helpers/config');
const {
    canResumeSession,
    hashSyncToken,
    isValidSyncToken,
    toMillis
} = require('./sessionSecurity');
const { createSessionAuthorizationCache } = require('./sessionAuthorizationCache');
const { createDeleteSessionHandler } = require('./sessionMaintenance');
const { ANALYTICS_SESSION_RETENTION_DAYS, timestampFromNow } = require('./constants');
const { hashOpaque, structuredLog } = require('../../helpers/observability');

const db = admin.firestore();
const ANALYTICS_RUNTIME_SERVICE_ACCOUNT = 'analytics-runtime@secondevienextjsssr.iam.gserviceaccount.com';
const ANALYTICS_CALLABLE_GEN2_RUNTIME = Object.freeze({
    region: 'europe-west1',
    cpu: 'gcf_gen1',
    concurrency: 1,
    minInstances: 0,
    maxInstances: 1,
    memory: '256MiB',
    timeoutSeconds: 60,
    serviceAccount: ANALYTICS_RUNTIME_SERVICE_ACCOUNT,
    enforceAppCheck: true
});
const ANALYTICS_BEACON_GEN2_RUNTIME = Object.freeze({
    region: 'europe-west1',
    cpu: 'gcf_gen1',
    concurrency: 1,
    minInstances: 0,
    maxInstances: 1,
    memory: '256MiB',
    timeoutSeconds: 60,
    serviceAccount: ANALYTICS_RUNTIME_SERVICE_ACCOUNT,
    cors: false
});
const MAX_SESSION_DURATION_SECONDS = 24 * 60 * 60;
const MAX_JOURNEY_CHUNK = 25;
const MAX_EVENT_PREVIEW = 16;
const SYNC_REASONS = new Set([
    'init',
    'route',
    'affiliate',
    'heartbeat',
    'visible',
    'visibility_hidden',
    'beforeunload',
    'pagehide',
    'manual'
]);
const sessionAuthorizationCache = createSessionAuthorizationCache();

const createSyncToken = () => crypto.randomBytes(32).toString('base64url');

const clampDuration = (value) => {
    const duration = Number(value);
    if (!Number.isFinite(duration)) return 0;
    return Math.max(0, Math.min(MAX_SESSION_DURATION_SECONDS, Math.round(duration)));
};

const clampJourneyTimestampMs = (value) => {
    const ms = Number(value);
    if (!Number.isFinite(ms) || ms <= 0) return null;

    const now = Date.now();
    const min = now - (366 * 24 * 60 * 60 * 1000);
    const max = now + (5 * 60 * 1000);
    if (ms < min || ms > max) return null;

    return Math.round(ms);
};

const sanitizeString = (value, maxLength = 160) => {
    if (value === null || value === undefined) return null;
    return String(value).slice(0, maxLength);
};

const sanitizeSyncReason = (value) => {
    const reason = sanitizeString(value, 40) || 'manual';
    return SYNC_REASONS.has(reason) ? reason : 'manual';
};

const verifySessionSyncToken = async (sessionRef, syncToken) => {
    const cachedHash = sessionAuthorizationCache.get(sessionRef.id);
    if (cachedHash) {
        return {
            exists: true,
            valid: isValidSyncToken({ syncTokenHash: cachedHash }, syncToken),
            cacheHit: true
        };
    }

    const sessionSnap = await sessionRef.get();
    if (!sessionSnap.exists) return { exists: false, valid: false, cacheHit: false };

    const sessionData = sessionSnap.data();
    if (sessionData?.syncTokenHash) {
        // Cache the authoritative hash even for a rejected token so repeated
        // invalid attempts cannot force one Firestore read per request.
        sessionAuthorizationCache.set(sessionRef.id, sessionData.syncTokenHash);
    }

    return {
        exists: true,
        valid: isValidSyncToken(sessionData, syncToken),
        cacheHit: false
    };
};

const applySessionMessage = (sessionRef, message, updates) => db.runTransaction(async (transaction) => {
    const snapshot = await transaction.get(sessionRef);
    if (!snapshot.exists) return { success: false, missing: true };
    const current = snapshot.data();
    if (!isValidSyncToken(current, message.syncToken)) return { success: false, invalidToken: true };
    const result = planSessionMessage(current, message, updates);
    if (result.updates) transaction.update(sessionRef, result.updates);
    const { updates: _updates, ...response } = result;
    return response;
});

const tryResumeSession = async ({ sessionId, syncToken, authUid, device, browser, os, sequenced }) => {
    const cleanSessionId = sanitizeString(sessionId, 160);
    if (!cleanSessionId || !syncToken) return null;

    const sessionRef = db.collection('analytics_sessions').doc(cleanSessionId);
    const sessionSnap = await sessionRef.get();
    if (!sessionSnap.exists) return null;

    let sessionData = sessionSnap.data();
    const now = Date.now();
    if (!sequenced && sessionData.syncGeneration) return null;
    if (!canResumeSession(sessionData, { authUid, syncToken, now })) return null;

    const syncGeneration = sequenced ? crypto.randomUUID() : null;
    const resumed = await db.runTransaction(async (transaction) => {
        const fresh = await transaction.get(sessionRef);
        if (!fresh.exists || !canResumeSession(fresh.data(), { authUid, syncToken, now })) return false;
        const current = fresh.data();
        if (!sequenced && current.syncGeneration) return false;
        transaction.update(sessionRef, {
        syncGeneration,
        syncSequence: 0,
        lastActivityAt: admin.firestore.FieldValue.serverTimestamp(),
        sessionActive: true,
        device: sanitizeString(device || current.device, 40) || 'Unknown',
        browser: sanitizeString(browser || current.browser, 40) || 'Unknown',
        os: sanitizeString(os || current.os, 40) || 'Unknown',
        resumedAt: admin.firestore.FieldValue.serverTimestamp(),
        analyticsVersion: 3
        });
        return current;
    });
    if (!resumed) return null;
    sessionData = resumed;
    if (sessionData.syncTokenHash) {
        sessionAuthorizationCache.set(sessionSnap.id, sessionData.syncTokenHash);
    }

    return {
        success: true,
        resumed: true,
        syncGeneration,
        sessionId: sessionSnap.id,
        syncToken,
        ipDetected: Boolean(sessionData.ipMeta?.detected || sessionData.ip),
        startedAtMs: toMillis(sessionData.startedAt) || now,
        duration: clampDuration(sessionData.duration),
        journeySnapshot: sanitizeJourney(sessionData.journey),
        journeyCount: Math.max(
            Array.isArray(sessionData.journey) ? sessionData.journey.length : 0,
            Math.round(Number(sessionData.journeyCount) || 0)
        ),
        pageCounts: sanitizeCountMap(sessionData.pageCounts),
        actionCounts: sanitizeCountMap(sessionData.actionCounts),
        lastEventPreview: sanitizeEventPreview(sessionData.lastEventPreview)
    };
};

const sanitizeJourney = (journey) => {
    if (!Array.isArray(journey)) return [];

    return journey
        .slice(0, MAX_JOURNEY_CHUNK)
        .map((step) => {
            const timestampMs = clampJourneyTimestampMs(step?.timestampMs);
            return {
                page: sanitizeString(step?.page, 80) || 'unknown',
                itemId: sanitizeString(step?.itemId, 255),
                time: sanitizeString(step?.time, 40),
                timeZone: sanitizeString(step?.timeZone, 80),
                duration: clampDuration(step?.duration),
                ...(timestampMs ? { timestampMs } : {})
            };
        })
        .filter(step => step.page);
};

const sanitizeEventPreview = (events) => {
    if (!Array.isArray(events)) return [];
    return events.slice(-MAX_EVENT_PREVIEW).map((event) => ({
        action: sanitizeString(event?.action, 80) || 'unknown',
        itemId: sanitizeString(event?.itemId, 160),
        itemName: sanitizeString(event?.itemName, 160),
        time: sanitizeString(event?.time, 40),
        timestamp: clampJourneyTimestampMs(event?.timestamp),
        form: sanitizeString(event?.form, 80)
    }));
};

const sanitizeCountMap = (value, maxKeys = 64) => {
    if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
    const result = {};
    for (const [rawKey, rawCount] of Object.entries(value).slice(0, maxKeys)) {
        const key = String(rawKey || '').trim().toLowerCase().replace(/[^a-z0-9_-]/g, '_').slice(0, 48);
        const count = Math.max(0, Math.min(100000, Math.round(Number(rawCount) || 0)));
        if (key && count) result[key] = count;
    }
    return result;
};

const initLiveSessionHandler = async (data = {}, context) => {
    if (!context.auth) {
        throw new functions.https.HttpsError('unauthenticated', 'Auth required');
    }

    const { userId, device, browser, os, resumeSessionId, resumeSyncToken } = data;
    const sequenced = data.syncProtocolVersion === 1;
    if (!sequenced && !legacySessionProtocolAllowed()) return { success: false, upgradeRequired: true };
    const authUid = context.auth.uid || userId || 'unknown';
    const authProvider = context.auth.token.firebase?.sign_in_provider || 'unknown';

    const resumedSession = await tryResumeSession({
        sessionId: resumeSessionId,
        syncToken: resumeSyncToken,
        authUid,
        device,
        browser,
        os,
        sequenced
    });
    if (resumedSession) return resumedSession;

    const syncToken = createSyncToken();

    const sessionType = authProvider === 'anonymous' ? 'anonymous' : 'client';

    const sessionData = {
        syncGeneration: sequenced ? crypto.randomUUID() : null,
        syncSequence: 0,
        userId: authUid,
        type: sessionType,
        authProvider,
        visitorIdentity: {
            source: authUid && authUid !== 'unknown'
                ? (authProvider === 'anonymous' ? 'anonymous_uid' : 'auth_uid')
                : 'session',
            hasAuthUid: Boolean(authUid && authUid !== 'unknown'),
            hasServerIp: false
        },
        startedAt: admin.firestore.FieldValue.serverTimestamp(),
        lastActivityAt: admin.firestore.FieldValue.serverTimestamp(),
        duration: 0,
        device: sanitizeString(device, 40) || 'Unknown',
        browser: sanitizeString(browser, 40) || 'Unknown',
        os: sanitizeString(os, 40) || 'Unknown',
        // Visitor IPs are not disclosed to an uncontracted third-party geo API.
        geo: { country: 'Unknown', city: 'Unknown', region: 'Unknown' },
        journey: [],
        journeyCount: 0,
        pageCounts: {},
        actionCounts: {},
        lastEventPreview: [],
        sessionActive: true,
        adminIPDetected: false,
        analyticsVersion: 3,
        syncTokenHash: hashSyncToken(syncToken),
        syncReasonCounts: {},
        expireAt: timestampFromNow(ANALYTICS_SESSION_RETENTION_DAYS)
    };

    try {
        const sessionRef = await db.collection('analytics_sessions').add(sessionData);
        sessionAuthorizationCache.set(sessionRef.id, sessionData.syncTokenHash);
        return {
            success: true,
            resumed: false,
            syncGeneration: sessionData.syncGeneration,
            sessionId: sessionRef.id,
            syncToken,
            ipDetected: false,
            startedAtMs: Date.now(),
            journeySnapshot: [],
            journeyCount: 0,
            pageCounts: {},
            actionCounts: {},
            lastEventPreview: []
        };
    } catch (error) {
        structuredLog('error', 'analytics_session_init_failed', {
            errorClass: String(error?.code || error?.name || 'unknown').slice(0, 120)
        });
        throw new functions.https.HttpsError('internal', 'Init failed');
    }
};

exports.initLiveSession = regionalFunctions()
    .runWith({ enforceAppCheck: true })
    .https.onCall(initLiveSessionHandler);

exports.initLiveSessionGen2 = onCall(
    ANALYTICS_CALLABLE_GEN2_RUNTIME,
    async (request) => initLiveSessionHandler(request.data, request)
);

const syncSessionHandler = async (data = {}, context) => {
    if (!context.auth) return { success: false, unauthenticated: true };

    const { sessionId, journey, journeyCount, pageCounts, actionCounts, lastEventPreview, duration, sessionActive, syncToken, reason } = data;
    if (!sessionId) return { success: false };

    try {
        const sessionRef = db.collection('analytics_sessions').doc(sessionId);
        const authorization = await verifySessionSyncToken(sessionRef, syncToken);

        if (!authorization.exists) {
            structuredLog('warning', 'analytics_session_missing', {
                sessionIdHash: hashOpaque(sessionId)
            });
            return { success: true, missing: true };
        }

        if (!authorization.valid) {
            structuredLog('warning', 'analytics_session_token_rejected', {
                sessionIdHash: hashOpaque(sessionId)
            });
            return { success: false, invalidToken: true };
        }

        const syncReason = sanitizeSyncReason(reason);
        const updates = {
            lastActivityAt: admin.firestore.FieldValue.serverTimestamp(),
            duration: clampDuration(duration),
            sessionActive: sessionActive !== undefined ? sessionActive : true,
            lastSyncReason: syncReason,
            [`syncReasonCounts.${syncReason}`]: admin.firestore.FieldValue.increment(1)
        };

        const cleanJourney = sanitizeJourney(journey);
        if (cleanJourney.length > 0) {
            updates.journey = cleanJourney.slice(-MAX_JOURNEY_CHUNK);
        }
        updates.journeyCount = Math.max(cleanJourney.length, Math.min(1000000, Math.round(Number(journeyCount) || 0)));
        updates.pageCounts = sanitizeCountMap(pageCounts);
        updates.actionCounts = sanitizeCountMap(actionCounts);
        if (Array.isArray(lastEventPreview)) {
            updates.lastEventPreview = sanitizeEventPreview(lastEventPreview);
        }

        return await applySessionMessage(sessionRef, data, updates);
    } catch (error) {
        structuredLog('error', 'analytics_session_sync_failed', {
            sessionIdHash: hashOpaque(sessionId),
            errorClass: String(error?.code || error?.name || 'unknown').slice(0, 120)
        });
        return { success: false };
    }
};

exports.syncSession = regionalFunctions()
    .runWith({ enforceAppCheck: true })
    .https.onCall(syncSessionHandler);

exports.syncSessionGen2 = onCall(
    ANALYTICS_CALLABLE_GEN2_RUNTIME,
    async (request) => syncSessionHandler(request.data, request)
);

const syncSessionBeaconHandler = async (req, res) => {
    const configuredOrigin = (() => {
        try { return new URL(getSiteUrl()).origin; } catch { return ''; }
    })();
    const allowedOrigins = new Set([
        configuredOrigin,
        'http://localhost:3000',
        'http://127.0.0.1:3000'
    ].filter(Boolean));

    const origin = req.headers.origin;
    const originAllowed = allowedOrigins.has(origin);
    if (originAllowed) res.set('Access-Control-Allow-Origin', origin);
    res.set('Vary', 'Origin');
    res.set('Access-Control-Allow-Methods', 'POST, OPTIONS');
    res.set('Access-Control-Allow-Headers', 'Content-Type');

    if (!originAllowed) { res.status(403).send('Origin denied'); return; }
    if (req.method === 'OPTIONS') { res.status(204).send(''); return; }
    if (req.method !== 'POST') { res.status(405).send('Method not allowed'); return; }
    const contentType = String(req.headers['content-type'] || '');
    const hasJsonBody = /^application\/json(?:\s*;|$)/i.test(contentType);
    const hasBeaconTextBody = /^text\/plain(?:\s*;|$)/i.test(contentType);
    if (!hasJsonBody && !hasBeaconTextBody) {
        res.status(415).send('JSON required');
        return;
    }
    if (req.rawBody && req.rawBody.length > 64 * 1024) {
        res.status(413).send('Payload too large');
        return;
    }

    let sessionIdForLog = null;
    try {
        let payload;
        if (typeof req.body === 'string') {
            payload = JSON.parse(req.body);
        } else if (req.rawBody) {
            payload = JSON.parse(req.rawBody.toString());
        } else {
            payload = req.body;
        }

        payload = payload || {};
        const { sessionId, journey, journeyCount, pageCounts, actionCounts, lastEventPreview, duration, sessionActive, syncToken, reason } = payload;
        sessionIdForLog = sessionId;

        if (!sessionId) {
            res.status(400).send('Missing session ID');
            return;
        }

        const sessionRef = db.collection('analytics_sessions').doc(sessionId);
        const authorization = await verifySessionSyncToken(sessionRef, syncToken);

        if (!authorization.exists) {
            structuredLog('warning', 'analytics_beacon_session_missing', {
                sessionIdHash: hashOpaque(sessionId)
            });
            res.status(204).send('');
            return;
        }

        if (!authorization.valid) {
            structuredLog('warning', 'analytics_beacon_token_rejected', {
                sessionIdHash: hashOpaque(sessionId)
            });
            res.status(403).send('Invalid session token');
            return;
        }

        const syncReason = sanitizeSyncReason(reason);
        const updates = {
            lastActivityAt: admin.firestore.FieldValue.serverTimestamp(),
            duration: clampDuration(duration),
            sessionActive: sessionActive !== undefined ? sessionActive : false,
            lastSyncReason: syncReason,
            [`syncReasonCounts.${syncReason}`]: admin.firestore.FieldValue.increment(1)
        };

        const cleanJourney = sanitizeJourney(journey);
        if (cleanJourney.length > 0) {
            updates.journey = cleanJourney.slice(-MAX_JOURNEY_CHUNK);
        }
        updates.journeyCount = Math.max(cleanJourney.length, Math.min(1000000, Math.round(Number(journeyCount) || 0)));
        updates.pageCounts = sanitizeCountMap(pageCounts);
        updates.actionCounts = sanitizeCountMap(actionCounts);
        if (Array.isArray(lastEventPreview)) {
            updates.lastEventPreview = sanitizeEventPreview(lastEventPreview);
        }

        const result = await applySessionMessage(sessionRef, payload, updates);
        res.status(result.success ? 200 : 409).send(result.success ? 'Session synced via beacon' : 'Session rejected');
    } catch (error) {
        structuredLog('error', 'analytics_session_beacon_failed', {
            sessionIdHash: sessionIdForLog ? hashOpaque(sessionIdForLog) : null,
            errorClass: String(error?.code || error?.name || 'unknown').slice(0, 120)
        });
        res.status(500).send('Beacon sync failed');
    }
};

exports.syncSessionBeacon = regionalFunctions().https.onRequest(syncSessionBeaconHandler);

exports.syncSessionBeaconGen2 = onRequest(
    ANALYTICS_BEACON_GEN2_RUNTIME,
    syncSessionBeaconHandler
);

const deleteSessionGen2Handler = createDeleteSessionHandler({
    authorizationCache: sessionAuthorizationCache
});

exports.deleteSessionGen2 = onCall(
    ANALYTICS_CALLABLE_GEN2_RUNTIME,
    (request) => deleteSessionGen2Handler(request.data, request)
);

exports.initLiveSessionHandler = initLiveSessionHandler;
exports.syncSessionHandler = syncSessionHandler;
exports.syncSessionBeaconHandler = syncSessionBeaconHandler;
exports.deleteSessionGen2Handler = deleteSessionGen2Handler;
exports.ANALYTICS_CALLABLE_GEN2_RUNTIME = ANALYTICS_CALLABLE_GEN2_RUNTIME;
exports.ANALYTICS_BEACON_GEN2_RUNTIME = ANALYTICS_BEACON_GEN2_RUNTIME;
