/**
 * AUTH: Attribution automatique du rôle Admin
 * 
 * Trigger: auth.user().onCreate
 * Vérifie si le nouvel utilisateur est dans la whitelist admin.
 * Si oui, attribue le Custom Claim + met à jour Firestore.
 */
const functions = require('firebase-functions/v1');
const admin = require('firebase-admin');
const crypto = require('node:crypto');
const { SUPER_ADMIN_EMAIL: SUPER_ADMIN_EMAIL_SECRET } = require('../../helpers/secrets');
const { getSuperAdminEmail } = require('../../helpers/security');

const db = admin.firestore();

exports.grantAdminOnAuth = functions.runWith({ secrets: [SUPER_ADMIN_EMAIL_SECRET] }).auth.user().onCreate(async (user) => {
    const adminDocRef = db.doc('sys_metadata/admin_users');
    const docSnap = await adminDocRef.get();
    const normalizedUserEmail = (user.email || '').trim().toLowerCase();

    const superAdminEmail = getSuperAdminEmail();
    const isConfiguredSuperAdmin = Boolean(superAdminEmail) && normalizedUserEmail === superAdminEmail;

    if (!docSnap.exists && !isConfiguredSuperAdmin) return;

    const whitelist = docSnap.exists ? (docSnap.data().users || {}) : {};
    const [pendingKey, pendingData] = Object.entries(whitelist).find(([, val]) => (
        (val.email || '').trim().toLowerCase() === normalizedUserEmail
    )) || [];

    if ((pendingData || isConfiguredSuperAdmin) && user.emailVerified !== true) {
        console.warn('Admin claim refused: account email is not verified.');
        return;
    }

    if (pendingData || isConfiguredSuperAdmin) {
        const role = isConfiguredSuperAdmin ? 'owner' : 'admin';
        console.log('Admin claim assignment started.', { role });

        // Le registre serveur coupe les droits Rules avant l'expiration d'un ID token.
        const accessRef = db.collection('sys_admin_access').doc(user.uid);
        const activated = await db.runTransaction(async (transaction) => {
            const [accessSnap, freshWhitelistSnap] = await Promise.all([
                transaction.get(accessRef),
                transaction.get(adminDocRef)
            ]);
            if (accessSnap.exists && accessSnap.data().active !== true) return false;
            const freshInvitation = freshWhitelistSnap.exists && Object.values(freshWhitelistSnap.data().users || {})
                .some((entry) => (entry.email || '').trim().toLowerCase() === normalizedUserEmail
                    && ['pending', 'pending_email_verification', 'active'].includes(entry.status));
            if (!isConfiguredSuperAdmin && !freshInvitation) return false;
            transaction.set(accessRef, {
                uid: user.uid,
                active: true,
                role,
                emailHash: crypto.createHash('sha256').update(normalizedUserEmail).digest('hex'),
                activatedByUid: pendingData?.addedByUid || 'system',
                activatedAt: admin.firestore.FieldValue.serverTimestamp(),
                updatedAt: admin.firestore.FieldValue.serverTimestamp(),
                revokedAt: admin.firestore.FieldValue.delete(),
                revokedByUid: admin.firestore.FieldValue.delete(),
                revocationState: admin.firestore.FieldValue.delete(),
                version: 1
            }, { merge: true });
            return true;
        });
        if (!activated) return;

        // 1. Grant Custom Claims
        await admin.auth().setCustomUserClaims(user.uid, {
            ...(user.customClaims || {}),
            admin: true,
            superAdmin: isConfiguredSuperAdmin
        });

        // 2. Update Whitelist (pending → active with real UID)
        const callerEmail = pendingData?.addedBy || 'system';
        const adminUserRecord = {
            uid: user.uid,
            email: normalizedUserEmail,
            name: pendingData?.name || user.displayName || 'Admin',
            addedBy: callerEmail,
            status: 'active',
            role,
            superAdmin: isConfiguredSuperAdmin
        };
        const updates = {};
        if (pendingKey && pendingKey !== user.uid) {
            updates[`users.${pendingKey}`] = admin.firestore.FieldValue.delete();
        }
        updates[`users.${user.uid}`] = adminUserRecord;
        if (docSnap.exists) {
            await adminDocRef.update(updates);
        } else {
            await adminDocRef.set({ users: { [user.uid]: adminUserRecord } }, { merge: true });
        }

        // 3. Create/Update User Document
        await db.collection('users').doc(user.uid).set({
            role,
            superAdmin: isConfiguredSuperAdmin,
            email: normalizedUserEmail,
            name: user.displayName || pendingData?.name || 'Admin',
            updatedAt: admin.firestore.FieldValue.serverTimestamp()
        }, { merge: true });

        console.log('Admin claim assignment completed.', { role });
    } else {
        console.log('Admin claim skipped: account is not in the allowlist.');
    }
});
